package blocked;

import config.BannedCommandsManager;
import java.util.Iterator;
import java.util.List;
import minealex.tchat.OrdaChat;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.jetbrains.annotations.NotNull;

public class BannedCommands implements Listener {
   private final BannedCommandsManager bannedCommandsManager;
   private final OrdaChat plugin;

   public BannedCommands(@NotNull OrdaChat plugin) {
      this.bannedCommandsManager = plugin.getBannedCommandsManager();
      this.plugin = plugin;
   }

   @EventHandler
   public void onPlayerCommandPreprocess(@NotNull PlayerCommandPreprocessEvent event) {
      if (!event.isCancelled()) {
         Player player = event.getPlayer();
         String message = event.getMessage();
         if (!event.getPlayer().hasPermission(this.bannedCommandsManager.getBypassPermissionCommand()) && !event.getPlayer().hasPermission("tchat.admin")) {
            String command = message.split(" ")[0].substring(1).toLowerCase();
            List<String> bannedCommands = this.bannedCommandsManager.getBannedCommands();
            if (bannedCommands.contains(command)) {
               List<String> blockedMessages = this.bannedCommandsManager.getBlockedMessage();
               Iterator var7 = blockedMessages.iterator();

               String subtitle;
               while(var7.hasNext()) {
                  subtitle = (String)var7.next();
                  event.getPlayer().sendMessage(this.plugin.getTranslateColors().translateColors(player, subtitle));
               }

               String actionBar;
               if (this.bannedCommandsManager.getTitleEnabled()) {
                  actionBar = this.plugin.getTranslateColors().translateColors(player, this.bannedCommandsManager.getTitle());
                  subtitle = this.plugin.getTranslateColors().translateColors(player, this.bannedCommandsManager.getSubTitle());
                  player.sendTitle(actionBar, subtitle, 10, 70, 20);
               }

               if (this.bannedCommandsManager.getActionBarEnabled()) {
                  actionBar = this.plugin.getTranslateColors().translateColors(player, this.bannedCommandsManager.getActionBar());
                  player.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText(actionBar));
               }

               if (this.bannedCommandsManager.getSoundEnabled()) {
                  Sound sound = Sound.valueOf(this.bannedCommandsManager.getSound().toUpperCase());
                  player.playSound(player.getLocation(), sound, 1.0F, 1.0F);
               }

               if (this.bannedCommandsManager.isParticlesEnabled()) {
                  player.getWorld().spawnParticle(this.bannedCommandsManager.getParticle(), player.getLocation(), this.bannedCommandsManager.getParticles());
               }

               if (this.plugin.getConfigManager().isLogBannedCommandsEnabled()) {
                  this.plugin.getLogsManager().logBannedCommand(event.getPlayer().getName(), command);
               }

               if (this.bannedCommandsManager.isDiscordEnabled()) {
                  this.plugin.getDiscordHook().sendBannedCommandEmbed(player.getName(), command, message, this.bannedCommandsManager.getDiscordWebhook());
               }

               event.setCancelled(true);
            }
         }

      }
   }
}
