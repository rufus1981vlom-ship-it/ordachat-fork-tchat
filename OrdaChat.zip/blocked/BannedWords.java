package blocked;

import config.BannedWordsManager;
import java.util.Iterator;
import java.util.List;
import minealex.tchat.OrdaChat;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.jetbrains.annotations.NotNull;

public class BannedWords implements Listener {
   private final OrdaChat plugin;
   private final BannedWordsManager bannedWordsManager;

   public BannedWords(OrdaChat plugin, BannedWordsManager bannedWordsManager) {
      this.plugin = plugin;
      this.bannedWordsManager = bannedWordsManager;
   }

   @EventHandler
   public void playerBannedWords(@NotNull AsyncPlayerChatEvent event) {
      if (!event.isCancelled() && this.bannedWordsManager.isEnabled()) {
         Player player = event.getPlayer();
         if (!player.hasPermission(this.bannedWordsManager.getBypassPermission()) && !player.hasPermission("tchat.admin")) {
            String message = event.getMessage();
            List<String> bannedWords = this.bannedWordsManager.getBannedWords();
            List<String> whitelist = this.bannedWordsManager.getWhitelist();
            boolean isBlocked = false;
            Iterator var7 = bannedWords.iterator();

            while(true) {
               String word;
               do {
                  do {
                     if (!var7.hasNext()) {
                        if (isBlocked) {
                           event.setCancelled(true);
                        } else {
                           event.setMessage(message);
                        }

                        return;
                     }

                     word = (String)var7.next();
                  } while(this.isWhitelisted(message, whitelist));
               } while(!message.toLowerCase().contains(word.toLowerCase()));

               if (this.bannedWordsManager.isDiscordEnabled()) {
                  this.plugin.getDiscordHook().sendBannedWordEmbed(player.getName(), word, message, this.bannedWordsManager.getDiscordURL());
               }

               if (this.plugin.getConfigManager().isLogBannedWordsEnabled()) {
                  this.plugin.getLogsManager().logBannedWords(player.getName(), word);
               }

               if (!"BLOCK".equalsIgnoreCase(this.bannedWordsManager.getType())) {
                  if ("CENSOR".equalsIgnoreCase(this.bannedWordsManager.getType())) {
                     message = this.censorWord(word, message);
                  }
               } else {
                  List<String> blockedMessages = this.bannedWordsManager.getBlockedMessages();
                  Iterator var10 = blockedMessages.iterator();

                  while(var10.hasNext()) {
                     String blockedMessage = (String)var10.next();
                     blockedMessage = this.translateAndReplace(player, blockedMessage, word);
                     event.getPlayer().sendMessage(blockedMessage);
                  }

                  isBlocked = true;
               }

               String soundName;
               if (this.bannedWordsManager.getTitleEnabled()) {
                  soundName = this.translateAndReplace(player, this.bannedWordsManager.getTitle(), word);
                  String subtitle = this.translateAndReplace(player, this.bannedWordsManager.getSubTitle(), word);
                  player.sendTitle(soundName, subtitle, 10, 70, 20);
               }

               if (this.bannedWordsManager.getActionBarEnabled()) {
                  soundName = this.translateAndReplace(player, this.bannedWordsManager.getActionBar(), word);
                  player.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText(soundName));
               }

               if (this.bannedWordsManager.getSoundEnabled()) {
                  soundName = this.bannedWordsManager.getSound();
                  Sound sound = Sound.valueOf(soundName.toUpperCase());
                  player.playSound(player.getLocation(), sound, 1.0F, 1.0F);
               }

               if (this.bannedWordsManager.isParticlesEnabled()) {
                  player.getWorld().spawnParticle(this.bannedWordsManager.getParticle(), player.getLocation(), this.bannedWordsManager.getParticles());
               }
            }
         }
      }
   }

   private boolean isWhitelisted(@NotNull String message, @NotNull List<String> whitelist) {
      Iterator var3 = whitelist.iterator();

      String whitelistWord;
      do {
         if (!var3.hasNext()) {
            return false;
         }

         whitelistWord = (String)var3.next();
      } while(!message.toLowerCase().matches(".*\\b" + whitelistWord.toLowerCase() + "\\b.*"));

      return true;
   }

   @NotNull
   private String censorWord(@NotNull String word, @NotNull String message) {
      String regex = word.replaceAll("\\.", "$0[^a-zA-Z]*");
      String censoredWord = "*".repeat(word.length());
      return message.replaceAll("(?i)" + regex, censoredWord);
   }

   @NotNull
   private String translateAndReplace(Player player, String text, String word) {
      String translatedText = this.plugin.getTranslateColors().translateColors(player, text);
      return ChatColor.translateAlternateColorCodes('&', translatedText.replace("{word}", word));
   }
}
