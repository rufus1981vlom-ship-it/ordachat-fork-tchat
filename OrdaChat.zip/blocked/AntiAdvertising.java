package blocked;

import config.AdvertisingConfig;
import java.util.Iterator;
import minealex.tchat.OrdaChat;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.jetbrains.annotations.NotNull;

public class AntiAdvertising {
   private final OrdaChat plugin;

   public AntiAdvertising(OrdaChat plugin) {
      this.plugin = plugin;
   }

   public void checkAdvertising(@NotNull AsyncPlayerChatEvent event) {
      if (!event.isCancelled()) {
         Player player = event.getPlayer();
         String message = event.getMessage();
         this.checkAndHandle(event, player, message, this.plugin.getConfigManager().getIpv4Config());
         this.checkAndHandle(event, player, message, this.plugin.getConfigManager().getDomainConfig());
         this.checkAndHandle(event, player, message, this.plugin.getConfigManager().getLinksConfig());
      }
   }

   public void checkAdvertisingCommand(@NotNull PlayerCommandPreprocessEvent event, Player player, String command) {
      if (!event.isCancelled()) {
         this.checkAndHandleCommand(event, player, command, this.plugin.getConfigManager().getIpv4Config());
         this.checkAndHandleCommand(event, player, command, this.plugin.getConfigManager().getDomainConfig());
         this.checkAndHandleCommand(event, player, command, this.plugin.getConfigManager().getLinksConfig());
      }
   }

   private void checkAndHandleCommand(PlayerCommandPreprocessEvent event, @NotNull Player player, String command, AdvertisingConfig config) {
      if (shouldBlock(player, command, config)) {
         event.setCancelled(true);
         this.handleActions(player, command, config);
      }
   }

   public void checkAndHandle(AsyncPlayerChatEvent event, @NotNull Player player, String message, AdvertisingConfig config) {
      if (shouldBlock(player, message, config)) {
         event.setCancelled(true);
         this.handleActions(player, message, config);
      }
   }

   private boolean shouldBlock(@NotNull Player player, String message, @NotNull AdvertisingConfig config) {
      if (!config.isEnabled()) {
         return false;
      }

      if (!hasNoBypass(player)) {
         return false;
      }

      if (!message.matches(config.getMatch())) {
         return false;
      }

      return this.isWhitelisted(message, config);
   }

   private boolean hasNoBypass(@NotNull Player player) {
      String bypassPermission = this.plugin.getConfigManager().getAdvertisingBypass();

      boolean hasBypassPermission = bypassPermission != null
              && !bypassPermission.trim().isEmpty()
              && player.hasPermission(bypassPermission);

      boolean hasAdminPermission = player.hasPermission("tchat.admin");

      return !hasBypassPermission && !hasAdminPermission;
   }

   private boolean isWhitelisted(String message, @NotNull AdvertisingConfig config) {
      if (config.getWhitelist() != null) {
         Iterator<String> iterator = config.getWhitelist().iterator();

         while (iterator.hasNext()) {
            String whitelistItem = iterator.next();
            if (whitelistItem != null && !whitelistItem.isEmpty() && message.contains(whitelistItem)) {
               return false;
            }
         }
      }

      return true;
   }

   private void handleActions(Player player, String message, @NotNull AdvertisingConfig config) {
      if (config.isMessageEnabled() && config.getMessage() != null) {
         config.getMessage().forEach((msg) -> {
            String messageToSend = this.plugin.getTranslateColors().translateColors(player, msg);
            player.sendMessage(messageToSend);
         });
      }

      if (config.isTitleEnabled()) {
         String title = this.plugin.getTranslateColors().translateColors(player, config.getTitle());
         String subtitle = this.plugin.getTranslateColors().translateColors(player, config.getSubtitle());
         player.sendTitle(title, subtitle, config.getTitleFadeIn(), config.getTitleStay(), config.getTitleFadeOut());
      }

      if (config.isActionBarEnabled()) {
         String actionBarMessage = this.plugin.getTranslateColors().translateColors(player, config.getActionBar());
         player.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText(actionBarMessage));
      }

      if (config.isSoundEnabled()) {
         try {
            Sound sound = Sound.valueOf(config.getSound().toUpperCase());
            player.playSound(player.getLocation(), sound, config.getSoundVolume(), config.getSoundPitch());
         } catch (IllegalArgumentException | NullPointerException ignored) {
         }
      }

      if (config.isParticlesEnabled()) {
         try {
            String particleName = config.getParticleType();

            if ("VILLAGER_ANGRY".equalsIgnoreCase(particleName)) {
               particleName = "VILLAGER_ANGRY";
            }

            Particle particle = Particle.valueOf(particleName.toUpperCase());
            player.getWorld().spawnParticle(particle, player.getLocation(), config.getParticles());
         } catch (IllegalArgumentException | NullPointerException ignored) {
         }
      }

      if (this.plugin.getConfigManager().isAntiAdvertisingLogEnabled()) {
         this.plugin.getLogsManager().logAntiAdvertising(player.getName(), message);
      }
   }
}