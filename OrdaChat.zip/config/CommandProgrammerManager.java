package config;

import java.time.DayOfWeek;
import java.time.Month;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import minealex.tchat.OrdaChat;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

public class CommandProgrammerManager {
   private final OrdaChat plugin;
   private final ConfigFile configFile;
   private boolean enabled;
   private final List<CommandProgrammerManager.CommandSchedule> hourlyCommands = new ArrayList();
   private final List<CommandProgrammerManager.CommandSchedule> dailyCommands = new ArrayList();
   private final List<CommandProgrammerManager.CommandSchedule> weeklyCommands = new ArrayList();
   private final List<CommandProgrammerManager.CommandSchedule> monthlyCommands = new ArrayList();
   private final List<CommandProgrammerManager.CommandSchedule> yearlyCommands = new ArrayList();

   public CommandProgrammerManager(OrdaChat plugin) {
      this.plugin = plugin;
      this.configFile = new ConfigFile("command_programmer.yml", (String)null, plugin);
      this.configFile.registerConfig();
      this.loadConfig();
   }

   private void loadConfig() {
      FileConfiguration config = this.configFile.getConfig();
      this.enabled = config.getBoolean("options.enabled", true);
      if (this.enabled) {
         Iterator var2 = ((ConfigurationSection)Objects.requireNonNull(config.getConfigurationSection("commands"))).getKeys(false).iterator();

         while(var2.hasNext()) {
            String key = (String)var2.next();
            String type = config.getString("commands." + key + ".type");
            int players = config.getInt("commands." + key + ".players");
            List<String> commands = config.getStringList("commands." + key + ".commands");
            String var7 = (String)Objects.requireNonNull(type);
            byte var8 = -1;
            switch(var7.hashCode()) {
            case -1738378111:
               if (var7.equals("WEEKLY")) {
                  var8 = 2;
               }
               break;
            case -1681232246:
               if (var7.equals("YEARLY")) {
                  var8 = 4;
               }
               break;
            case 64808441:
               if (var7.equals("DAILY")) {
                  var8 = 1;
               }
               break;
            case 1954618349:
               if (var7.equals("MONTHLY")) {
                  var8 = 3;
               }
               break;
            case 2136870513:
               if (var7.equals("HOURLY")) {
                  var8 = 0;
               }
            }

            switch(var8) {
            case 0:
               int minute = config.getInt("commands." + key + ".minute");
               this.hourlyCommands.add(new CommandProgrammerManager.CommandSchedule(type, minute, -1, -1, (String)null, -1, players, commands));
               break;
            case 1:
               int hour = config.getInt("commands." + key + ".hour");
               int minuteDaily = config.getInt("commands." + key + ".minute");
               this.dailyCommands.add(new CommandProgrammerManager.CommandSchedule(type, minuteDaily, hour, -1, (String)null, -1, players, commands));
               break;
            case 2:
               int day = this.parseDay(config.get("commands." + key + ".day"));
               int hourWeekly = config.getInt("commands." + key + ".hour");
               int minuteWeekly = config.getInt("commands." + key + ".minute");
               this.weeklyCommands.add(new CommandProgrammerManager.CommandSchedule(type, minuteWeekly, hourWeekly, day, (String)null, -1, players, commands));
               break;
            case 3:
               int dayMonthly = config.getInt("commands." + key + ".day");
               int hourMonthly = config.getInt("commands." + key + ".hour");
               int minuteMonthly = config.getInt("commands." + key + ".minute");
               int monthMonthly = this.parseMonth(config.getString("commands." + key + ".month"));
               this.monthlyCommands.add(new CommandProgrammerManager.CommandSchedule(type, minuteMonthly, hourMonthly, dayMonthly, (String)null, monthMonthly, players, commands));
               break;
            case 4:
               int dayYearly = config.getInt("commands." + key + ".day");
               int hourYearly = config.getInt("commands." + key + ".hour");
               int minuteYearly = config.getInt("commands." + key + ".minute");
               int monthYearly = this.parseMonth(config.getString("commands." + key + ".month"));
               this.yearlyCommands.add(new CommandProgrammerManager.CommandSchedule(type, minuteYearly, hourYearly, dayYearly, (String)null, monthYearly, players, commands));
               break;
            default:
               this.plugin.getLogger().warning("Unknown command type: " + type);
            }
         }
      }

   }

   private int parseDay(Object value) {
      if (value instanceof Integer) {
         return (Integer)value;
      } else if (value instanceof String) {
         try {
            DayOfWeek dayOfWeek = DayOfWeek.valueOf(((String)value).toUpperCase());
            return dayOfWeek.getValue();
         } catch (IllegalArgumentException var3) {
            this.plugin.getLogger().warning("Invalid day format: " + value);
            return -1;
         }
      } else {
         return -1;
      }
   }

   private int parseMonth(String monthName) {
      if (monthName == null) {
         return -1;
      } else {
         try {
            Month month = Month.valueOf(monthName.toUpperCase());
            return month.getValue();
         } catch (IllegalArgumentException var3) {
            this.plugin.getLogger().warning("Invalid month format: " + monthName);
            return -1;
         }
      }
   }

   public void reloadConfig() {
      this.configFile.reloadConfig();
      this.loadConfig();
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public List<CommandProgrammerManager.CommandSchedule> getHourlyCommands() {
      return this.hourlyCommands;
   }

   public List<CommandProgrammerManager.CommandSchedule> getDailyCommands() {
      return this.dailyCommands;
   }

   public List<CommandProgrammerManager.CommandSchedule> getWeeklyCommands() {
      return this.weeklyCommands;
   }

   public List<CommandProgrammerManager.CommandSchedule> getMonthlyCommands() {
      return this.monthlyCommands;
   }

   public List<CommandProgrammerManager.CommandSchedule> getYearlyCommands() {
      return this.yearlyCommands;
   }

   public TChat getPlugin() {
      return this.plugin;
   }

   public static class CommandSchedule {
      private final String type;
      private final int minute;
      private final int hour;
      private final int day;
      private final String dayName;
      private final int month;
      private final int players;
      private final List<String> commands;

      public CommandSchedule(String type, int minute, int hour, int day, String dayName, int month, int players, List<String> commands) {
         this.type = type;
         this.minute = minute;
         this.hour = hour;
         this.day = day;
         this.dayName = dayName;
         this.month = month;
         this.players = players;
         this.commands = commands;
      }

      public String getType() {
         return this.type;
      }

      public int getMinute() {
         return this.minute;
      }

      public int getHour() {
         return this.hour;
      }

      public int getDay() {
         return this.day;
      }

      public String getDayName() {
         return this.dayName;
      }

      public int getMonth() {
         return this.month;
      }

      public int getPlayers() {
         return this.players;
      }

      public List<String> getCommands() {
         return this.commands;
      }
   }
}
