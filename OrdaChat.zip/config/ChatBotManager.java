package config;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import minealex.tchat.OrdaChat;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

public class ChatBotManager {
   private final ConfigFile chatBotFile;
   private boolean enabled;
   private Map<String, List<String>> messages;

   public ChatBotManager(OrdaChat plugin) {
      this.chatBotFile = new ConfigFile("chatbot.yml", (String)null, plugin);
      this.chatBotFile.registerConfig();
      this.loadConfig();
   }

   public void loadConfig() {
      FileConfiguration config = this.chatBotFile.getConfig();
      this.enabled = config.getBoolean("options.enabled");
      this.messages = new HashMap();
      if (config.isConfigurationSection("chatbot")) {
         Iterator var2 = ((ConfigurationSection)Objects.requireNonNull(config.getConfigurationSection("chatbot"))).getKeys(false).iterator();

         while(var2.hasNext()) {
            String key = (String)var2.next();
            List<String> messageList = config.getStringList("chatbot." + key + ".messages");
            this.messages.put(key, messageList);
         }
      }

   }

   public void reloadConfig() {
      this.chatBotFile.reloadConfig();
      this.loadConfig();
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public List<String> getMessages(String key) {
      return (List)this.messages.getOrDefault(key, List.of());
   }
}
