package config;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import minealex.tchat.OrdaChat;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

public class MentionsManager {
   private final ConfigFile configFile;
   private Map<String, MentionsManager.GroupConfig> groupsConfig;
   private Map<String, MentionsManager.EventConfig> personalEvents;
   private Map<String, MentionsManager.EventConfig> globalEvents;
   private boolean enabled;

   public MentionsManager(OrdaChat plugin) {
      this.configFile = new ConfigFile("mentions.yml", (String)null, plugin);
      this.configFile.registerConfig();
      this.loadConfig();
   }

   public void loadConfig() {
      FileConfiguration config = this.configFile.getConfig();
      this.enabled = config.getBoolean("enabled", false);
      if (this.enabled) {
         ConfigurationSection groupsSection = config.getConfigurationSection("groups");
         if (groupsSection != null) {
            this.groupsConfig = new HashMap();
            this.personalEvents = new HashMap();
            this.globalEvents = new HashMap();
            Iterator var3 = groupsSection.getKeys(false).iterator();

            while(var3.hasNext()) {
               String groupName = (String)var3.next();
               ConfigurationSection groupSection = groupsSection.getConfigurationSection(groupName);
               if (groupSection != null) {
                  MentionsManager.GroupConfig groupConfig = new MentionsManager.GroupConfig();
                  groupConfig.setCharacter(groupSection.getString("character", "@"));
                  groupConfig.setColor(groupSection.getString("color", "&f"));
                  ConfigurationSection personalSection = groupSection.getConfigurationSection("personal");
                  if (personalSection != null) {
                     MentionsManager.EventConfig personalConfig = new MentionsManager.EventConfig();
                     this.loadEventConfig(personalSection, personalConfig);
                     this.personalEvents.put(groupName, personalConfig);
                     groupConfig.setPersonalConfig(personalConfig);
                  }

                  ConfigurationSection globalSection = groupSection.getConfigurationSection("global");
                  if (globalSection != null) {
                     MentionsManager.EventConfig globalConfig = new MentionsManager.EventConfig();
                     this.loadEventConfig(globalSection, globalConfig);
                     this.globalEvents.put(groupName, globalConfig);
                     groupConfig.setGlobalConfig(globalConfig);
                  }

                  this.groupsConfig.put(groupName, groupConfig);
               }
            }
         }

      }
   }

   private void loadEventConfig(ConfigurationSection eventSection, MentionsManager.EventConfig eventConfig) {
      if (eventSection != null) {
         eventConfig.setMessageEnabled(eventSection.getBoolean("message.enabled", false));
         eventConfig.setMessage(eventSection.getStringList("message.text"));
         ConfigurationSection titleSection = eventSection.getConfigurationSection("title");
         if (titleSection != null) {
            eventConfig.setTitleEnabled(titleSection.getBoolean("enabled", false));
            eventConfig.setTitle(titleSection.getString("main", ""));
            eventConfig.setSubtitleEnabled(titleSection.getBoolean("subtitle.enabled", false));
            eventConfig.setSubtitle(titleSection.getString("subtitle.text", ""));
         }

         ConfigurationSection soundSection = eventSection.getConfigurationSection("sound");
         if (soundSection != null) {
            eventConfig.setSoundEnabled(soundSection.getBoolean("enabled", false));
            eventConfig.setSound(soundSection.getString("type", ""));
         }

         ConfigurationSection particlesSection = eventSection.getConfigurationSection("particles");
         if (particlesSection != null) {
            eventConfig.setParticlesEnabled(particlesSection.getBoolean("enabled", false));
            eventConfig.setParticle(particlesSection.getString("type", ""));
         }

         ConfigurationSection actionbarSection = eventSection.getConfigurationSection("actionbar");
         if (actionbarSection != null) {
            eventConfig.setActionbarEnabled(actionbarSection.getBoolean("enabled", false));
            eventConfig.setActionbarMessage(actionbarSection.getString("text", ""));
         }
      }

   }

   public void reloadConfig() {
      this.configFile.reloadConfig();
      this.loadConfig();
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public MentionsManager.GroupConfig getGroupConfig(String group) {
      return (MentionsManager.GroupConfig)this.groupsConfig.getOrDefault(group, new MentionsManager.GroupConfig());
   }

   public MentionsManager.EventConfig getPersonalEventConfig(String group) {
      return (MentionsManager.EventConfig)this.personalEvents.getOrDefault(group, new MentionsManager.EventConfig());
   }

   public MentionsManager.EventConfig getGlobalEventConfig(String group) {
      return (MentionsManager.EventConfig)this.globalEvents.getOrDefault(group, new MentionsManager.EventConfig());
   }

   public static class GroupConfig {
      private String character;
      private String color;
      private MentionsManager.EventConfig personalConfig;
      private MentionsManager.EventConfig globalConfig;

      public String getCharacter() {
         return this.character;
      }

      public void setCharacter(String character) {
         this.character = character;
      }

      public String getColor() {
         return this.color;
      }

      public void setColor(String color) {
         this.color = color;
      }

      public MentionsManager.EventConfig getPersonalConfig() {
         return this.personalConfig;
      }

      public void setPersonalConfig(MentionsManager.EventConfig personalConfig) {
         this.personalConfig = personalConfig;
      }

      public MentionsManager.EventConfig getGlobalConfig() {
         return this.globalConfig;
      }

      public void setGlobalConfig(MentionsManager.EventConfig globalConfig) {
         this.globalConfig = globalConfig;
      }
   }

   public static class EventConfig {
      private boolean messageEnabled;
      private List<String> message;
      private boolean titleEnabled;
      private String title;
      private boolean subtitleEnabled;
      private String subtitle;
      private boolean soundEnabled;
      private String sound;
      private boolean particlesEnabled;
      private String particle;
      private boolean actionbarEnabled;
      private String actionbarMessage;

      public boolean isMessageEnabled() {
         return this.messageEnabled;
      }

      public void setMessageEnabled(boolean messageEnabled) {
         this.messageEnabled = messageEnabled;
      }

      public List<String> getMessage() {
         return this.message;
      }

      public void setMessage(List<String> message) {
         this.message = message;
      }

      public boolean isTitleEnabled() {
         return this.titleEnabled;
      }

      public void setTitleEnabled(boolean titleEnabled) {
         this.titleEnabled = titleEnabled;
      }

      public String getTitle() {
         return this.title;
      }

      public void setTitle(String title) {
         this.title = title;
      }

      public boolean isSubtitleEnabled() {
         return this.subtitleEnabled;
      }

      public void setSubtitleEnabled(boolean subtitleEnabled) {
         this.subtitleEnabled = subtitleEnabled;
      }

      public String getSubtitle() {
         return this.subtitle;
      }

      public void setSubtitle(String subtitle) {
         this.subtitle = subtitle;
      }

      public boolean isSoundEnabled() {
         return this.soundEnabled;
      }

      public void setSoundEnabled(boolean soundEnabled) {
         this.soundEnabled = soundEnabled;
      }

      public String getSound() {
         return this.sound;
      }

      public void setSound(String sound) {
         this.sound = sound;
      }

      public boolean isParticlesEnabled() {
         return this.particlesEnabled;
      }

      public void setParticlesEnabled(boolean particlesEnabled) {
         this.particlesEnabled = particlesEnabled;
      }

      public String getParticle() {
         return this.particle;
      }

      public void setParticle(String particle) {
         this.particle = particle;
      }

      public boolean isActionbarEnabled() {
         return this.actionbarEnabled;
      }

      public void setActionbarEnabled(boolean actionbarEnabled) {
         this.actionbarEnabled = actionbarEnabled;
      }

      public String getActionbarMessage() {
         return this.actionbarMessage;
      }

      public void setActionbarMessage(String actionbarMessage) {
         this.actionbarMessage = actionbarMessage;
      }
   }
}
