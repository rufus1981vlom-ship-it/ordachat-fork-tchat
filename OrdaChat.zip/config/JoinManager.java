package config;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import minealex.tchat.OrdaChat;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

public class JoinManager {
   private final ConfigFile configFile;
   private final Map<String, JoinManager.GroupConfig> groupConfigs;

   public JoinManager(OrdaChat plugin) {
      this.configFile = new ConfigFile("joins.yml", (String)null, plugin);
      this.configFile.registerConfig();
      this.groupConfigs = new HashMap();
      this.loadConfig();
   }

   public void loadConfig() {
      FileConfiguration config = this.configFile.getConfig();
      ConfigurationSection groupsSection = config.getConfigurationSection("groups");
      if (groupsSection != null) {
         Iterator var3 = groupsSection.getKeys(false).iterator();

         while(var3.hasNext()) {
            String groupName = (String)var3.next();
            ConfigurationSection groupSection = groupsSection.getConfigurationSection(groupName);
            if (groupSection != null) {
               JoinManager.GroupConfig groupConfig = new JoinManager.GroupConfig();
               this.loadEventConfig(groupSection.getConfigurationSection("join.personal"), groupConfig.getPersonalConfig());
               this.loadEventConfig(groupSection.getConfigurationSection("join.global"), groupConfig.getGlobalConfig());
               this.loadEventConfig(groupSection.getConfigurationSection("quit"), groupConfig.getQuitConfig());
               this.groupConfigs.put(groupName, groupConfig);
            }
         }
      }

   }

   private void loadEventConfig(ConfigurationSection eventSection, JoinManager.EventConfig eventConfig) {
      if (eventSection != null) {
         eventConfig.setCancelLeftMessage(eventSection.getBoolean("cancel-quit-message", false));
         eventConfig.setCancelJoinMessage(eventSection.getBoolean("cancel-join-message", false));
         eventConfig.setMessageEnabled(eventSection.getBoolean("message-enabled", false));
         eventConfig.setMessage(eventSection.getStringList("message"));
         ConfigurationSection titleSection = eventSection.getConfigurationSection("title");
         if (titleSection != null) {
            eventConfig.setTitleEnabled(titleSection.getBoolean("enabled", false));
            eventConfig.setTitle(titleSection.getString("title", ""));
            eventConfig.setSubtitle(titleSection.getString("subtitle", ""));
         }

         ConfigurationSection soundSection = eventSection.getConfigurationSection("sound");
         if (soundSection != null) {
            eventConfig.setSoundEnabled(soundSection.getBoolean("enabled", false));
            eventConfig.setSound(soundSection.getString("sound", ""));
            eventConfig.setVolume((float)soundSection.getDouble("volume", 1.0D));
            eventConfig.setPitch((float)soundSection.getDouble("pitch", 1.0D));
         }

         ConfigurationSection particlesSection = eventSection.getConfigurationSection("particles");
         if (particlesSection != null) {
            eventConfig.setParticlesEnabled(particlesSection.getBoolean("enabled", false));
            eventConfig.setParticle(particlesSection.getString("particle", ""));
         }

         ConfigurationSection actionbarSection = eventSection.getConfigurationSection("actionbar");
         if (actionbarSection != null) {
            eventConfig.setActionbarEnabled(actionbarSection.getBoolean("enabled", false));
            eventConfig.setActionbarMessage(actionbarSection.getString("actionbar", ""));
         }
      }

   }

   public void reloadConfig() {
      this.configFile.reloadConfig();
      this.loadConfig();
   }

   public JoinManager.EventConfig getPersonalConfig(String groupName) {
      return this.groupConfigs.containsKey(groupName) ? ((JoinManager.GroupConfig)this.groupConfigs.get(groupName)).getPersonalConfig() : new JoinManager.EventConfig();
   }

   public JoinManager.EventConfig getGlobalConfig(String groupName) {
      return this.groupConfigs.containsKey(groupName) ? ((JoinManager.GroupConfig)this.groupConfigs.get(groupName)).getGlobalConfig() : new JoinManager.EventConfig();
   }

   public JoinManager.EventConfig getQuitConfig(String groupName) {
      return this.groupConfigs.containsKey(groupName) ? ((JoinManager.GroupConfig)this.groupConfigs.get(groupName)).getQuitConfig() : new JoinManager.EventConfig();
   }

   public Map<String, JoinManager.GroupConfig> getAllGroupConfigs() {
      return this.groupConfigs;
   }

   public static class GroupConfig {
      private final JoinManager.EventConfig personalConfig = new JoinManager.EventConfig();
      private final JoinManager.EventConfig globalConfig = new JoinManager.EventConfig();
      private final JoinManager.EventConfig quitConfig = new JoinManager.EventConfig();

      public JoinManager.EventConfig getPersonalConfig() {
         return this.personalConfig;
      }

      public JoinManager.EventConfig getGlobalConfig() {
         return this.globalConfig;
      }

      public JoinManager.EventConfig getQuitConfig() {
         return this.quitConfig;
      }
   }

   public static class EventConfig {
      private boolean messageEnabled;
      private List<String> message;
      private boolean titleEnabled;
      private String title;
      private String subtitle;
      private boolean soundEnabled;
      private String sound;
      private float volume;
      private float pitch;
      private boolean particlesEnabled;
      private String particle;
      private boolean actionbarEnabled;
      private String actionbarMessage;
      private boolean cancelJoinMessage;
      private boolean cancelLeftMessage;

      public float getVolume() {
         return this.volume;
      }

      public float getPitch() {
         return this.pitch;
      }

      public boolean isCancelJoinMessage() {
         return this.cancelJoinMessage;
      }

      public void setCancelJoinMessage(boolean cancelJoinMessage) {
         this.cancelJoinMessage = cancelJoinMessage;
      }

      public boolean isCancelLeftMessage() {
         return this.cancelLeftMessage;
      }

      public void setCancelLeftMessage(boolean cancelLeftMessage) {
         this.cancelLeftMessage = cancelLeftMessage;
      }

      public boolean isMessageEnabled() {
         return this.messageEnabled;
      }

      public void setMessageEnabled(boolean messageEnabled) {
         this.messageEnabled = messageEnabled;
      }

      public List<String> getMessage() {
         return this.message;
      }

      public void setMessage(List<String> message) {
         this.message = message;
      }

      public boolean isTitleEnabled() {
         return this.titleEnabled;
      }

      public void setTitleEnabled(boolean titleEnabled) {
         this.titleEnabled = titleEnabled;
      }

      public String getTitle() {
         return this.title;
      }

      public void setTitle(String title) {
         this.title = title;
      }

      public void setVolume(float volume) {
         this.volume = volume;
      }

      public void setPitch(float pitch) {
         this.pitch = pitch;
      }

      public String getSubtitle() {
         return this.subtitle;
      }

      public void setSubtitle(String subtitle) {
         this.subtitle = subtitle;
      }

      public boolean isSoundEnabled() {
         return this.soundEnabled;
      }

      public void setSoundEnabled(boolean soundEnabled) {
         this.soundEnabled = soundEnabled;
      }

      public String getSound() {
         return this.sound;
      }

      public void setSound(String sound) {
         this.sound = sound;
      }

      public boolean isParticlesEnabled() {
         return this.particlesEnabled;
      }

      public void setParticlesEnabled(boolean particlesEnabled) {
         this.particlesEnabled = particlesEnabled;
      }

      public String getParticle() {
         return this.particle;
      }

      public void setParticle(String particle) {
         this.particle = particle;
      }

      public boolean isActionbarEnabled() {
         return this.actionbarEnabled;
      }

      public void setActionbarEnabled(boolean actionbarEnabled) {
         this.actionbarEnabled = actionbarEnabled;
      }

      public String getActionbarMessage() {
         return this.actionbarMessage;
      }

      public void setActionbarMessage(String actionbarMessage) {
         this.actionbarMessage = actionbarMessage;
      }
   }
}
