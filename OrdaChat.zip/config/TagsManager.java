package config;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import minealex.tchat.OrdaChat;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

public class TagsManager {
   private final ConfigFile configFile;
   private final Map<String, TagsManager.Tag> tags = new HashMap();

   public TagsManager(OrdaChat plugin) {
      this.configFile = new ConfigFile("tags.yml", (String)null, plugin);
      this.configFile.registerConfig();
      this.loadConfig();
   }

   public void loadConfig() {
      FileConfiguration config = this.configFile.getConfig();
      this.tags.clear();
      if (config.isConfigurationSection("tags")) {
         Iterator var2 = ((ConfigurationSection)Objects.requireNonNull(config.getConfigurationSection("tags"))).getKeys(false).iterator();

         while(var2.hasNext()) {
            String key = (String)var2.next();
            String permission = config.getString("tags." + key + ".permission", "");
            String display = config.getString("tags." + key + ".display", "");
            this.tags.put(key, new TagsManager.Tag(permission, display));
         }
      }

   }

   public void reloadConfig() {
      this.configFile.reloadConfig();
      this.loadConfig();
   }

   public TagsManager.Tag getTag(String key) {
      return (TagsManager.Tag)this.tags.get(key);
   }

   public Map<String, TagsManager.Tag> getTags() {
      return this.tags;
   }

   public static class Tag {
      private final String permission;
      private final String display;

      public Tag(String permission, String display) {
         this.permission = permission;
         this.display = display;
      }

      public String getPermission() {
         return this.permission;
      }

      public String getDisplay() {
         return this.display;
      }
   }
}
