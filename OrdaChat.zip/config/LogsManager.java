package config;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import minealex.tchat.OrdaChat;
import org.bukkit.Bukkit;
import org.jetbrains.annotations.NotNull;

public class LogsManager {
   private final File chatLogFile;
   private final File commandLogFile;
   private final File bannedCommandsFile;
   private final File bannedWordsFile;
   private final File ignoreFile;
   private final File antiAdverFile;
   private final File deathFile;

   public LogsManager(@NotNull OrdaChat plugin) {
      File pluginDataFolder = plugin.getDataFolder();
      File logsFolder = new File(pluginDataFolder, "logs");
      if (!logsFolder.exists()) {
         logsFolder.mkdirs();
      }

      this.chatLogFile = new File(logsFolder, "chat.log");
      this.commandLogFile = new File(logsFolder, "commands.log");
      this.bannedCommandsFile = new File(logsFolder, "banned_commands.log");
      this.bannedWordsFile = new File(logsFolder, "banned_words.log");
      this.ignoreFile = new File(logsFolder, "ignore.log");
      this.antiAdverFile = new File(logsFolder, "anti_advertising.log");
      this.deathFile = new File(logsFolder, "death.log");
      this.regenerateFiles();
   }

   private void regenerateFiles() {
      File[] files = new File[]{this.chatLogFile, this.commandLogFile, this.bannedCommandsFile, this.bannedWordsFile, this.ignoreFile, this.antiAdverFile, this.deathFile};
      File[] var2 = files;
      int var3 = files.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         File file = var2[var4];
         if (file.exists()) {
            this.clearFile(file);
         }
      }

   }

   private void clearFile(File file) {
      try {
         FileWriter writer = new FileWriter(file);

         try {
            writer.write("");
         } catch (Throwable var6) {
            try {
               writer.close();
            } catch (Throwable var5) {
               var6.addSuppressed(var5);
            }

            throw var6;
         }

         writer.close();
      } catch (IOException var7) {
         Bukkit.getLogger().severe("Failed to clear log file: " + var7.getMessage());
      }

   }

   public void logChatMessage(String playerName, String message) {
      try {
         BufferedWriter writer = new BufferedWriter(new FileWriter(this.chatLogFile, true));

         try {
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            writer.write("[" + timestamp + "] " + playerName + ": " + message);
            writer.newLine();
         } catch (Throwable var7) {
            try {
               writer.close();
            } catch (Throwable var6) {
               var7.addSuppressed(var6);
            }

            throw var7;
         }

         writer.close();
      } catch (IOException var8) {
         Bukkit.getLogger().severe("Failed to log chat message: " + var8.getMessage() + " (#c7dhd - LogsManager.java)");
      }

   }

   public void logCommand(String playerName, String command) {
      try {
         BufferedWriter writer = new BufferedWriter(new FileWriter(this.commandLogFile, true));

         try {
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            writer.write("[" + timestamp + "] " + playerName + ": " + command);
            writer.newLine();
         } catch (Throwable var7) {
            try {
               writer.close();
            } catch (Throwable var6) {
               var7.addSuppressed(var6);
            }

            throw var7;
         }

         writer.close();
      } catch (IOException var8) {
         Bukkit.getLogger().severe("Failed to log command: " + var8.getMessage() + " (#8dns3 - LogsManager.java)");
      }

   }

   public void logBannedCommand(String playerName, String command) {
      try {
         BufferedWriter writer = new BufferedWriter(new FileWriter(this.bannedCommandsFile, true));

         try {
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            writer.write("[" + timestamp + "] Banned Command executed by: " + playerName + ": /" + command);
            writer.newLine();
         } catch (Throwable var7) {
            try {
               writer.close();
            } catch (Throwable var6) {
               var7.addSuppressed(var6);
            }

            throw var7;
         }

         writer.close();
      } catch (IOException var8) {
         Bukkit.getLogger().severe("Failed to log banned command: " + var8.getMessage() + " (#xc8m2 - LogsManager.java)");
      }

   }

   public void logBannedWords(String playerName, String word) {
      try {
         BufferedWriter writer = new BufferedWriter(new FileWriter(this.bannedWordsFile, true));

         try {
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            writer.write("[" + timestamp + "] Banned Word executed by: " + playerName + ": " + word);
            writer.newLine();
         } catch (Throwable var7) {
            try {
               writer.close();
            } catch (Throwable var6) {
               var7.addSuppressed(var6);
            }

            throw var7;
         }

         writer.close();
      } catch (IOException var8) {
         Bukkit.getLogger().severe("Failed to log banned command: " + var8.getMessage() + " (#c8sm1 - LogsManager.java)");
      }

   }

   public void logIgnore(String player, String playerName) {
      try {
         BufferedWriter writer = new BufferedWriter(new FileWriter(this.ignoreFile, true));

         try {
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            writer.write("[" + timestamp + "] Player" + player + "ignored by: " + playerName);
            writer.newLine();
         } catch (Throwable var7) {
            try {
               writer.close();
            } catch (Throwable var6) {
               var7.addSuppressed(var6);
            }

            throw var7;
         }

         writer.close();
      } catch (IOException var8) {
         Bukkit.getLogger().severe("Failed to log banned command: " + var8.getMessage() + " (#a6bd1 - LogsManager.java)");
      }

   }

   public void logAntiAdvertising(String player, String word) {
      try {
         BufferedWriter writer = new BufferedWriter(new FileWriter(this.antiAdverFile, true));

         try {
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            writer.write("[" + timestamp + "] Detected Anti Advertising for: " + player + " with words: " + word);
            writer.newLine();
         } catch (Throwable var7) {
            try {
               writer.close();
            } catch (Throwable var6) {
               var7.addSuppressed(var6);
            }

            throw var7;
         }

         writer.close();
      } catch (IOException var8) {
         Bukkit.getLogger().severe("Failed to log banned command: " + var8.getMessage() + " (#8nr7c - LogsManager.java)");
      }

   }

   public void logDeaths(String player) {
      try {
         BufferedWriter writer = new BufferedWriter(new FileWriter(this.deathFile, true));

         try {
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            writer.write("[" + timestamp + "] Player " + player + " has died");
            writer.newLine();
         } catch (Throwable var6) {
            try {
               writer.close();
            } catch (Throwable var5) {
               var6.addSuppressed(var5);
            }

            throw var6;
         }

         writer.close();
      } catch (IOException var7) {
         Bukkit.getLogger().severe("Failed to log death: " + var7.getMessage() + " (#n56gb - LogsManager.java)");
      }

   }

   public File getChatLogFile() {
      return this.chatLogFile;
   }

   public File getCommandLogFile() {
      return this.commandLogFile;
   }

   public File getBannedCommandsFile() {
      return this.bannedCommandsFile;
   }

   public File getBannedWordsFile() {
      return this.bannedWordsFile;
   }

   public File getIgnoreFile() {
      return this.ignoreFile;
   }

   public File getAntiAdverFile() {
      return this.antiAdverFile;
   }

   public File getDeathFile() {
      return this.deathFile;
   }
}
