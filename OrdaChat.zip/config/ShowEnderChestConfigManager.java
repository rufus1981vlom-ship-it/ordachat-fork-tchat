package config;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import minealex.tchat.OrdaChat;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

public class ShowEnderChestConfigManager {
   private final ConfigFile configFile;
   private String menuTitle;
   private int slots;
   private Material glassMaterial;
   private String glassDisplayName;
   private Material headMaterial;
   private String headDisplayName;
   private List<String> headLore;
   private int headSlot;
   private int startSlotGlass;
   private int endSlotGlass;
   private int startSlotEnder;
   private int endSlotEnder;
   private boolean enabled;

   public ShowEnderChestConfigManager(OrdaChat plugin) {
      this.configFile = new ConfigFile("show_ender_chest.yml", "menus", plugin);
      this.configFile.registerConfig();
      this.loadConfig();
   }

   public void loadConfig() {
      FileConfiguration config = this.configFile.getConfig();
      this.enabled = config.getBoolean("menu.enabled", false);
      if (this.enabled) {
         this.menuTitle = config.getString("menu.title", "%player_name%'s enderchest");
         this.slots = config.getInt("menu.slots", 36);
         String glassMaterialName = config.getString("menu.glass.material", "GRAY_STAINED_GLASS_PANE");
         this.glassMaterial = Material.matchMaterial(glassMaterialName);
         this.glassDisplayName = config.getString("menu.glass.display_name", " ");
         this.startSlotGlass = config.getInt("menu.glass.slots.start", 27);
         this.endSlotGlass = config.getInt("menu.glass.slots.end", 36);
         String headMaterialName = config.getString("menu.head.material", "PLAYER_HEAD");
         this.headMaterial = Material.matchMaterial(headMaterialName);
         this.headSlot = config.getInt("menu.head.slot", 31);
         this.headDisplayName = config.getString("menu.head.display_name", "Information about %player%");
         this.headLore = config.getStringList("menu.head.lore");
         this.startSlotEnder = config.getInt("ender.slots.start", 0);
         this.endSlotEnder = config.getInt("ender.slots.end", 27);
      }

   }

   public void reloadConfig() {
      this.configFile.reloadConfig();
      this.loadConfig();
   }

   public String getMenuTitle() {
      return this.menuTitle;
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public int getSlots() {
      return this.slots;
   }

   public int getHeadSlot() {
      return this.headSlot;
   }

   public int getStartSlotGlass() {
      return this.startSlotGlass;
   }

   public int getEndSlotGlass() {
      return this.endSlotGlass;
   }

   public int getStartSlotEnder() {
      return this.startSlotEnder;
   }

   public int getEndSlotEnder() {
      return this.endSlotEnder;
   }

   public ItemStack createGlass() {
      ItemStack glass = new ItemStack(this.glassMaterial);
      ItemMeta glassMeta = glass.getItemMeta();
      if (glassMeta != null) {
         glassMeta.setDisplayName(this.glassDisplayName);
         glass.setItemMeta(glassMeta);
      }

      return glass;
   }

   public ItemStack createHead(Player target) {
      ItemStack head = new ItemStack(this.headMaterial);
      SkullMeta headMeta = (SkullMeta)head.getItemMeta();
      if (headMeta != null) {
         String displayName = this.headDisplayName.replace("%player%", target.getName());
         headMeta.setDisplayName(displayName);
         headMeta.setOwningPlayer(target);
         List<String> lore = new ArrayList();
         Iterator var6 = this.headLore.iterator();

         while(var6.hasNext()) {
            String line = (String)var6.next();
            line = line.replace("%player%", target.getName()).replace("%uuid%", target.getUniqueId().toString()).replace("%health%", String.valueOf(target.getHealth())).replace("%level%", String.valueOf(target.getLevel()));
            lore.add(line);
         }

         headMeta.setLore(lore);
         head.setItemMeta(headMeta);
      }

      return head;
   }
}
