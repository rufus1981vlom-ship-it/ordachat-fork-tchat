package config;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import minealex.tchat.OrdaChat;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class ReplacerManager {
   private final ConfigFile replacerConfig;
   private Map<String, ReplacerManager.Replacement> replacements;
   private static boolean replacerEnabled;

   public ReplacerManager(OrdaChat plugin) {
      this.replacerConfig = new ConfigFile("replacer.yml", (String)null, plugin);
      this.replacerConfig.registerConfig();
      this.loadConfig();
   }

   public void loadConfig() {
      FileConfiguration config = this.replacerConfig.getConfig();
      this.loadReplacements(config);
   }

   public void reloadConfig() {
      this.replacerConfig.reloadConfig();
      this.loadConfig();
   }

   private void loadReplacements(@NotNull FileConfiguration config) {
      this.replacements = new HashMap();
      replacerEnabled = config.getBoolean("replacer_enabled", false);
      if (config.getConfigurationSection("words") != null) {
         Iterator var2 = ((ConfigurationSection)Objects.requireNonNull(config.getConfigurationSection("words"))).getKeys(false).iterator();

         while(var2.hasNext()) {
            String key = (String)var2.next();
            String path = "words." + key;
            String original = config.getString(path + ".original");
            String replace = config.getString(path + ".replace");
            String permission = config.getString(path + ".permission");
            this.replacements.put(original, new ReplacerManager.Replacement(original, replace, permission));
         }

      }
   }

   public String replaceWords(String message, Player player) {
      Iterator var3 = this.replacements.values().iterator();

      while(true) {
         ReplacerManager.Replacement replacement;
         do {
            if (!var3.hasNext()) {
               return message;
            }

            replacement = (ReplacerManager.Replacement)var3.next();
         } while(!"none".equals(replacement.getPermission()) && !player.hasPermission(replacement.getPermission()));

         message = message.replaceAll("\\b" + replacement.getOriginal() + "\\b", replacement.getReplace());
      }
   }

   public boolean getReplacerEnabled() {
      return replacerEnabled;
   }

   public void addReplacement(String original, String replace, String permission) {
      this.replacements.put(original, new ReplacerManager.Replacement(original, replace, permission));
      this.replacerConfig.getConfig().set("words." + original + ".original", original);
      this.replacerConfig.getConfig().set("words." + original + ".replace", replace);
      this.replacerConfig.getConfig().set("words." + original + ".permission", permission);
      this.replacerConfig.saveConfig();
   }

   public void removeReplacement(String original) {
      this.replacements.remove(original);
      this.replacerConfig.getConfig().set("words." + original, (Object)null);
      this.replacerConfig.saveConfig();
   }

   public Map<String, ReplacerManager.Replacement> getReplacements() {
      return this.replacements;
   }

   public void setReplacerEnabled(boolean enabled) {
      replacerEnabled = enabled;
      this.replacerConfig.getConfig().set("replacer_enabled", enabled);
      this.replacerConfig.saveConfig();
   }

   public static class Replacement {
      private final String original;
      private final String replace;
      private final String permission;

      public Replacement(String original, String replace, String permission) {
         this.original = original;
         this.replace = replace;
         this.permission = permission;
      }

      public String getOriginal() {
         return this.original;
      }

      public String getReplace() {
         return this.replace;
      }

      public String getPermission() {
         return this.permission;
      }
   }
}
