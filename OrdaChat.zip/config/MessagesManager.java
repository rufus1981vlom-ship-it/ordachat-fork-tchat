package config;

import java.util.List;
import minealex.tchat.OrdaChat;
import org.bukkit.configuration.file.FileConfiguration;

public class MessagesManager {
   private ConfigFile messagesFile;
   private final OrdaChat plugin;
   private String noPermission;
   private String versionMessage;
   private String reloadMessage;
   private String unknownMessage;
   private String prefix;
   private String noFormatGroup;
   private String noPlayer;
   private String antiCapMessage;
   private String colorSelectedMessage;
   private String formatSelectedMessage;
   private String invalidIdMessage;
   private String materialNotFound;
   private String usageChannel;
   private String usageJoinChannel;
   private String usageLeaveChannel;
   private String channelNotExist;
   private String channelNoPermissionJoin;
   private String channelAlready;
   private String channelLeft;
   private String channelJoin;
   private String channelLeftAnnounce;
   private String channelJoinAnnounce;
   private String noChannel;
   private String noPermissionChannelLeft;
   private String playerNotFound;
   private String usageMsg;
   private String usageReply;
   private String noReply;
   private String chatClearMessage;
   private String chatMuted;
   private String chatMute;
   private String chatUnmute;
   private String repeatMessage;
   private String antibotChat;
   private String antibotCommand;
   private String antibotJoin;
   private String antibotMoved;
   private String noEnabledGames;
   private String noMessages;
   private String timeFinished;
   private String gameWin;
   private String cooldownChat;
   private String cooldownCommand;
   private String antiFlood;
   private String customCommandsCooldown;
   private String ping;
   private String broadcastUsage;
   private String ignoreUsage;
   private String ignoreSelf;
   private String ignoreAlready;
   private String ignoreMessage;
   private String pollMessage;
   private String pollOptionsMessage;
   private String endTitle;
   private String endTextTitle;
   private String optionLine;
   private String progressBar;
   private String usagePoll;
   private String usagePollCreate;
   private String durationNumber;
   private String oneOption;
   private String usagePollVote;
   private String noPoll;
   private String invalidOptionPoll;
   private String votePoll;
   private String pollCreate;
   private String startTitle;
   private String startText;
   private String startOptionLine;
   private String startProgressBar;
   private String updateTitle;
   private String updateText;
   private String updateOptionLine;
   private String updateProgressBar;
   private String antiUnicode;
   private String levelUp;
   private String printUsage;
   private List<String> chatMessage;
   private String chatDisabledWorld;
   private String ignoreListEmpty;
   private String ignoreListMessage;
   private String usageWarning;
   private String usageAnnouncement;
   private String autoBroadcastUsage;
   private String autoBroadcastStart;
   private String autoBroadcastStop;
   private String autoBroadcastRestart;
   private String autoBroadcastUsageRemove;
   private String autoBroadcastRemove;
   private String autoBroadcastUsageAdd;
   private String autoBroadcastAddEnabled;
   private String autoBroadcastAddNewLine;
   private String autoBroadcastAddOneLine;
   private String autoBroadcastAddAdded;
   private String autoBroadcastActionsPrompt;
   private List<String> pluginMessage;
   private String pluginUsage;
   private String pluginNotFound;
   private String depurationChatCooldown;
   private String depurationCommandCooldown;
   private String usageBannedCommands;
   private String usageSendChannel;
   private String customCommandsArguments;
   private String usageBannedCommandsList;
   private String bannedCommandsNoCommandsBlocked;
   private String bannedCommandsBlockedList;
   private String bannedCommandsNoTabBlocked;
   private String bannedCommandsBlockedTabList;
   private String usageBannedCommandsAdd;
   private String bannedCommandsAlready;
   private String bannedCommandsAlreadyTab;
   private String bannedCommandsAdded;
   private String bannedCommandsAddedTab;
   private String usageBannedCommandsRemove;
   private String bannedCommandsNotBlocked;
   private String bannedCommandsNotBlockedTab;
   private String bannedCommandsRemoved;
   private String bannedCommandsRemovedTab;
   private String depurationAntiFlood;
   private String helpOp;
   private String usageHelpOp;
   private String usageCalculator;
   private String invalidOperator;
   private String divisionZero;
   private String calculatorResult;
   private String invalidNumber;
   private String invalidColor;
   private String colorReset;
   private String usagePlayer;
   private List<String> playerMessage;
   private List<String> playerMessageAdmin;
   private String otherPing;
   private List<String> serverMessage;
   private String usageSocialSpy;
   private String alreadyEnabledSpy;
   private String alreadyDisabledSpy;
   private String enabledSpy;
   private String disabledSpy;
   private String invalidModeSpy;
   private String modeSpy;
   private String usageCommandTimer;
   private String usageCommandTimerAdd;
   private String usageCommandTimerRemove;
   private String commandTimerAdded;
   private String commandTimerAlreadyAdded;
   private String commandTimerInvalidNumber;
   private String commandTimerRemoved;
   private String commandTimerNotExist;
   private String usageNick;
   private String usageNickSet;
   private String nickSet;
   private String nickRemove;
   private List<String> seen;
   private List<String> seenAdmin;
   private String usageSeen;
   private String usageRealName;
   private String noPlayerRealName;
   private String offlineRealName;
   private String realName;
   private String noStaff;
   private String headerStaffList;
   private String footerStaffList;
   private String usageBannedWords;
   private String usageBannedWordsAdd;
   private String usageBannedWordsRemove;
   private String bannedWordsNone;
   private String bannedWordsList;
   private String bannedWordsAdd;
   private String bannedWordsAlready;
   private String bannedWordsRemoved;
   private String bannedWordsUnknown;
   private String muted;
   private String muteUsage;
   private String mutePermanent;
   private String muteTemp;
   private String muteInvalidDuration;
   private String muteInvalidUnit;
   private String usageLogs;
   private String logsInvalid;
   private String logsNoRegister;
   private String logsHeader;
   private String cooldownChannel;
   private String invseeUsage;
   private String usageMention;
   private String mentionOther;
   private String meUsage;
   private String cgUsage;
   private String cgStart;
   private String cgStop;
   private String cgUsageAdd;
   private String cgAdd;
   private String cgUsageRemove;
   private String cgRemove;
   private String cgRestart;
   private String tagsUsage;
   private String tagsList;
   private String tagsUsageSelect;
   private String tagsNotFound;
   private String tagsSelected;
   private String ignoreBlacklist;
   private String channelFull;
   private String pollFinish;
   private String autoBroadcastToggleOn;
   private String autoBroadcastToggleOff;
   private String noItemInHand;
   private String invalidItemMeta;
   private String repeatCommands;
   private String usageReplacer;
   private String usageReplacerAdd;
   private String usageReplacerRemove;
   private String replacerHeader;
   private String replacerNoReplacements;
   private String replacerOriginal;
   private String replacerReplace;
   private String replacerPermission;
   private String replacerPermissionEnd;
   private String replacerAdded;
   private String replacerRemoved;
   private String replacerEnabled;
   private String replacerDisabled;
   private String usagePremade;
   private String broadcastPremadeNull;
   private String broadcastSent;

   public MessagesManager(OrdaChat plugin) {
      this.messagesFile = new ConfigFile(plugin.getConfigManager().getLangFile(), "lang", plugin);
      this.plugin = plugin;
      this.messagesFile.registerConfig();
      this.loadConfig();
      this.generateAdditionalFiles();
   }

   public void loadConfig() {
      FileConfiguration config = this.messagesFile.getConfig();
      boolean prefixEnabled = config.getBoolean("prefix.enabled");
      if (prefixEnabled) {
         this.prefix = config.getString("prefix.prefix");
      } else {
         this.prefix = "";
      }

      if (this.plugin.getConfigManager().isCooldownChat()) {
         this.cooldownChat = config.getString("messages.cooldown.chat", "&cPlease wait %cooldown% seconds before sending another message.");
         this.depurationChatCooldown = config.getString("messages.debug.chat-cooldown", "&cPlease wait %cooldown% seconds before executing another command.");
      }

      if (this.plugin.getConfigManager().isCooldownCommand()) {
         this.cooldownCommand = config.getString("messages.cooldown.command");
         this.depurationCommandCooldown = config.getString("messages.debug.command-cooldown");
      }

      if (this.plugin.getConfigManager().isAntibotEnabled()) {
         if (this.plugin.getConfigManager().isAntibotChat()) {
            this.antibotChat = config.getString("messages.antibot.antibot-chat");
         }

         if (this.plugin.getConfigManager().isAntibotCommand()) {
            this.antibotCommand = config.getString("messages.antibot.antibot-command");
         }

         if (this.plugin.getConfigManager().isAntibotJoin()) {
            this.antibotJoin = config.getString("messages.antibot.antibot-join");
         }

         if (this.plugin.getConfigManager().isAntibotMoved()) {
            this.antibotMoved = config.getString("messages.antibot.antibot-moved");
         }
      }

      if (this.plugin.getConfigManager().isUnicodeEnabled()) {
         this.antiUnicode = config.getString("messages.unicode");
      }

      this.usagePremade = config.getString("messages.usage.premade", "&cUsage: /premade broadcast <broadcast>");
      this.broadcastPremadeNull = config.getString("messages.broadcast-null", "&cBroadcast not found or is disabled.");
      this.broadcastSent = config.getString("messages.broadcast-sent", "&aBroadcast '%broadcast%' sent to all players.");
      if (this.plugin.getReplacerManager().getReplacerEnabled()) {
         this.replacerNoReplacements = config.getString("messages.replacer.no-replacements", "&cNo replacements found.");
         this.usageReplacer = config.getString("messages.usage.replacer", "&cUsage: /replacer <list/add/remove/enable/disable>");
         this.usageReplacerAdd = config.getString("messages.usage.replacer-add", "&cUsage: /replacer add <original> <replace> <permission>");
         this.usageReplacerRemove = config.getString("messages.usage.replacer-remove", "&cUsage: /replacer remove <original>");
         this.replacerAdded = config.getString("messages.replacer.added", "&aReplacement added: &e%original% &a-> &e%replacement%");
         this.replacerRemoved = config.getString("messages.replacer.removed", "&cReplacement removed: %original%");
         this.replacerEnabled = config.getString("messages.replacer.enabled", "&aReplacer enabled.");
         this.replacerDisabled = config.getString("messages.replacer.disabled", "&aReplacer disabled.");
         this.replacerHeader = config.getString("messages.replacer.replacements.header", "&aReplacements:");
         this.replacerOriginal = config.getString("messages.replacer.replacements.original", "&eOriginal: &f");
         this.replacerReplace = config.getString("messages.replacer.replacements.replace", "&e-> Replace: &f");
         this.replacerPermission = config.getString("messages.replacer.replacements.permission", "&e[Permission: §f");
         this.replacerPermissionEnd = config.getString("messages.replacer.replacements.permission-end", "&e]");
      }

      this.tagsUsage = config.getString("messages.usage.tags", "&cUsage: /tags list or /tags select <tag>");
      this.tagsUsageSelect = config.getString("messages.usage.tags-selected", "&cUsage: /tags select <tag>");
      this.tagsList = config.getString("messages.tags.list", "&aList of available tags:");
      this.tagsSelected = config.getString("messages.tags.selected", "&aYou have selected the tag: &e%tag%");
      this.tagsNotFound = config.getString("messages.tags.unknown", "&aThe tag '&e%tag%&a' does not exist.");
      if (this.plugin.getConfigManager().isFloodPercentEnabled() || this.plugin.getConfigManager().isFloodRepeatEnabled()) {
         this.antiFlood = config.getString("messages.anti-flood");
         if (this.plugin.getConfigManager().isDepurationAntiFloodEnabled()) {
            this.depurationAntiFlood = config.getString("messages.debug.anti-flood");
         }
      }

      if (this.plugin.getConfigManager().isBroadcastEnabled()) {
         this.broadcastUsage = config.getString("messages.usage.usage-broadcast");
      }

      if (this.plugin.getConfigManager().isMeEnabled()) {
         this.meUsage = config.getString("messages.usage.me", "&cUsage: /me <player>");
      }

      if (this.plugin.getConfigManager().isWarningEnabled()) {
         this.usageWarning = config.getString("messages.usage.usage-warning");
      }

      if (this.plugin.getConfigManager().isAnnouncementEnabled()) {
         this.usageAnnouncement = config.getString("messages.usage.usage-announcement");
      }

      if (this.plugin.getConfigManager().isPrintEnabled()) {
         this.printUsage = config.getString("messages.usage.usage-print");
      }

      this.cgUsage = config.getString("messages.usage.cg", "&cUsage: /chatgames <start|stop|restart|add|remove>");
      this.cgUsageAdd = config.getString("messages.usage.cg-add", "&cUsage: /chatgames add <name> <message1,message1,...> <keyword1,keyword2,...> <reward1,reward2,...>");
      this.cgUsageRemove = config.getString("messages.usage.cg-remove", "&cUsage: /chatgames remove <name>");
      this.cgAdd = config.getString("messages.chatgames.add", "&aThe game '&e%name%&a' has been added successfully.");
      this.cgRemove = config.getString("messages.chatgames.remove", "&aThe game '&e%name%&a' has been removed successfully.");
      this.cgRestart = config.getString("messages.chatgames.restart", "&eThe game has been restarted.");
      this.cgStart = config.getString("messages.chatgames.start", "&aThe game has started.");
      this.cgStop = config.getString("messages.chatgames.stop", "&aThe game has been stopped.");
      if (this.plugin.getConfigManager().isIgnoreEnabled()) {
         this.ignoreSelf = config.getString("messages.ignore.ignore-self");
         this.ignoreAlready = config.getString("messages.ignore.already-ignored");
         this.ignoreMessage = config.getString("messages.ignore.ignore");
         this.ignoreUsage = config.getString("messages.usage.usage-ignore");
         this.ignoreListMessage = config.getString("messages.ignore.ignore-list-message");
         this.ignoreListEmpty = config.getString("messages.ignore.ignore-list-empty");
         this.ignoreBlacklist = config.getString("messages.ignore.blacklist", "&cThe player '&4%player%&c' is blacklisted. You cannot ignore him.");
      }

      if (this.plugin.getConfigManager().isChatColorEnabled()) {
         this.colorReset = config.getString("messages.color-reset");
         this.invalidColor = config.getString("messages.invalid-color");
         this.colorSelectedMessage = config.getString("messages.color-selected");
         this.invalidIdMessage = config.getString("messages.invalid-id");
         this.formatSelectedMessage = config.getString("messages.format-selected");
      }

      if (this.plugin.getConfigManager().isPingEnabled()) {
         this.ping = config.getString("messages.ping");
         this.otherPing = config.getString("messages.other-ping");
      }

      if (this.plugin.getConfigManager().isSpyEnabled()) {
         this.usageSocialSpy = config.getString("messages.usage.usage-socialspy");
         this.alreadyEnabledSpy = config.getString("messages.socialspy.already-enabled");
         this.alreadyDisabledSpy = config.getString("messages.socialspy.already-disabled");
         this.enabledSpy = config.getString("messages.socialspy.enabled");
         this.disabledSpy = config.getString("messages.socialspy.disabled");
         this.modeSpy = config.getString("messages.socialspy.mode");
         this.invalidModeSpy = config.getString("messages.socialspy.invalid-mode");
      }

      if (this.plugin.getConfigManager().isAntiCapEnabled()) {
         this.antiCapMessage = config.getString("messages.anticap");
      }

      if (this.plugin.getBannedWordsManager().isEnabled()) {
         this.bannedWordsUnknown = config.getString("messages.bannedwords.unknown");
         this.bannedWordsAlready = config.getString("messages.bannedwords.already");
         this.bannedWordsList = config.getString("messages.bannedwords.list");
         this.bannedWordsNone = config.getString("messages.bannedwords.none");
         this.bannedWordsRemoved = config.getString("messages.bannedwords.removed");
         this.bannedWordsAdd = config.getString("messages.bannedwords.add");
         this.usageBannedWordsRemove = config.getString("messages.usage.bannedwords-remove");
         this.usageBannedWordsAdd = config.getString("messages.usage.bannedwords-add");
         this.usageBannedWords = config.getString("messages.usage.bannedwords");
      }

      if (this.plugin.getCommandTimerManager().isEnabled()) {
         this.commandTimerInvalidNumber = config.getString("messages.commandtimer.invalid-number");
         this.commandTimerRemoved = config.getString("messages.commandtimer.removed");
         this.commandTimerAdded = config.getString("messages.commandtimer.added");
         this.commandTimerAlreadyAdded = config.getString("messages.commandtimer.already-added");
         this.commandTimerNotExist = config.getString("messages.commandtimer.not-exist");
         this.usageCommandTimer = config.getString("messages.usage.usage-commandtimer");
         this.usageCommandTimerRemove = config.getString("messages.usage.usage-commandtimer-remove");
         this.usageCommandTimerAdd = config.getString("messages.usage.usage-commandtimer-add");
      }

      this.logsHeader = config.getString("messages.logs.header");
      this.logsInvalid = config.getString("messages.logs.invalid");
      this.logsNoRegister = config.getString("messages.logs.no-register");
      this.usageLogs = config.getString("messages.usage.logs");
      this.muted = config.getString("messages.muted");
      this.muteInvalidDuration = config.getString("messages.mute.invalid-duration");
      this.muteInvalidUnit = config.getString("messages.mute.invalid-unit");
      this.mutePermanent = config.getString("messages.mute.permanent");
      this.muteUsage = config.getString("messages.usage.mute");
      this.muteTemp = config.getString("messages.mute.temp");
      this.usageMention = config.getString("messages.usage.mention");
      this.mentionOther = config.getString("messages.mention-other");
      if (this.plugin.getLevelsManager().isEnabled()) {
         this.levelUp = config.getString("messages.level-up");
      }

      if (this.plugin.getConfigManager().isRepeatCommandsEnabled()) {
         this.repeatCommands = config.getString("messages.repeat-commands", "&cYou cannot send the same command.");
      }

      this.noItemInHand = config.getString("messages.no-item-in-hand", "&cYou do not have any items in hand.");
      this.invalidItemMeta = config.getString("messages.invalid-item-meta", "&cThe item has no meta.");
      this.headerStaffList = config.getString("messages.stafflist.header");
      this.footerStaffList = config.getString("messages.stafflist.footer");
      this.noStaff = config.getString("messages.no-staff");
      this.offlineRealName = config.getString("messages.realname.offline");
      this.noPlayerRealName = config.getString("messages.realname.no-player");
      this.realName = config.getString("messages.realname.realname");
      this.usageRealName = config.getString("messages.usage.usage-realname");
      this.usageSeen = config.getString("messages.usage.usage-seen");
      this.seen = config.getStringList("seen.player");
      this.seenAdmin = config.getStringList("seen.admin");
      this.nickRemove = config.getString("messages.nick.remove");
      this.nickSet = config.getString("messages.nick.set");
      this.usageNick = config.getString("messages.usage.usage-nick");
      this.usageNickSet = config.getString("messages.usage.usage-nick-set");
      this.serverMessage = config.getStringList("server");
      this.playerMessageAdmin = config.getStringList("player.admin");
      this.playerMessage = config.getStringList("player.global");
      this.usagePlayer = config.getString("messages.usage.usage-player");
      this.divisionZero = config.getString("messages.division-zero");
      this.invalidOperator = config.getString("messages.invalid-operator");
      this.invalidNumber = config.getString("messages.invalid-number");
      this.calculatorResult = config.getString("messages.calculator-result");
      this.usageCalculator = config.getString("messages.usage.usage-calculator");
      this.usageHelpOp = config.getString("messages.usage.usage-helpop");
      this.helpOp = config.getString("messages.helpop");
      this.bannedCommandsRemoved = config.getString("messages.bannedcommands.removed");
      this.bannedCommandsRemovedTab = config.getString("messages.bannedcommands.removed-tab");
      this.bannedCommandsNotBlocked = config.getString("messages.bannedcommands.not-blocked");
      this.bannedCommandsNotBlockedTab = config.getString("messages.bannedcommands.not-blocked-tab");
      this.usageBannedCommandsRemove = config.getString("messages.usage.usage-remove-bc");
      this.bannedCommandsAdded = config.getString("messages.bannedcommands.added");
      this.bannedCommandsAddedTab = config.getString("messages.bannedcommands.added-tab");
      this.bannedCommandsAlready = config.getString("messages.bannedcommands.already");
      this.bannedCommandsAlreadyTab = config.getString("messages.bannedcommands.already-tab");
      this.usageBannedCommandsAdd = config.getString("messages.usage.usage-add-bc");
      this.bannedCommandsBlockedList = config.getString("messages.bannedcommands.blocked-list");
      this.bannedCommandsBlockedTabList = config.getString("messages.bannedcommands.no-tab-blocked");
      this.bannedCommandsNoCommandsBlocked = config.getString("messages.bannedcommands.no-commands-blocked");
      this.bannedCommandsNoTabBlocked = config.getString("messages.bannedcommands.blocked-tab-list");
      this.usageBannedCommandsList = config.getString("messages.usage.usage-list-bannedcommands");
      this.customCommandsArguments = config.getString("messages.cc-arguments");
      this.usageSendChannel = config.getString("messages.usage.usage-send-channel");
      this.usageBannedCommands = config.getString("messages.usage.usage-bannedcommands");
      this.pluginNotFound = config.getString("messages.plugin-not-found");
      this.pluginUsage = config.getString("messages.usage.usage-plugin");
      this.pluginMessage = config.getStringList("plugin");
      this.autoBroadcastActionsPrompt = config.getString("messages.autobroadcast.create.actions-prompt");
      this.autoBroadcastAddOneLine = config.getString("messages.autobroadcast.create.one-line");
      this.autoBroadcastAddNewLine = config.getString("messages.autobroadcast.create.new-line");
      this.autoBroadcastAddAdded = config.getString("messages.autobroadcast.create.added");
      this.autoBroadcastAddEnabled = config.getString("messages.autobroadcast.create.enabled");
      this.autoBroadcastUsageRemove = config.getString("messages.autobroadcast.usage-remove");
      this.autoBroadcastUsageAdd = config.getString("messages.autobroadcast.usage-add");
      this.autoBroadcastStop = config.getString("messages.autobroadcast.stop");
      this.autoBroadcastStart = config.getString("messages.autobroadcast.start");
      this.autoBroadcastRestart = config.getString("messages.autobroadcast.restart");
      this.autoBroadcastRemove = config.getString("messages.autobroadcast.removed");
      this.autoBroadcastUsage = config.getString("messages.usage.usage-autobroadcast");
      this.autoBroadcastToggleOff = config.getString("messages.autobroadcast.toggle-off", "&cThe messages has been disabled.");
      this.autoBroadcastToggleOn = config.getString("messages.autobroadcast.toggle-on", "&aThe messages has been enabled.");
      this.chatDisabledWorld = config.getString("messages.chat-disabled-world");
      this.chatMessage = config.getStringList("messages.chat-help.message");
      this.updateProgressBar = config.getString("messages.poll.message.update.progress-bar");
      this.updateTitle = config.getString("messages.poll.message.update.title");
      this.updateText = config.getString("messages.poll.message.update.text");
      this.updateOptionLine = config.getString("messages.poll.message.update.option-line");
      this.startProgressBar = config.getString("messages.poll.message.start.progress-bar");
      this.startOptionLine = config.getString("messages.poll.message.start.option-line");
      this.startTitle = config.getString("messages.poll.message.start.title");
      this.startText = config.getString("messages.poll.message.start.text");
      this.pollCreate = config.getString("messages.poll-create");
      this.pollFinish = config.getString("messages.poll.finish", "&6[Poll] &aThe poll has finished!");
      this.votePoll = config.getString("messages.vote");
      this.invalidOptionPoll = config.getString("messages.invalid-option-poll");
      this.noPoll = config.getString("messages.no-poll");
      this.usagePollVote = config.getString("messages.usage.usage-poll-vote");
      this.oneOption = config.getString("messages.one-option");
      this.durationNumber = config.getString("messages.duration-number");
      this.usagePollCreate = config.getString("messages.usage.usage-poll-create");
      this.usagePoll = config.getString("messages.usage.usage-poll");
      this.optionLine = config.getString("messages.poll.message.end.option-line");
      this.progressBar = config.getString("messages.poll.message.end.progress-bar");
      this.endTextTitle = config.getString("messages.poll.message.end.text");
      this.endTitle = config.getString("messages.poll.message.end.title");
      this.pollOptionsMessage = config.getString("messages.poll.join.message-options");
      this.pollMessage = config.getString("messages.poll.join.message");
      this.customCommandsCooldown = config.getString("messages.custom-commands-cooldown");
      this.noEnabledGames = config.getString("messages.chatgames.no-enabled-games");
      this.noMessages = config.getString("messages.chatgames.no-messages");
      this.timeFinished = config.getString("messages.chatgames.time-finished");
      this.gameWin = config.getString("messages.chatgames.win");
      this.repeatMessage = config.getString("messages.repeat-message");
      this.chatUnmute = config.getString("messages.chat-unmute");
      this.chatMute = config.getString("messages.chat-mute");
      this.chatMuted = config.getString("messages.chat-muted");
      this.chatClearMessage = config.getString("messages.chat-clear");
      this.noReply = config.getString("messages.no-reply");
      this.usageMsg = config.getString("messages.usage.usage-msg");
      this.usageReply = config.getString("messages.usage.usage-reply");
      this.playerNotFound = config.getString("messages.player-not-found");
      this.noPermissionChannelLeft = config.getString("messages.channel.channel-no-permission-left");
      this.noChannel = config.getString("messages.channel.no-channel");
      this.channelLeftAnnounce = config.getString("messages.channel.left-channel-announce");
      this.channelJoinAnnounce = config.getString("messages.channel.join-channel-announce");
      this.channelJoin = config.getString("messages.channel.join-channel");
      this.channelLeft = config.getString("messages.channel.left-channel");
      this.channelAlready = config.getString("messages.channel.already-channel");
      this.channelNoPermissionJoin = config.getString("messages.channel.channel-no-permission-join");
      this.channelNotExist = config.getString("messages.channel.channel-not-exist");
      this.usageLeaveChannel = config.getString("messages.usage.leave-channel");
      this.usageJoinChannel = config.getString("messages.usage.join-channel");
      this.channelFull = config.getString("messages.channel.full", "&cThe channel '&e%channel%&c' is full (&a%players%&c/&e%limit%&c).");
      this.noPermission = config.getString("messages.no-permission");
      this.versionMessage = config.getString("messages.version-message");
      this.reloadMessage = config.getString("messages.reload-message");
      this.unknownMessage = config.getString("messages.unknown-command");
      this.usageChannel = config.getString("messages.usage.channel");
      this.cooldownChannel = config.getString("messages.cooldown-channel");
      this.invseeUsage = config.getString("messages.usage.invsee");
      this.materialNotFound = config.getString("messages.debug.material-not-found");
      this.noFormatGroup = config.getString("messages.debug.no-format-group");
      this.noPlayer = config.getString("messages.debug.no-player");
   }

   public void reloadConfig() {
      this.messagesFile = new ConfigFile(this.plugin.getConfigManager().getLangFile(), "lang", this.plugin);
      this.messagesFile.reloadConfig();
      this.loadConfig();
   }

   public void generateAdditionalFiles() {
      this.createConfigFile("messages_es.yml");
      this.createConfigFile("messages_en.yml");
   }

   private void createConfigFile(String fileName) {
      ConfigFile configFile = new ConfigFile(fileName, "lang", this.plugin);
      configFile.registerConfig();
   }

   public String getUsagePremade() {
      return this.usagePremade;
   }

   public String getBroadcastPremadeNull() {
      return this.broadcastPremadeNull;
   }

   public String getBroadcastSent() {
      return this.broadcastSent;
   }

   public String getUsageReplacer() {
      return this.usageReplacer;
   }

   public String getUsageReplacerAdd() {
      return this.usageReplacerAdd;
   }

   public String getUsageReplacerRemove() {
      return this.usageReplacerRemove;
   }

   public String getReplacerHeader() {
      return this.replacerHeader;
   }

   public String getReplacerNoReplacements() {
      return this.replacerNoReplacements;
   }

   public String getReplacerOriginal() {
      return this.replacerOriginal;
   }

   public String getReplacerReplace() {
      return this.replacerReplace;
   }

   public String getReplacerPermission() {
      return this.replacerPermission;
   }

   public String getReplacerPermissionEnd() {
      return this.replacerPermissionEnd;
   }

   public String getReplacerAdded() {
      return this.replacerAdded;
   }

   public String getReplacerRemoved() {
      return this.replacerRemoved;
   }

   public String getReplacerEnabled() {
      return this.replacerEnabled;
   }

   public String getReplacerDisabled() {
      return this.replacerDisabled;
   }

   public String getRepeatCommands() {
      return this.repeatCommands;
   }

   public String getNoItemInHand() {
      return this.noItemInHand;
   }

   public String getInvalidItemMeta() {
      return this.invalidItemMeta;
   }

   public String getAutoBroadcastToggleOn() {
      return this.autoBroadcastToggleOn;
   }

   public String getAutoBroadcastToggleOff() {
      return this.autoBroadcastToggleOff;
   }

   public String getPollFinish() {
      return this.pollFinish;
   }

   public String getChannelFull() {
      return this.channelFull;
   }

   public String getIgnoreBlacklist() {
      return this.ignoreBlacklist;
   }

   public String getTagsUsage() {
      return this.tagsUsage;
   }

   public String getTagsList() {
      return this.tagsList;
   }

   public String getTagsUsageSelect() {
      return this.tagsUsageSelect;
   }

   public String getTagsNotFound() {
      return this.tagsNotFound;
   }

   public String getTagsSelected() {
      return this.tagsSelected;
   }

   public String getCgUsage() {
      return this.cgUsage;
   }

   public String getCgStart() {
      return this.cgStart;
   }

   public String getCgStop() {
      return this.cgStop;
   }

   public String getCgUsageAdd() {
      return this.cgUsageAdd;
   }

   public String getCgAdd() {
      return this.cgAdd;
   }

   public String getCgUsageRemove() {
      return this.cgUsageRemove;
   }

   public String getCgRemove() {
      return this.cgRemove;
   }

   public String getCgRestart() {
      return this.cgRestart;
   }

   public String getMeUsage() {
      return this.meUsage;
   }

   public String getUsageMention() {
      return this.usageMention;
   }

   public String getMentionOther() {
      return this.mentionOther;
   }

   public String getInvseeUsage() {
      return this.invseeUsage;
   }

   public String getCooldownChannel() {
      return this.cooldownChannel;
   }

   public String getUsageLogs() {
      return this.usageLogs;
   }

   public String getLogsInvalid() {
      return this.logsInvalid;
   }

   public String getLogsNoRegister() {
      return this.logsNoRegister;
   }

   public String getLogsHeader() {
      return this.logsHeader;
   }

   public String getMuteUsage() {
      return this.muteUsage;
   }

   public String getMutePermanent() {
      return this.mutePermanent;
   }

   public String getMuteTemp() {
      return this.muteTemp;
   }

   public String getMuteInvalidDuration() {
      return this.muteInvalidDuration;
   }

   public String getMuteInvalidUnit() {
      return this.muteInvalidUnit;
   }

   public String getMuted() {
      return this.muted;
   }

   public String getBannedWordsAdd() {
      return this.bannedWordsAdd;
   }

   public String getBannedWordsNone() {
      return this.bannedWordsNone;
   }

   public String getBannedWordsList() {
      return this.bannedWordsList;
   }

   public String getBannedWordsAlready() {
      return this.bannedWordsAlready;
   }

   public String getBannedWordsRemoved() {
      return this.bannedWordsRemoved;
   }

   public String getBannedWordsUnknown() {
      return this.bannedWordsUnknown;
   }

   public String getUsageBannedWordsRemove() {
      return this.usageBannedWordsRemove;
   }

   public String getUsageBannedWordsAdd() {
      return this.usageBannedWordsAdd;
   }

   public String getUsageBannedWords() {
      return this.usageBannedWords;
   }

   public String getFooterStaffList() {
      return this.footerStaffList;
   }

   public String getHeaderStaffList() {
      return this.headerStaffList;
   }

   public String getNoStaff() {
      return this.noStaff;
   }

   public String getRealName() {
      return this.realName;
   }

   public String getOfflineRealName() {
      return this.offlineRealName;
   }

   public String getNoPlayerRealName() {
      return this.noPlayerRealName;
   }

   public String getUsageRealName() {
      return this.usageRealName;
   }

   public String getUsageSeen() {
      return this.usageSeen;
   }

   public List<String> getSeenAdmin() {
      return this.seenAdmin;
   }

   public List<String> getSeen() {
      return this.seen;
   }

   public String getNickRemove() {
      return this.nickRemove;
   }

   public String getNickSet() {
      return this.nickSet;
   }

   public String getUsageNickSet() {
      return this.usageNickSet;
   }

   public String getUsageNick() {
      return this.usageNick;
   }

   public String getCommandTimerNotExist() {
      return this.commandTimerNotExist;
   }

   public String getCommandTimerRemoved() {
      return this.commandTimerRemoved;
   }

   public String getCommandTimerAlreadyAdded() {
      return this.commandTimerAlreadyAdded;
   }

   public String getCommandTimerAdded() {
      return this.commandTimerAdded;
   }

   public String getCommandTimerInvalidNumber() {
      return this.commandTimerInvalidNumber;
   }

   public String getUsageCommandTimerRemove() {
      return this.usageCommandTimerRemove;
   }

   public String getUsageCommandTimerAdd() {
      return this.usageCommandTimerAdd;
   }

   public String getUsageCommandTimer() {
      return this.usageCommandTimer;
   }

   public String getInvalidModeSpy() {
      return this.invalidModeSpy;
   }

   public String getModeSpy() {
      return this.modeSpy;
   }

   public String getAlreadyEnabledSpy() {
      return this.alreadyEnabledSpy;
   }

   public String getAlreadyDisabledSpy() {
      return this.alreadyDisabledSpy;
   }

   public String getDisabledSpy() {
      return this.disabledSpy;
   }

   public String getEnabledSpy() {
      return this.enabledSpy;
   }

   public String getUsageSocialSpy() {
      return this.usageSocialSpy;
   }

   public List<String> getServerMessage() {
      return this.serverMessage;
   }

   public String getOtherPing() {
      return this.otherPing;
   }

   public List<String> getPlayerMessageAdmin() {
      return this.playerMessageAdmin;
   }

   public List<String> getPlayerMessage() {
      return this.playerMessage;
   }

   public String getUsagePlayer() {
      return this.usagePlayer;
   }

   public String getColorReset() {
      return this.colorReset;
   }

   public String getInvalidColor() {
      return this.invalidColor;
   }

   public String getInvalidNumber() {
      return this.invalidNumber;
   }

   public String getCalculatorResult() {
      return this.calculatorResult;
   }

   public String getDivisionZero() {
      return this.divisionZero;
   }

   public String getInvalidOperator() {
      return this.invalidOperator;
   }

   public String getUsageCalculator() {
      return this.usageCalculator;
   }

   public String getUsageHelpOp() {
      return this.usageHelpOp;
   }

   public String getHelpOp() {
      return this.helpOp;
   }

   public String getDepurationAntiFlood() {
      return this.depurationAntiFlood;
   }

   public String getBannedCommandsNotBlocked() {
      return this.bannedCommandsNotBlocked;
   }

   public String getBannedCommandsNotBlockedTab() {
      return this.bannedCommandsNotBlockedTab;
   }

   public String getBannedCommandsRemoved() {
      return this.bannedCommandsRemoved;
   }

   public String getBannedCommandsRemovedTab() {
      return this.bannedCommandsRemovedTab;
   }

   public String getUsageBannedCommandsRemove() {
      return this.usageBannedCommandsRemove;
   }

   public String getBannedCommandsAddedTab() {
      return this.bannedCommandsAddedTab;
   }

   public String getBannedCommandsAdded() {
      return this.bannedCommandsAdded;
   }

   public String getBannedCommandsAlreadyTab() {
      return this.bannedCommandsAlreadyTab;
   }

   public String getBannedCommandsAlready() {
      return this.bannedCommandsAlready;
   }

   public String getUsageBannedCommandsAdd() {
      return this.usageBannedCommandsAdd;
   }

   public String getBannedCommandsNoCommandsBlocked() {
      return this.bannedCommandsNoCommandsBlocked;
   }

   public String getBannedCommandsBlockedList() {
      return this.bannedCommandsBlockedList;
   }

   public String getBannedCommandsNoTabBlocked() {
      return this.bannedCommandsNoTabBlocked;
   }

   public String getBannedCommandsBlockedTabList() {
      return this.bannedCommandsBlockedTabList;
   }

   public String getUsageBannedCommandsList() {
      return this.usageBannedCommandsList;
   }

   public String getCustomCommandsArguments() {
      return this.customCommandsArguments;
   }

   public String getUsageSendChannel() {
      return this.usageSendChannel;
   }

   public String getUsageBannedCommands() {
      return this.usageBannedCommands;
   }

   public String getPluginNotFound() {
      return this.pluginNotFound;
   }

   public String getPluginUsage() {
      return this.pluginUsage;
   }

   public List<String> getPluginMessage() {
      return this.pluginMessage;
   }

   public String getAutoBroadcastActionsPrompt() {
      return this.autoBroadcastActionsPrompt;
   }

   public String getAutoBroadcastAddAdded() {
      return this.autoBroadcastAddAdded;
   }

   public String getAutoBroadcastAddOneLine() {
      return this.autoBroadcastAddOneLine;
   }

   public String getAutoBroadcastAddNewLine() {
      return this.autoBroadcastAddNewLine;
   }

   public String getAutoBroadcastAddEnabled() {
      return this.autoBroadcastAddEnabled;
   }

   public String getAutoBroadcastUsageAdd() {
      return this.autoBroadcastUsageAdd;
   }

   public String getAutoBroadcastRemove() {
      return this.autoBroadcastRemove;
   }

   public String getAutoBroadcastUsageRemove() {
      return this.autoBroadcastUsageRemove;
   }

   public String getAutoBroadcastRestart() {
      return this.autoBroadcastRestart;
   }

   public String getAutoBroadcastStop() {
      return this.autoBroadcastStop;
   }

   public String getAutoBroadcastStart() {
      return this.autoBroadcastStart;
   }

   public String getAutoBroadcastUsage() {
      return this.autoBroadcastUsage;
   }

   public String getUsageAnnouncement() {
      return this.usageAnnouncement;
   }

   public String getUsageWarning() {
      return this.usageWarning;
   }

   public String getIgnoreListMessage() {
      return this.ignoreListMessage;
   }

   public String getIgnoreListEmpty() {
      return this.ignoreListEmpty;
   }

   public String getChatDisabledWorld() {
      return this.chatDisabledWorld;
   }

   public List<String> getChatMessage() {
      return this.chatMessage;
   }

   public String getPrintUsage() {
      return this.printUsage;
   }

   public String getLevelUp() {
      return this.levelUp;
   }

   public String getAntiUnicode() {
      return this.antiUnicode;
   }

   public String getUpdateProgressBar() {
      return this.updateProgressBar;
   }

   public String getUpdateOptionLine() {
      return this.updateOptionLine;
   }

   public String getUpdateText() {
      return this.updateText;
   }

   public String getUpdateTitle() {
      return this.updateTitle;
   }

   public String getStartProgressBar() {
      return this.startProgressBar;
   }

   public String getStartOptionLine() {
      return this.startOptionLine;
   }

   public String getStartText() {
      return this.startText;
   }

   public String getStartTitle() {
      return this.startTitle;
   }

   public String getPollCreate() {
      return this.pollCreate;
   }

   public String getVotePoll() {
      return this.votePoll;
   }

   public String getInvalidOptionPoll() {
      return this.invalidOptionPoll;
   }

   public String getNoPoll() {
      return this.noPoll;
   }

   public String getUsagePollVote() {
      return this.usagePollVote;
   }

   public String getOneOption() {
      return this.oneOption;
   }

   public String getDurationNumber() {
      return this.durationNumber;
   }

   public String getUsagePollCreate() {
      return this.usagePollCreate;
   }

   public String getUsagePoll() {
      return this.usagePoll;
   }

   public String getProgressBar() {
      return this.progressBar;
   }

   public String getOptionLine() {
      return this.optionLine;
   }

   public String getEndTextTitle() {
      return this.endTextTitle;
   }

   public String getEndTitle() {
      return this.endTitle;
   }

   public String getPollOptionsMessage() {
      return this.pollOptionsMessage;
   }

   public String getPollMessage() {
      return this.pollMessage;
   }

   public String getIgnoreMessage() {
      return this.ignoreMessage;
   }

   public String getIgnoreAlready() {
      return this.ignoreAlready;
   }

   public String getIgnoreSelf() {
      return this.ignoreSelf;
   }

   public String getIgnoreUsage() {
      return this.ignoreUsage;
   }

   public String getBroadcastUsage() {
      return this.broadcastUsage;
   }

   public String getPing() {
      return this.ping;
   }

   public String getCustomCommandsCooldown() {
      return this.customCommandsCooldown;
   }

   public String getAntiFlood() {
      return this.antiFlood;
   }

   public String getCooldownCommand() {
      return this.cooldownCommand;
   }

   public String getCooldownChat() {
      return this.cooldownChat;
   }

   public String getGameWin() {
      return this.gameWin;
   }

   public String getTimeFinished() {
      return this.timeFinished;
   }

   public String getNoEnabledGames() {
      return this.noEnabledGames;
   }

   public String getNoMessages() {
      return this.noMessages;
   }

   public String getAntibotMoved() {
      return this.antibotMoved;
   }

   public String getAntibotJoin() {
      return this.antibotJoin;
   }

   public String getAntibotCommand() {
      return this.antibotCommand;
   }

   public String getAntibotChat() {
      return this.antibotChat;
   }

   public String getRepeatMessage() {
      return this.repeatMessage;
   }

   public String getChatUnmute() {
      return this.chatUnmute;
   }

   public String getChatMute() {
      return this.chatMute;
   }

   public String getChatMuted() {
      return this.chatMuted;
   }

   public String getChatClearMessage() {
      return this.chatClearMessage;
   }

   public String getNoReply() {
      return this.noReply;
   }

   public String getUsageReply() {
      return this.usageReply;
   }

   public String getUsageMsg() {
      return this.usageMsg;
   }

   public String getPlayerNotFound() {
      return this.playerNotFound;
   }

   public String getNoPermissionChannelLeft() {
      return this.noPermissionChannelLeft;
   }

   public String getNoChannel() {
      return this.noChannel;
   }

   public String getChannelJoinAnnounce() {
      return this.channelJoinAnnounce;
   }

   public String getChannelLeftAnnounce() {
      return this.channelLeftAnnounce;
   }

   public String getChannelJoin() {
      return this.channelJoin;
   }

   public String getChannelLeft() {
      return this.channelLeft;
   }

   public String getChannelAlready() {
      return this.channelAlready;
   }

   public String getChannelNoPermissionJoin() {
      return this.channelNoPermissionJoin;
   }

   public String getChannelNotExist() {
      return this.channelNotExist;
   }

   public String getUsageLeaveChannel() {
      return this.usageLeaveChannel;
   }

   public String getUsageJoinChannel() {
      return this.usageJoinChannel;
   }

   public String getUsageChannel() {
      return this.usageChannel;
   }

   public String getInvalidIdMessage() {
      return this.invalidIdMessage;
   }

   public String getFormatSelectedMessage() {
      return this.formatSelectedMessage;
   }

   public String getColorSelectedMessage() {
      return this.colorSelectedMessage;
   }

   public String getVersionMessage() {
      return this.versionMessage;
   }

   public String getNoPermission() {
      return this.noPermission;
   }

   public String getReloadMessage() {
      return this.reloadMessage;
   }

   public String getUnknownMessage() {
      return this.unknownMessage;
   }

   public String getPrefix() {
      return this.prefix;
   }

   public String getAntiCapMessage() {
      return this.antiCapMessage;
   }

   public String getDepurationCommandCooldown() {
      return this.depurationCommandCooldown;
   }

   public String getDepurationChatCooldown() {
      return this.depurationChatCooldown;
   }

   public String getMaterialNotFound() {
      return this.materialNotFound;
   }

   public String getNoPlayer() {
      return this.noPlayer;
   }

   public String getNoFormatGroup() {
      return this.noFormatGroup;
   }
}
