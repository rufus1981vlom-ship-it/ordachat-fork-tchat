package config;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import minealex.tchat.OrdaChat;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.jetbrains.annotations.Nullable;

public class TagsMenuConfigManager {
   private final ConfigFile configFile;
   private final Map<String, TagsMenuConfigManager.MenuConfig> menus = new HashMap();
   private boolean enabled;
   private String dmenu;

   public TagsMenuConfigManager(OrdaChat plugin) {
      this.configFile = new ConfigFile("tags_menus.yml", "menus", plugin);
      this.configFile.registerConfig();
      this.loadConfig();
   }

   public void loadConfig() {
      this.menus.clear();
      FileConfiguration config = this.configFile.getConfig();
      this.enabled = config.getBoolean("options.enabled", false);
      if (this.enabled) {
         this.dmenu = config.getString("options.default_menu", "menu1");
         ConfigurationSection menusSection = config.getConfigurationSection("menus");
         if (menusSection != null) {
            Iterator var3 = menusSection.getKeys(false).iterator();

            while(true) {
               String menuName;
               ConfigurationSection menuSection;
               do {
                  if (!var3.hasNext()) {
                     return;
                  }

                  menuName = (String)var3.next();
                  menuSection = menusSection.getConfigurationSection(menuName);
               } while(menuSection == null);

               String title = menuSection.getString("title", "Menu");
               int size = menuSection.getInt("size", 27);
               Map<Integer, TagsMenuConfigManager.MenuItem> items = new HashMap();
               ConfigurationSection itemsSection = menuSection.getConfigurationSection("items");
               if (itemsSection != null) {
                  Iterator var10 = itemsSection.getKeys(false).iterator();

                  while(var10.hasNext()) {
                     String slotKey = (String)var10.next();
                     int slot = Integer.parseInt(slotKey);
                     ConfigurationSection itemSection = itemsSection.getConfigurationSection(slotKey);
                     if (itemSection != null) {
                        String material = itemSection.getString("material", "STONE");
                        String name = itemSection.getString("name", "");
                        List<String> lore = itemSection.getStringList("lore");
                        List<String> commands = itemSection.getStringList("commands");
                        String nextMenu = itemSection.getString("open_menu", (String)null);
                        TagsMenuConfigManager.MenuItem menuItem = new TagsMenuConfigManager.MenuItem(material, name, lore, commands, nextMenu);
                        items.put(slot, menuItem);
                     }
                  }
               }

               TagsMenuConfigManager.MenuConfig menuConfig = new TagsMenuConfigManager.MenuConfig(title, size, items);
               this.menus.put(menuName, menuConfig);
            }
         }
      }

   }

   public void reloadConfig() {
      this.configFile.reloadConfig();
      this.loadConfig();
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public String getDmenu() {
      return this.dmenu;
   }

   @Nullable
   public TagsMenuConfigManager.MenuConfig getMenu(String name) {
      return (TagsMenuConfigManager.MenuConfig)this.menus.get(name);
   }

   @Nullable
   public TagsMenuConfigManager.MenuConfig getMenuByTitle(String title) {
      Iterator var2 = this.menus.values().iterator();

      TagsMenuConfigManager.MenuConfig menuConfig;
      do {
         if (!var2.hasNext()) {
            return null;
         }

         menuConfig = (TagsMenuConfigManager.MenuConfig)var2.next();
      } while(!menuConfig.getTitle().equalsIgnoreCase(title));

      return menuConfig;
   }

   public static class MenuItem {
      private final String material;
      private final String name;
      private final List<String> lore;
      private final List<String> commands;
      private final String nextMenu;

      public MenuItem(String material, String name, List<String> lore, List<String> commands, String nextMenu) {
         this.material = material;
         this.name = name;
         this.lore = lore;
         this.commands = commands;
         this.nextMenu = nextMenu;
      }

      public String getMaterial() {
         return this.material;
      }

      public String getName() {
         return this.name;
      }

      public List<String> getLore() {
         return this.lore;
      }

      public List<String> getCommands() {
         return this.commands;
      }

      public String getNextMenu() {
         return this.nextMenu;
      }
   }

   public static class MenuConfig {
      private final String title;
      private final int size;
      private final Map<Integer, TagsMenuConfigManager.MenuItem> items;

      public MenuConfig(String title, int size, Map<Integer, TagsMenuConfigManager.MenuItem> items) {
         this.title = title;
         this.size = size;
         this.items = items;
      }

      public String getTitle() {
         return this.title;
      }

      public int getSize() {
         return this.size;
      }

      public Map<Integer, TagsMenuConfigManager.MenuItem> getItems() {
         return this.items;
      }
   }
}
