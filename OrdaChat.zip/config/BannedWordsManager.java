package config;

import java.io.File;
import java.util.List;
import minealex.tchat.OrdaChat;
import org.bukkit.Particle;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.jetbrains.annotations.NotNull;

public class BannedWordsManager {
   private final OrdaChat plugin;
   private final File bannedWordsFile;
   private boolean enabled;
   private List<String> bannedWords;
   private List<String> whitelist;
   private String type;
   private List<String> blockedMessages;
   private boolean titleEnabled;
   private String title;
   private String subTitle;
   private boolean actionBarEnabled;
   private String actionBar;
   private boolean soundEnabled;
   private String sound;
   private String bypassPermission;
   private boolean particlesEnabled;
   private Particle particle;
   private int particles;
   private boolean discordEnabled;
   private String discordURL;

   public BannedWordsManager(@NotNull OrdaChat plugin) {
      this.plugin = plugin;
      this.bannedWordsFile = new File(plugin.getDataFolder(), "banned_words.yml");
      if (!this.bannedWordsFile.exists()) {
         plugin.saveResource("banned_words.yml", false);
      }

      this.loadBannedWords();
   }

   public void reloadBannedWords() {
      this.loadBannedWords();
   }

   public void loadBannedWords() {
      FileConfiguration bannedWordsConfig = YamlConfiguration.loadConfiguration(this.bannedWordsFile);
      this.enabled = bannedWordsConfig.getBoolean("options.enabled", true);
      if (this.enabled) {
         this.bannedWords = bannedWordsConfig.getStringList("bannedWords");
         this.whitelist = bannedWordsConfig.getStringList("whitelist");
         this.type = bannedWordsConfig.getString("type");
         this.blockedMessages = bannedWordsConfig.getStringList("blockedMessage");
         this.titleEnabled = bannedWordsConfig.getBoolean("title.enabled");
         if (this.titleEnabled) {
            this.title = bannedWordsConfig.getString("title.title");
            this.subTitle = bannedWordsConfig.getString("title.subtitle");
         }

         this.actionBarEnabled = bannedWordsConfig.getBoolean("actionbar.enabled");
         if (this.actionBarEnabled) {
            this.actionBar = bannedWordsConfig.getString("actionbar.bar");
         }

         this.soundEnabled = bannedWordsConfig.getBoolean("sound.enabled");
         if (this.soundEnabled) {
            this.sound = bannedWordsConfig.getString("sound.sound");
         }

         this.bypassPermission = bannedWordsConfig.getString("bypass.permission");
         this.particlesEnabled = bannedWordsConfig.getBoolean("particles.enabled");
         if (this.particlesEnabled) {
            this.particle = Particle.valueOf(bannedWordsConfig.getString("particles.particle"));
            this.particles = bannedWordsConfig.getInt("particles.particles");
         }

         this.discordEnabled = bannedWordsConfig.getBoolean("discord.enabled", false);
         if (this.discordEnabled) {
            this.discordURL = bannedWordsConfig.getString("discord.webhook");
         }
      }

   }

   public void saveBannedWords() {
      FileConfiguration bannedWordsConfig = YamlConfiguration.loadConfiguration(this.bannedWordsFile);
      bannedWordsConfig.set("bannedWords", this.bannedWords);

      try {
         bannedWordsConfig.save(this.bannedWordsFile);
      } catch (Exception var3) {
         this.plugin.getLogger().severe("Error saving banned words [BannedWordsManager.java]");
         var3.printStackTrace();
      }

   }

   public boolean isDiscordEnabled() {
      return this.discordEnabled;
   }

   public String getDiscordURL() {
      return this.discordURL;
   }

   public List<String> getWhitelist() {
      return this.whitelist;
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public int getParticles() {
      return this.particles;
   }

   public Particle getParticle() {
      return this.particle;
   }

   public boolean isParticlesEnabled() {
      return this.particlesEnabled;
   }

   public String getBypassPermission() {
      return this.bypassPermission;
   }

   public String getSound() {
      return this.sound;
   }

   public boolean getSoundEnabled() {
      return this.soundEnabled;
   }

   public String getActionBar() {
      return this.actionBar;
   }

   public boolean getActionBarEnabled() {
      return this.actionBarEnabled;
   }

   public List<String> getBannedWords() {
      return this.bannedWords;
   }

   public String getType() {
      return this.type;
   }

   public List<String> getBlockedMessages() {
      return this.blockedMessages;
   }

   public boolean getTitleEnabled() {
      return this.titleEnabled;
   }

   public String getTitle() {
      return this.title;
   }

   public String getSubTitle() {
      return this.subTitle;
   }

   public TChat getPlugin() {
      return this.plugin;
   }
}
