package config;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import minealex.tchat.OrdaChat;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.jetbrains.annotations.NotNull;

public class ChatGamesManager {
   private final List<ChatGamesManager.Game> games = new ArrayList();
   private final ConfigFile configFile;
   private final OrdaChat plugin;

   public ChatGamesManager(OrdaChat plugin) {
      this.plugin = plugin;
      this.configFile = new ConfigFile("chatgames.yml", (String)null, plugin);
      this.configFile.registerConfig();
      this.loadGames();
   }

   private void loadGames() {
      FileConfiguration config = this.configFile.getConfig();
      if (config.contains("games")) {
         Iterator var2 = ((ConfigurationSection)Objects.requireNonNull(config.getConfigurationSection("games"))).getKeys(false).iterator();

         while(var2.hasNext()) {
            String key = (String)var2.next();
            boolean enabled = config.getBoolean("games." + key + ".enabled", false);
            if (enabled) {
               List<String> messages = config.getStringList("games." + key + ".messages");
               boolean hoverEnabled = config.getBoolean("games." + key + ".hover.enabled");
               List<String> hover = config.getStringList("games." + key + ".hover.lines");
               boolean actionEnabled = config.getBoolean("games." + key + ".action.enabled");
               String action = config.getString("games." + key + ".action.action");
               List<String> keywords = config.getStringList("games." + key + ".keywords");
               List<String> rewards = config.getStringList("games." + key + ".rewards");
               int endTime = config.getInt("games." + key + ".options.endTime");
               int time = config.getInt("games." + key + ".options.time");
               ChatGamesManager.Effects startEffects = this.loadEffects(config, "games." + key + ".startEffects");
               ChatGamesManager.Effects endEffects = this.loadEffects(config, "games." + key + ".endEffects");
               ChatGamesManager.Effects winnerEffects = this.loadEffects(config, "games." + key + ".winnerEffects");
               ChatGamesManager.Game game = new ChatGamesManager.Game(messages, hoverEnabled, hover, actionEnabled, action, keywords, rewards, new ChatGamesManager.Options(endTime, time), enabled, startEffects, endEffects, winnerEffects);
               this.games.add(game);
            }
         }
      } else {
         this.plugin.getLogger().warning("No games found in the chatgames.yml file.");
      }

   }

   @NotNull
   private ChatGamesManager.Effects loadEffects(@NotNull FileConfiguration config, String path) {
      boolean titleEnabled = config.getBoolean(path + ".title.enabled", false);
      String titleText = config.getString(path + ".title.text", "");
      String subtitleText = config.getString(path + ".title.subtitle", "");
      int fadeIn = config.getInt(path + ".title.fadeIn", 10);
      int stay = config.getInt(path + ".title.stay", 70);
      int fadeOut = config.getInt(path + ".title.fadeOut", 20);
      boolean soundEnabled = config.getBoolean(path + ".sound.enabled", false);
      String soundName = config.getString(path + ".sound.name", "ENTITY_PLAYER_LEVELUP");
      float volume = (float)config.getDouble(path + ".sound.volume", 1.0D);
      float pitch = (float)config.getDouble(path + ".sound.pitch", 1.0D);
      boolean particleEnabled = config.getBoolean(path + ".particle.enabled", false);
      String particleName = config.getString(path + ".particle.name", "EXPLOSION_NORMAL");
      int particleCount = config.getInt(path + ".particle.count", 10);
      double speed = config.getDouble(path + ".particle.speed", 1.0D);
      boolean actionBarEnabled = config.getBoolean(path + ".actionBar.enabled", false);
      String actionBarText = config.getString(path + ".actionBar.text", "");
      return new ChatGamesManager.Effects(new ChatGamesManager.Title(titleEnabled, titleText, subtitleText, fadeIn, stay, fadeOut), new ChatGamesManager.SoundEffect(soundEnabled, soundName, volume, pitch), new ChatGamesManager.ParticleEffect(particleEnabled, particleName, particleCount, speed), new ChatGamesManager.ActionBar(actionBarEnabled, actionBarText));
   }

   public void reloadConfig() {
      this.games.clear();
      this.configFile.reloadConfig();
      this.loadGames();
   }

   public List<ChatGamesManager.Game> getGames() {
      return this.games;
   }

   public void addGame(String name, List<String> messages, List<String> keywords, List<String> rewards, ChatGamesManager.Options options, ChatGamesManager.Effects startEffects, ChatGamesManager.Effects endEffects, ChatGamesManager.Effects winnerEffects) {
      ChatGamesManager.Game newGame = new ChatGamesManager.Game(messages, false, new ArrayList(), false, "", keywords, rewards, options, true, startEffects, endEffects, winnerEffects);
      this.games.add(newGame);
      FileConfiguration config = this.configFile.getConfig();
      String path = "games." + name;
      config.set(path + ".enabled", true);
      config.set(path + ".messages", messages);
      config.set(path + ".keywords", keywords);
      config.set(path + ".rewards", rewards);
      config.set(path + ".options.endTime", options.getEndTime());
      config.set(path + ".options.time", options.getTime());
      this.saveEffects(config, path + ".startEffects", startEffects);
      this.saveEffects(config, path + ".endEffects", endEffects);
      this.saveEffects(config, path + ".winnerEffects", winnerEffects);
      this.configFile.saveConfig();
   }

   public void removeGame(String name) {
      this.games.removeIf((game) -> {
         return game.getKeywords().contains(name);
      });
      FileConfiguration config = this.configFile.getConfig();
      config.set("games." + name, (Object)null);
      this.configFile.saveConfig();
   }

   private void saveEffects(@NotNull FileConfiguration config, String path, @NotNull ChatGamesManager.Effects effects) {
      config.set(path + ".title.enabled", effects.getTitle().isEnabled());
      config.set(path + ".title.text", effects.getTitle().getText());
      config.set(path + ".title.subtitle", effects.getTitle().getSubtitle());
      config.set(path + ".title.fadeIn", effects.getTitle().getFadeIn());
      config.set(path + ".title.stay", effects.getTitle().getStay());
      config.set(path + ".title.fadeOut", effects.getTitle().getFadeOut());
      config.set(path + ".sound.enabled", effects.getSound().isEnabled());
      config.set(path + ".sound.name", effects.getSound().getName());
      config.set(path + ".sound.volume", effects.getSound().getVolume());
      config.set(path + ".sound.pitch", effects.getSound().getPitch());
      config.set(path + ".particle.enabled", effects.getParticle().isEnabled());
      config.set(path + ".particle.name", effects.getParticle().getName());
      config.set(path + ".particle.count", effects.getParticle().getCount());
      config.set(path + ".particle.speed", effects.getParticle().getSpeed());
      config.set(path + ".actionBar.enabled", effects.getActionBar().isEnabled());
      config.set(path + ".actionBar.text", effects.getActionBar().getText());
   }

   public static class Effects {
      private final ChatGamesManager.Title title;
      private final ChatGamesManager.SoundEffect sound;
      private final ChatGamesManager.ParticleEffect particle;
      private final ChatGamesManager.ActionBar actionBar;

      public Effects(ChatGamesManager.Title title, ChatGamesManager.SoundEffect sound, ChatGamesManager.ParticleEffect particle, ChatGamesManager.ActionBar actionBar) {
         this.title = title;
         this.sound = sound;
         this.particle = particle;
         this.actionBar = actionBar;
      }

      public ChatGamesManager.Title getTitle() {
         return this.title;
      }

      public ChatGamesManager.SoundEffect getSound() {
         return this.sound;
      }

      public ChatGamesManager.ParticleEffect getParticle() {
         return this.particle;
      }

      public ChatGamesManager.ActionBar getActionBar() {
         return this.actionBar;
      }
   }

   public static class Game {
      private final List<String> messages;
      private final boolean hoverEnabled;
      private final List<String> hover;
      private final boolean actionEnabled;
      private final String action;
      private final List<String> keywords;
      private final List<String> rewards;
      private final ChatGamesManager.Options options;
      private final boolean enabled;
      private final ChatGamesManager.Effects startEffects;
      private final ChatGamesManager.Effects endEffects;
      private final ChatGamesManager.Effects winnerEffects;

      public Game(List<String> messages, boolean hoverEnabled, List<String> hover, boolean actionEnabled, String action, List<String> keywords, List<String> rewards, ChatGamesManager.Options options, boolean enabled, ChatGamesManager.Effects startEffects, ChatGamesManager.Effects endEffects, ChatGamesManager.Effects winnerEffects) {
         this.messages = messages;
         this.hoverEnabled = hoverEnabled;
         this.hover = hover;
         this.actionEnabled = actionEnabled;
         this.action = action;
         this.keywords = keywords;
         this.rewards = rewards;
         this.options = options;
         this.enabled = enabled;
         this.startEffects = startEffects;
         this.endEffects = endEffects;
         this.winnerEffects = winnerEffects;
      }

      public List<String> getMessages() {
         return this.messages;
      }

      public boolean isHoverEnabled() {
         return this.hoverEnabled;
      }

      public List<String> getHover() {
         return this.hover;
      }

      public boolean isActionEnabled() {
         return this.actionEnabled;
      }

      public String getAction() {
         return this.action;
      }

      public List<String> getKeywords() {
         return this.keywords;
      }

      public List<String> getRewards() {
         return this.rewards;
      }

      public ChatGamesManager.Options getOptions() {
         return this.options;
      }

      public boolean isEnabled() {
         return this.enabled;
      }

      public ChatGamesManager.Effects getStartEffects() {
         return this.startEffects;
      }

      public ChatGamesManager.Effects getEndEffects() {
         return this.endEffects;
      }

      public ChatGamesManager.Effects getWinnerEffects() {
         return this.winnerEffects;
      }
   }

   public static class Options {
      private final int endTime;
      private final int time;

      public Options(int endTime, int time) {
         this.endTime = endTime;
         this.time = time;
      }

      public int getEndTime() {
         return this.endTime;
      }

      public int getTime() {
         return this.time;
      }
   }

   public static class Title {
      private final boolean enabled;
      private final String text;
      private final String subtitle;
      private final int fadeIn;
      private final int stay;
      private final int fadeOut;

      public Title(boolean enabled, String text, String subtitle, int fadeIn, int stay, int fadeOut) {
         this.enabled = enabled;
         this.text = text;
         this.subtitle = subtitle;
         this.fadeIn = fadeIn;
         this.stay = stay;
         this.fadeOut = fadeOut;
      }

      public boolean isEnabled() {
         return this.enabled;
      }

      public String getText() {
         return this.text;
      }

      public String getSubtitle() {
         return this.subtitle;
      }

      public int getFadeIn() {
         return this.fadeIn;
      }

      public int getStay() {
         return this.stay;
      }

      public int getFadeOut() {
         return this.fadeOut;
      }
   }

   public static class SoundEffect {
      private final boolean enabled;
      private final String name;
      private final float volume;
      private final float pitch;

      public SoundEffect(boolean enabled, String name, float volume, float pitch) {
         this.enabled = enabled;
         this.name = name;
         this.volume = volume;
         this.pitch = pitch;
      }

      public boolean isEnabled() {
         return this.enabled;
      }

      public String getName() {
         return this.name;
      }

      public float getVolume() {
         return this.volume;
      }

      public float getPitch() {
         return this.pitch;
      }
   }

   public static class ParticleEffect {
      private final boolean enabled;
      private final String name;
      private final int count;
      private final double speed;

      public ParticleEffect(boolean enabled, String name, int count, double speed) {
         this.enabled = enabled;
         this.name = name;
         this.count = count;
         this.speed = speed;
      }

      public boolean isEnabled() {
         return this.enabled;
      }

      public String getName() {
         return this.name;
      }

      public int getCount() {
         return this.count;
      }

      public double getSpeed() {
         return this.speed;
      }
   }

   public static class ActionBar {
      private final boolean enabled;
      private final String text;

      public ActionBar(boolean enabled, String text) {
         this.enabled = enabled;
         this.text = text;
      }

      public boolean isEnabled() {
         return this.enabled;
      }

      public String getText() {
         return this.text;
      }
   }
}
