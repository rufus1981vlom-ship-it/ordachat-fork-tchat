package config;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import minealex.tchat.OrdaChat;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

public class DeathManager {
   private final ConfigFile configFile;
   private final Map<String, DeathManager.DeathMessage> deathMessages = new HashMap();
   private boolean titleEnabled;
   private String title;
   private String subtitle;
   private boolean actionBarEnabled;
   private String actionBarText;
   private boolean soundEnabled;
   private String sound;
   private boolean particlesEnabled;
   private String particle;
   private int numberOfParticles;

   public DeathManager(OrdaChat plugin) {
      this.configFile = new ConfigFile("death.yml", (String)null, plugin);
      this.configFile.registerConfig();
      this.loadConfig();
   }

   public void loadConfig() {
      FileConfiguration config = this.configFile.getConfig();
      ConfigurationSection actionsConfig;
      if (config.contains("death-messages")) {
         actionsConfig = config.getConfigurationSection("death-messages");
         Iterator var3 = ((ConfigurationSection)Objects.requireNonNull(actionsConfig)).getKeys(false).iterator();

         while(var3.hasNext()) {
            String key = (String)var3.next();
            boolean enabled = actionsConfig.getBoolean(key + ".enabled", false);
            String message = actionsConfig.getString(key + ".message");
            if (message != null && enabled) {
               this.deathMessages.put(key, new DeathManager.DeathMessage(enabled, message));
            }
         }
      }

      if (config.contains("actions")) {
         actionsConfig = config.getConfigurationSection("actions");

         assert actionsConfig != null;

         this.titleEnabled = actionsConfig.getBoolean("title.enabled");
         this.title = actionsConfig.getString("title.title");
         this.subtitle = actionsConfig.getString("title.subtitle");
         this.actionBarEnabled = actionsConfig.getBoolean("actionBar.enabled");
         this.actionBarText = actionsConfig.getString("actionBar.bar");
         this.soundEnabled = actionsConfig.getBoolean("sound.enabled");
         this.sound = actionsConfig.getString("sound.sound");
         this.particlesEnabled = actionsConfig.getBoolean("particles.enabled");
         this.particle = actionsConfig.getString("particles.particle");
         this.numberOfParticles = actionsConfig.getInt("particles.particles");
      }

   }

   public void reloadConfig() {
      this.configFile.reloadConfig();
      this.loadConfig();
   }

   public String getDeathMessage(String key) {
      DeathManager.DeathMessage deathMessage = (DeathManager.DeathMessage)this.deathMessages.get(key);
      return deathMessage != null && deathMessage.enabled() ? deathMessage.message() : null;
   }

   public boolean isTitleEnabled() {
      return this.titleEnabled;
   }

   public String getTitle() {
      return this.title;
   }

   public String getSubtitle() {
      return this.subtitle;
   }

   public boolean isActionBarEnabled() {
      return this.actionBarEnabled;
   }

   public String getActionBarText() {
      return this.actionBarText;
   }

   public boolean isSoundEnabled() {
      return this.soundEnabled;
   }

   public String getSound() {
      return this.sound;
   }

   public boolean isParticlesEnabled() {
      return this.particlesEnabled;
   }

   public String getParticle() {
      return this.particle;
   }

   public int getNumberOfParticles() {
      return this.numberOfParticles;
   }

   public static record DeathMessage(boolean enabled, String message) {
      public DeathMessage(boolean enabled, String message) {
         this.enabled = enabled;
         this.message = message;
      }

      public boolean enabled() {
         return this.enabled;
      }

      public String message() {
         return this.message;
      }
   }
}
