package config;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import minealex.tchat.OrdaChat;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

public class CommandsManager {
   private final OrdaChat plugin;
   private final ConfigFile configFile;
   private final Map<String, CommandsManager.Command> commands;

   public CommandsManager(OrdaChat plugin) {
      this.plugin = plugin;
      this.configFile = new ConfigFile("commands.yml", (String)null, plugin);
      this.configFile.registerConfig();
      this.commands = new HashMap();
      this.loadConfig();
   }

   public void loadConfig() {
      FileConfiguration config = this.configFile.getConfig();
      this.commands.clear();
      if (config.contains("commands")) {
         Set<String> commandKeys = ((ConfigurationSection)Objects.requireNonNull(config.getConfigurationSection("commands"))).getKeys(false);
         Iterator var3 = commandKeys.iterator();

         while(var3.hasNext()) {
            String key = (String)var3.next();
            boolean permissionRequired = config.getBoolean("commands." + key + ".permission-required", false);
            List<String> actions = config.getStringList("commands." + key + ".actions");
            int cooldown = config.getInt("commands." + key + ".cooldown", 0);
            boolean args = config.getBoolean("commands." + key + ".args");
            this.commands.put(key, new CommandsManager.Command(permissionRequired, actions, cooldown, args));
         }
      }

   }

   public void reloadConfig() {
      this.configFile.reloadConfig();
      this.loadConfig();
   }

   public Map<String, CommandsManager.Command> getCommands() {
      return this.commands;
   }

   public TChat getPlugin() {
      return this.plugin;
   }

   public static record Command(boolean permissionRequired, List<String> actions, int cooldown, boolean args) {
      public Command(boolean permissionRequired, List<String> actions, int cooldown, boolean args) {
         this.permissionRequired = permissionRequired;
         this.actions = actions;
         this.cooldown = cooldown;
         this.args = args;
      }

      public boolean permissionRequired() {
         return this.permissionRequired;
      }

      public List<String> actions() {
         return this.actions;
      }

      public int cooldown() {
         return this.cooldown;
      }

      public boolean args() {
         return this.args;
      }
   }
}
