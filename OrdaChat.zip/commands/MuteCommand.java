package commands;

import config.SaveManager;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import minealex.tchat.OrdaChat;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class MuteCommand implements CommandExecutor {
   private final OrdaChat plugin;
   private final SaveManager saveManager;

   public MuteCommand(@NotNull OrdaChat plugin) {
      this.plugin = plugin;
      this.saveManager = plugin.getSaveManager();
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      String m;
      if (!sender.hasPermission("tchat.admin.mute")) {
         m = this.plugin.getMessagesManager().getNoPermission();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + m));
         return true;
      } else if (args.length < 1) {
         m = this.plugin.getMessagesManager().getMuteUsage();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + m));
         return true;
      } else {
         Player target = Bukkit.getPlayer(args[0]);
         if (target == null) {
            String m = this.plugin.getMessagesManager().getPlayerNotFound();
            sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + m));
            return true;
         } else {
            UUID targetId = target.getUniqueId();
            if (args.length == 1) {
               this.saveManager.mutePlayer(targetId, -1L);
               String m = this.plugin.getMessagesManager().getMutePermanent().replace("%player%", target.getName());
               sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + m));
            } else {
               try {
                  long duration = this.parseDuration(args[1]);
                  this.saveManager.mutePlayer(targetId, duration);
                  String m = this.plugin.getMessagesManager().getMuteTemp().replace("%player%", target.getName()).replace("%time%", args[1]);
                  sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + m));
               } catch (IllegalArgumentException var11) {
                  String m = this.plugin.getMessagesManager().getMuteInvalidDuration();
                  sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + m));
               }
            }

            if (this.plugin.getDiscordManager().isMuteEnabled()) {
               this.plugin.getDiscordHook().sendMuteEmbed(target.getName(), sender.getName(), this.plugin.getDiscordManager().getMuteWebhook());
            }

            return true;
         }
      }
   }

   private long parseDuration(@NotNull String duration) throws IllegalArgumentException {
      char timeUnit = duration.charAt(duration.length() - 1);
      long timeValue = Long.parseLong(duration.substring(0, duration.length() - 1));
      String p = this.plugin.getMessagesManager().getPrefix();
      String m = this.plugin.getMessagesManager().getMuteInvalidUnit();
      long var10000;
      switch(timeUnit) {
      case 'M':
         var10000 = TimeUnit.DAYS.toMillis(timeValue * 30L);
         break;
      case 'd':
         var10000 = TimeUnit.DAYS.toMillis(timeValue);
         break;
      case 'h':
         var10000 = TimeUnit.HOURS.toMillis(timeValue);
         break;
      case 'm':
         var10000 = TimeUnit.MINUTES.toMillis(timeValue);
         break;
      case 's':
         var10000 = TimeUnit.SECONDS.toMillis(timeValue);
         break;
      case 'w':
         var10000 = TimeUnit.DAYS.toMillis(timeValue * 7L);
         break;
      default:
         throw new IllegalArgumentException(this.plugin.getTranslateColors().translateColors((Player)null, p + m));
      }

      return var10000;
   }
}
