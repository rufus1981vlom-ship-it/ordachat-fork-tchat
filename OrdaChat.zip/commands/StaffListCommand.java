package commands;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import minealex.tchat.OrdaChat;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class StaffListCommand implements CommandExecutor {
   private final OrdaChat plugin;

   public StaffListCommand(OrdaChat plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      String message;
      if (!(sender instanceof Player)) {
         message = this.plugin.getMessagesManager().getNoPlayer();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
         return true;
      } else {
         Player player = (Player)sender;
         if (!sender.hasPermission("tchat.command.stafflist")) {
            message = this.plugin.getMessagesManager().getNoPermission();
            sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
            return true;
         } else {
            List<String> staffList = new ArrayList();
            Iterator var8 = Bukkit.getOnlinePlayers().iterator();

            while(true) {
               Player p;
               do {
                  if (!var8.hasNext()) {
                     if (staffList.isEmpty()) {
                        String message = this.plugin.getMessagesManager().getNoStaff();
                        sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
                        return true;
                     }

                     int staffCount = staffList.size();
                     String header = this.plugin.getMessagesManager().getHeaderStaffList().replace("%staff%", String.valueOf(staffCount));
                     String footer = this.plugin.getMessagesManager().getFooterStaffList();
                     String staffNames = ChatColor.GREEN + String.join(ChatColor.WHITE + ", " + ChatColor.GREEN, staffList);
                     sender.sendMessage(header);
                     sender.sendMessage(staffNames);
                     sender.sendMessage(footer);
                     return true;
                  }

                  p = (Player)var8.next();
               } while(!p.hasPermission("tchat.admin") && !p.hasPermission("tchat.staff") && !p.isOp());

               staffList.add(p.getName());
            }
         }
      }
   }
}
