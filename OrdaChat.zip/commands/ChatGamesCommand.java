package commands;

import config.ChatGamesManager;
import java.util.Arrays;
import minealex.tchat.OrdaChat;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import utils.ChatGamesSender;

public class ChatGamesCommand implements CommandExecutor {
   private final OrdaChat plugin;
   private final ChatGamesSender chatGamesSender;
   private final ChatGamesManager chatGamesManager;

   public ChatGamesCommand(OrdaChat plugin, ChatGamesSender chatGamesSender, ChatGamesManager chatGamesManager) {
      this.plugin = plugin;
      this.chatGamesSender = chatGamesSender;
      this.chatGamesManager = chatGamesManager;
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, String[] args) {
      String p = this.plugin.getMessagesManager().getPrefix();
      String u;
      if (sender instanceof Player) {
         Player player = (Player)sender;
         if (!player.hasPermission("tchat.admin") && !player.hasPermission("tchat.admin.chatgames")) {
            u = this.plugin.getMessagesManager().getNoPermission();
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, p + u));
            return true;
         } else if (args.length == 0) {
            u = this.plugin.getMessagesManager().getCgUsage();
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, p + u));
            return true;
         } else {
            u = args[0].toLowerCase();
            byte var8 = -1;
            switch(u.hashCode()) {
            case -934610812:
               if (u.equals("remove")) {
                  var8 = 4;
               }
               break;
            case 96417:
               if (u.equals("add")) {
                  var8 = 3;
               }
               break;
            case 3540994:
               if (u.equals("stop")) {
                  var8 = 1;
               }
               break;
            case 109757538:
               if (u.equals("start")) {
                  var8 = 0;
               }
               break;
            case 1097506319:
               if (u.equals("restart")) {
                  var8 = 2;
               }
            }

            switch(var8) {
            case 0:
               this.chatGamesSender.startNextGame();
               String s = this.plugin.getMessagesManager().getCgStart();
               player.sendMessage(this.plugin.getTranslateColors().translateColors(player, p + s));
               break;
            case 1:
               this.chatGamesSender.stopGame();
               String m = this.plugin.getMessagesManager().getCgStop();
               player.sendMessage(this.plugin.getTranslateColors().translateColors(player, p + m));
               break;
            case 2:
               this.chatGamesSender.restartGame();
               String r = this.plugin.getMessagesManager().getCgRestart();
               player.sendMessage(this.plugin.getTranslateColors().translateColors(player, p + r));
               break;
            case 3:
               this.handleAddGameCommand(player, args);
               break;
            case 4:
               this.handleRemoveGameCommand(player, args);
               break;
            default:
               String u = this.plugin.getMessagesManager().getCgUsage();
               player.sendMessage(this.plugin.getTranslateColors().translateColors(player, p + u));
            }

            return true;
         }
      } else {
         u = this.plugin.getMessagesManager().getNoPlayer();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, p + u));
         return true;
      }
   }

   private void handleAddGameCommand(Player player, @NotNull String[] args) {
      String p = this.plugin.getMessagesManager().getPrefix();
      String name;
      if (args.length < 4) {
         name = this.plugin.getMessagesManager().getCgUsageAdd();
         player.sendMessage(this.plugin.getTranslateColors().translateColors(player, p + name));
      } else {
         name = args[1];
         String[] messagesArray = args[2].split(",");
         String[] keywordsArray = args[3].split(",");
         String[] rewardsArray = args.length >= 5 ? args[4].split(",") : new String[0];
         ChatGamesManager.Options options = new ChatGamesManager.Options(60, 30);
         ChatGamesManager.Title startTitle = new ChatGamesManager.Title(true, "&aThe game starts!", "", 10, 70, 20);
         ChatGamesManager.SoundEffect startSound = new ChatGamesManager.SoundEffect(true, "ENTITY_PLAYER_LEVELUP", 1.0F, 1.0F);
         ChatGamesManager.ParticleEffect startParticle = new ChatGamesManager.ParticleEffect(true, "FIREWORKS_SPARK", 10, 1.0D);
         ChatGamesManager.ActionBar startActionBar = new ChatGamesManager.ActionBar(true, "&bStarting game!");
         ChatGamesManager.Title endTitle = new ChatGamesManager.Title(true, "&cThe Game ended!", "", 10, 70, 20);
         ChatGamesManager.SoundEffect endSound = new ChatGamesManager.SoundEffect(true, "ENTITY_ENDER_DRAGON_DEATH", 1.0F, 1.0F);
         ChatGamesManager.ParticleEffect endParticle = new ChatGamesManager.ParticleEffect(true, "EXPLOSION_LARGE", 10, 1.0D);
         ChatGamesManager.ActionBar endActionBar = new ChatGamesManager.ActionBar(true, "&cGame over");
         ChatGamesManager.Title winnerTitle = new ChatGamesManager.Title(true, "&cGame over!", "", 10, 70, 20);
         ChatGamesManager.SoundEffect winnerSound = new ChatGamesManager.SoundEffect(true, "ENTITY_VILLAGER_YES", 1.0F, 1.0F);
         ChatGamesManager.ParticleEffect winnerParticle = new ChatGamesManager.ParticleEffect(true, "HEART", 10, 1.0D);
         ChatGamesManager.ActionBar winnerActionBar = new ChatGamesManager.ActionBar(true, "&a%winner% has won the game!");
         ChatGamesManager.Effects startEffects = new ChatGamesManager.Effects(startTitle, startSound, startParticle, startActionBar);
         ChatGamesManager.Effects endEffects = new ChatGamesManager.Effects(endTitle, endSound, endParticle, endActionBar);
         ChatGamesManager.Effects winnerEffects = new ChatGamesManager.Effects(winnerTitle, winnerSound, winnerParticle, winnerActionBar);
         this.chatGamesManager.addGame(name, Arrays.asList(messagesArray), Arrays.asList(keywordsArray), Arrays.asList(rewardsArray), options, startEffects, endEffects, winnerEffects);
         this.chatGamesManager.reloadConfig();
         String m = this.plugin.getMessagesManager().getCgAdd().replace("%name%", name);
         player.sendMessage(this.plugin.getTranslateColors().translateColors(player, p + m));
      }
   }

   private void handleRemoveGameCommand(Player player, @NotNull String[] args) {
      String p = this.plugin.getMessagesManager().getPrefix();
      String name;
      if (args.length < 2) {
         name = this.plugin.getMessagesManager().getCgUsageRemove();
         player.sendMessage(this.plugin.getTranslateColors().translateColors(player, p + name));
      } else {
         name = args[1];
         this.chatGamesManager.removeGame(name);
         this.chatGamesManager.reloadConfig();
         String m = this.plugin.getMessagesManager().getCgRemove().replace("%name%", name);
         player.sendMessage(this.plugin.getTranslateColors().translateColors(player, p + m));
      }
   }
}
