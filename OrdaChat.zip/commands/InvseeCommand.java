package commands;

import config.InvseeConfigManager;
import minealex.tchat.OrdaChat;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.NotNull;

public class InvseeCommand implements CommandExecutor, Listener {
   private final OrdaChat plugin;
   private final InvseeConfigManager configManager;

   public InvseeCommand(@NotNull OrdaChat plugin) {
      this.plugin = plugin;
      this.configManager = new InvseeConfigManager(plugin);
      plugin.getServer().getPluginManager().registerEvents(this, plugin);
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
      String p = this.plugin.getMessagesManager().getPrefix();
      String m;
      if (sender instanceof Player) {
         Player player = (Player)sender;
         if (!player.hasPermission("tchat.admin") && !player.hasPermission("tchat.command.invsee")) {
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, p + this.plugin.getMessagesManager().getNoPermission()));
            return true;
         } else if (args.length != 1) {
            m = this.plugin.getMessagesManager().getInvseeUsage();
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, p + m));
            return true;
         } else {
            Player target = Bukkit.getPlayer(args[0]);
            if (target == null) {
               String m = this.plugin.getMessagesManager().getPlayerNotFound();
               player.sendMessage(this.plugin.getTranslateColors().translateColors(player, p + m));
               return true;
            } else {
               this.showInventory(target, player);
               return true;
            }
         }
      } else {
         m = this.plugin.getMessagesManager().getNoPlayer();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, p + m));
         return true;
      }
   }

   @EventHandler
   public void onInventoryClick(@NotNull InventoryClickEvent event) {
      HumanEntity var3 = event.getWhoClicked();
      if (var3 instanceof Player) {
         Player player = (Player)var3;
         String playerName = player.getName();
         String title = this.plugin.getTranslateColors().translateColors(player, this.configManager.getInventoryTitle().replace("%player%", playerName));
         if (event.getView().getTitle().startsWith(title)) {
            event.setCancelled(true);
         }
      }

   }

   private void showInventory(@NotNull Player p, Player v) {
      String title = this.plugin.getTranslateColors().translateColors(p, this.configManager.getInventoryTitle().replace("%player%", p.getName()));
      Inventory tempInventory = Bukkit.createInventory((InventoryHolder)null, this.configManager.getSlots(), title);
      ItemStack[] items = p.getInventory().getContents();
      tempInventory.setContents(items);
      ItemStack[] armor = p.getInventory().getArmorContents();
      ItemStack glass = this.configManager.getGlass();
      glass = this.translateItemStack(glass, p);
      int[] var8 = this.configManager.getGlassSlots();
      int i = var8.length;

      for(int var10 = 0; var10 < i; ++var10) {
         int slot = var8[var10];
         tempInventory.setItem(slot, glass);
      }

      ItemStack empty = this.configManager.getBarrier();
      empty = this.translateItemStack(empty, p);

      for(i = 0; i < this.configManager.getArmorLength(); ++i) {
         ItemStack armorItem = armor[this.configManager.getArmorLength() - 1 - i];
         if (armorItem != null && armorItem.getType() != Material.AIR) {
            armorItem = this.translateItemStack(armorItem, p);
            tempInventory.setItem(this.configManager.getArmorStartSlot() + i, armorItem);
         } else {
            tempInventory.setItem(this.configManager.getArmorStartSlot() + i, empty);
         }
      }

      ItemStack offHandItem = p.getInventory().getItemInOffHand();
      offHandItem = this.translateItemStack(offHandItem, p);
      tempInventory.setItem(this.configManager.getOffhandSlot(), offHandItem.getType() != Material.AIR ? offHandItem : empty);
      v.openInventory(tempInventory);
   }

   private ItemStack translateItemStack(ItemStack itemStack, Player player) {
      if (itemStack != null && itemStack.getItemMeta() != null) {
         ItemMeta itemMeta = itemStack.getItemMeta();
         if (itemMeta != null && itemMeta.hasDisplayName()) {
            String translatedName = this.plugin.getTranslateColors().translateColors(player, itemMeta.getDisplayName());
            itemMeta.setDisplayName(translatedName);
            itemStack.setItemMeta(itemMeta);
         }

         return itemStack;
      } else {
         return itemStack;
      }
   }
}
