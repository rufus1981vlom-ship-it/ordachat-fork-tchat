package commands;

import java.util.Iterator;
import minealex.tchat.OrdaChat;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class SeenCommand implements CommandExecutor {
   private final OrdaChat plugin;

   public SeenCommand(OrdaChat plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(@NotNull CommandSender commandSender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      String playerName;
      if (!commandSender.hasPermission("tchat.admin") && !commandSender.hasPermission("tchat.command.seen") && !commandSender.hasPermission("tchat.admin.command.seen")) {
         playerName = this.plugin.getMessagesManager().getNoPermission();
         commandSender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + playerName));
      }

      if (args.length != 1) {
         playerName = this.plugin.getMessagesManager().getUsageSeen();
         commandSender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + playerName));
         return false;
      } else {
         playerName = args[0];
         Player player = Bukkit.getPlayerExact(playerName);
         if (player == null) {
            String message = this.plugin.getMessagesManager().getNoPlayer();
            commandSender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
            return false;
         } else {
            Iterator var8 = this.plugin.getMessagesManager().getSeen().iterator();

            String m;
            while(var8.hasNext()) {
               m = (String)var8.next();
               commandSender.sendMessage(this.plugin.getTranslateColors().translateColors(player, m));
            }

            if (commandSender.hasPermission("tchat.admin") || commandSender.hasPermission("tchat.admin.command.seen")) {
               var8 = this.plugin.getMessagesManager().getSeenAdmin().iterator();

               while(var8.hasNext()) {
                  m = (String)var8.next();
                  commandSender.sendMessage(this.plugin.getTranslateColors().translateColors(player, m));
               }
            }

            return true;
         }
      }
   }
}
