package commands;

import config.ConfigManager;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import minealex.tchat.OrdaChat;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.ComponentBuilder;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.chat.HoverEvent.Action;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import utils.TranslateColors;

public class ReplyCommand implements CommandExecutor {
   private final PrivateMessageCommand privateMessageCommand;
   private final OrdaChat plugin;

   public ReplyCommand(OrdaChat plugin, PrivateMessageCommand privateMessageCommand) {
      this.plugin = plugin;
      this.privateMessageCommand = privateMessageCommand;
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, String[] args) {
      Player senderPlayer = (Player)sender;
      String prefix = this.plugin.getMessagesManager().getPrefix();
      TranslateColors translateColors = this.plugin.getTranslateColors();
      String message;
      if (!senderPlayer.hasPermission(this.plugin.getConfigManager().getReplyPermission()) && !senderPlayer.hasPermission("tchat.admin")) {
         message = this.plugin.getMessagesManager().getNoPermission();
         senderPlayer.sendMessage(translateColors.translateColors(senderPlayer, prefix + message));
      } else {
         if (args.length < 1) {
            message = this.plugin.getMessagesManager().getUsageReply();
            sender.sendMessage(translateColors.translateColors(senderPlayer, prefix + message));
            return true;
         }

         UUID lastMessagedUUID = (UUID)this.privateMessageCommand.getLastMessaged().get(senderPlayer.getUniqueId());
         if (lastMessagedUUID == null) {
            String message = this.plugin.getMessagesManager().getNoReply();
            sender.sendMessage(translateColors.translateColors(senderPlayer, prefix + message));
            return true;
         }

         Player targetPlayer = Bukkit.getPlayer(lastMessagedUUID);
         if (targetPlayer == null) {
            String message = this.plugin.getMessagesManager().getPlayerNotFound();
            sender.sendMessage(translateColors.translateColors(senderPlayer, prefix + message));
            return true;
         }

         StringBuilder messageBuilder = new StringBuilder();
         String[] var11 = args;
         int var12 = args.length;

         String senderGroup;
         for(int var13 = 0; var13 < var12; ++var13) {
            senderGroup = var11[var13];
            messageBuilder.append(senderGroup).append(" ");
         }

         String messageToSend = messageBuilder.toString().trim();
         String senderFormattedMessage = translateColors.translateColors(senderPlayer, this.plugin.getConfigManager().getReplyFormatSender().replace("%sender%", sender.getName()).replace("%recipient%", targetPlayer.getName()).replace("%message%", messageToSend));
         String receiverFormattedMessage = translateColors.translateColors(targetPlayer, this.plugin.getConfigManager().getReplyFormatReceiver().replace("%sender%", sender.getName()).replace("%recipient%", targetPlayer.getName()).replace("%message%", messageToSend));
         senderGroup = this.plugin.getGroupManager().getGroupName(senderPlayer);
         String receiverGroup = this.plugin.getGroupManager().getGroupName(targetPlayer);
         ConfigManager.HoverConfig senderHoverConfig = this.plugin.getConfigManager().getReplyHoverConfig(senderGroup);
         ConfigManager.HoverConfig receiverHoverConfig = this.plugin.getConfigManager().getReplyHoverConfig(receiverGroup);
         List<String> hoverSenderTextList = senderHoverConfig != null ? (List)senderHoverConfig.getSenderTexts().stream().map((line) -> {
            return translateColors.translateColors(senderPlayer, line);
         }).collect(Collectors.toList()) : List.of("No hover found (sender)");
         String hoverSenderText = String.join("\n", hoverSenderTextList);
         String senderAction = senderHoverConfig != null ? senderHoverConfig.getSenderAction() : null;
         TextComponent senderMessage = new TextComponent((new ComponentBuilder(senderFormattedMessage)).create());
         senderMessage.setHoverEvent(new HoverEvent(Action.SHOW_TEXT, (new ComponentBuilder(hoverSenderText)).create()));
         if (senderAction != null && !senderAction.isEmpty()) {
            this.applyClickEvent(senderMessage, senderAction);
         }

         List<String> hoverReceiverTextList = receiverHoverConfig != null ? (List)receiverHoverConfig.getReceiverTexts().stream().map((line) -> {
            return translateColors.translateColors(targetPlayer, line);
         }).collect(Collectors.toList()) : List.of("No hover found (receiver)");
         String hoverReceiverText = String.join("\n", hoverReceiverTextList);
         String receiverAction = receiverHoverConfig != null ? receiverHoverConfig.getReceiverAction() : null;
         TextComponent receiverMessage = new TextComponent((new ComponentBuilder(receiverFormattedMessage)).create());
         receiverMessage.setHoverEvent(new HoverEvent(Action.SHOW_TEXT, (new ComponentBuilder(hoverReceiverText)).create()));
         if (receiverAction != null && !receiverAction.isEmpty()) {
            this.applyClickEvent(receiverMessage, receiverAction);
         }

         senderPlayer.spigot().sendMessage(senderMessage);
         targetPlayer.spigot().sendMessage(receiverMessage);
      }

      return true;
   }

   private void applyClickEvent(TextComponent message, @NotNull String action) {
      String url;
      if (action.startsWith("[SUGGEST]")) {
         url = action.substring(10);
         message.setClickEvent(new ClickEvent(net.md_5.bungee.api.chat.ClickEvent.Action.SUGGEST_COMMAND, url));
      } else if (action.startsWith("[EXECUTE]")) {
         url = action.substring(10);
         message.setClickEvent(new ClickEvent(net.md_5.bungee.api.chat.ClickEvent.Action.RUN_COMMAND, url));
      } else if (action.startsWith("[OPEN]")) {
         url = action.substring(7);
         message.setClickEvent(new ClickEvent(net.md_5.bungee.api.chat.ClickEvent.Action.OPEN_URL, url));
      }

   }
}
