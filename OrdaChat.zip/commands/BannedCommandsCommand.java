package commands;

import config.BannedCommandsManager;
import java.util.Iterator;
import java.util.List;
import minealex.tchat.OrdaChat;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class BannedCommandsCommand implements CommandExecutor {
   private final BannedCommandsManager bannedCommandsManager;
   private final OrdaChat plugin;

   public BannedCommandsCommand(BannedCommandsManager bannedCommandsManager, OrdaChat plugin) {
      this.bannedCommandsManager = bannedCommandsManager;
      this.plugin = plugin;
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      String subCommand;
      if (!sender.hasPermission("tchat.admin") && !sender.hasPermission("tchat.admin.bannedcommands")) {
         subCommand = this.plugin.getMessagesManager().getNoPermission();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + subCommand));
         return true;
      } else if (args.length == 0) {
         subCommand = this.plugin.getMessagesManager().getUsageBannedCommands();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + subCommand));
         return true;
      } else {
         subCommand = args[0];
         String var7 = subCommand.toLowerCase();
         byte var8 = -1;
         switch(var7.hashCode()) {
         case -934610812:
            if (var7.equals("remove")) {
               var8 = 2;
            }
            break;
         case 96417:
            if (var7.equals("add")) {
               var8 = 1;
            }
            break;
         case 3322014:
            if (var7.equals("list")) {
               var8 = 0;
            }
         }

         switch(var8) {
         case 0:
            this.handleListCommand(sender, args);
            break;
         case 1:
            this.handleAddCommand(sender, args);
            break;
         case 2:
            this.handleRemoveCommand(sender, args);
            break;
         default:
            String message = this.plugin.getMessagesManager().getUsageBannedCommands();
            sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
         }

         return true;
      }
   }

   private void handleListCommand(CommandSender sender, String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      String message = this.plugin.getMessagesManager().getUsageBannedCommandsList();
      if (args.length < 2) {
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
      } else {
         String listType = args[1];
         String var6 = listType.toLowerCase();
         byte var7 = -1;
         switch(var6.hashCode()) {
         case 114581:
            if (var6.equals("tab")) {
               var7 = 1;
            }
            break;
         case 950394699:
            if (var6.equals("command")) {
               var7 = 0;
            }
         }

         switch(var7) {
         case 0:
            this.listBlockedCommands(sender);
            break;
         case 1:
            this.listNoTabCompleteCommands(sender);
            break;
         default:
            sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
         }

      }
   }

   private void listBlockedCommands(CommandSender sender) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      FileConfiguration config = this.bannedCommandsManager.getConfigFile().getConfig();
      String message;
      if (config.getStringList("bannedCommands").isEmpty()) {
         message = this.plugin.getMessagesManager().getBannedCommandsNoCommandsBlocked();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
      } else {
         message = this.plugin.getMessagesManager().getBannedCommandsBlockedList();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
         Iterator var5 = config.getStringList("bannedCommands").iterator();

         while(var5.hasNext()) {
            String command = (String)var5.next();
            sender.sendMessage("- " + command);
         }

      }
   }

   private void listNoTabCompleteCommands(CommandSender sender) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      FileConfiguration config = this.bannedCommandsManager.getConfigFile().getConfig();
      String message;
      if (config.getStringList("tab.noTabCompleteCommands").isEmpty()) {
         message = this.plugin.getMessagesManager().getBannedCommandsNoTabBlocked();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
      } else {
         message = this.plugin.getMessagesManager().getBannedCommandsBlockedTabList();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
         Iterator var5 = config.getStringList("tab.noTabCompleteCommands").iterator();

         while(var5.hasNext()) {
            String command = (String)var5.next();
            sender.sendMessage("- " + command);
         }

      }
   }

   private void handleAddCommand(CommandSender sender, String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      String message = this.plugin.getMessagesManager().getUsageBannedCommandsAdd();
      if (args.length < 3) {
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
      } else {
         String addType = args[1];
         String commandToAdd = args[2];
         String var7 = addType.toLowerCase();
         byte var8 = -1;
         switch(var7.hashCode()) {
         case 114581:
            if (var7.equals("tab")) {
               var8 = 1;
            }
            break;
         case 950394699:
            if (var7.equals("command")) {
               var8 = 0;
            }
         }

         switch(var8) {
         case 0:
            this.addBlockedCommand(sender, commandToAdd);
            break;
         case 1:
            this.addNoTabCompleteCommand(sender, commandToAdd);
            break;
         default:
            sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
         }

      }
   }

   private void addBlockedCommand(CommandSender sender, String command) {
      FileConfiguration config = this.bannedCommandsManager.getConfigFile().getConfig();
      List<String> commands = config.getStringList("bannedCommands");
      String prefix = this.plugin.getMessagesManager().getPrefix();
      String message;
      if (commands.contains(command)) {
         message = this.plugin.getMessagesManager().getBannedCommandsAlready();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
      } else {
         commands.add(command);
         config.set("bannedCommands", commands);
         this.bannedCommandsManager.saveConfig();
         message = this.plugin.getMessagesManager().getBannedCommandsAdded();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
      }
   }

   private void addNoTabCompleteCommand(CommandSender sender, String command) {
      FileConfiguration config = this.bannedCommandsManager.getConfigFile().getConfig();
      List<String> commands = config.getStringList("tab.noTabCompleteCommands");
      String prefix = this.plugin.getMessagesManager().getPrefix();
      String message;
      if (commands.contains(command)) {
         message = this.plugin.getMessagesManager().getBannedCommandsAlreadyTab();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
      } else {
         commands.add(command);
         config.set("tab.noTabCompleteCommands", commands);
         this.bannedCommandsManager.saveConfig();
         message = this.plugin.getMessagesManager().getBannedCommandsAddedTab();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
      }
   }

   private void handleRemoveCommand(CommandSender sender, String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      String removeType;
      if (args.length < 3) {
         removeType = this.plugin.getMessagesManager().getUsageBannedCommandsRemove();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + removeType));
      } else {
         removeType = args[1];
         String commandToRemove = args[2];
         String var6 = removeType.toLowerCase();
         byte var7 = -1;
         switch(var6.hashCode()) {
         case 114581:
            if (var6.equals("tab")) {
               var7 = 1;
            }
            break;
         case 950394699:
            if (var6.equals("command")) {
               var7 = 0;
            }
         }

         switch(var7) {
         case 0:
            this.removeBlockedCommand(sender, commandToRemove);
            break;
         case 1:
            this.removeNoTabCompleteCommand(sender, commandToRemove);
            break;
         default:
            String message = this.plugin.getMessagesManager().getUsageBannedCommandsRemove();
            sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
         }

      }
   }

   private void removeBlockedCommand(CommandSender sender, String command) {
      FileConfiguration config = this.bannedCommandsManager.getConfigFile().getConfig();
      List<String> commands = config.getStringList("bannedCommands");
      String prefix = this.plugin.getMessagesManager().getPrefix();
      String message;
      if (!commands.contains(command)) {
         message = this.plugin.getMessagesManager().getBannedCommandsNotBlocked();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
      } else {
         commands.remove(command);
         config.set("bannedCommands", commands);
         this.bannedCommandsManager.saveConfig();
         message = this.plugin.getMessagesManager().getBannedCommandsRemoved();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
      }
   }

   private void removeNoTabCompleteCommand(CommandSender sender, String command) {
      FileConfiguration config = this.bannedCommandsManager.getConfigFile().getConfig();
      List<String> commands = config.getStringList("tab.noTabCompleteCommands");
      String prefix = this.plugin.getMessagesManager().getPrefix();
      String message;
      if (!commands.contains(command)) {
         message = this.plugin.getMessagesManager().getBannedCommandsNotBlockedTab();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
      } else {
         commands.remove(command);
         config.set("tab.noTabCompleteCommands", commands);
         this.bannedCommandsManager.saveConfig();
         message = this.plugin.getMessagesManager().getBannedCommandsRemovedTab();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
      }
   }
}
