package commands;

import java.util.Iterator;
import minealex.tchat.OrdaChat;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class PrintCommand implements CommandExecutor {
   private final OrdaChat plugin;

   public PrintCommand(OrdaChat plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      String message;
      if (!sender.hasPermission("tchat.admin.print") && !sender.hasPermission("tchat.admin")) {
         message = this.plugin.getMessagesManager().getNoPermission();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
      } else {
         if (args.length == 0) {
            message = this.plugin.getMessagesManager().getPrintUsage();
            sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
            return true;
         }

         message = String.join(" ", args);
         String p = this.plugin.getConfigManager().getPrintPrefix().replace("%prefix%", this.plugin.getMessagesManager().getPrefix());
         Iterator var8 = Bukkit.getOnlinePlayers().iterator();

         while(var8.hasNext()) {
            Player player = (Player)var8.next();
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, p + message));
         }
      }

      return true;
   }
}
