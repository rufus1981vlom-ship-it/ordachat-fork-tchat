package commands;

import java.util.Iterator;
import minealex.tchat.OrdaChat;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class ChatClearCommand implements CommandExecutor {
   private final OrdaChat plugin;

   public ChatClearCommand(OrdaChat plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      String chatClearMessage;
      String translatedChatClearMessage;
      if (sender.hasPermission("tchat.admin.chatclear")) {
         Iterator var6 = Bukkit.getOnlinePlayers().iterator();

         while(true) {
            Player player;
            do {
               if (!var6.hasNext()) {
                  chatClearMessage = this.plugin.getMessagesManager().getChatClearMessage();
                  translatedChatClearMessage = this.plugin.getTranslateColors().translateColors((Player)null, prefix + chatClearMessage);
                  Bukkit.broadcastMessage(translatedChatClearMessage);
                  return true;
               }

               player = (Player)var6.next();
            } while(player.hasPermission("tchat.bypass.chatclear"));

            for(int i = 0; i < this.plugin.getConfigManager().getMessagesChatClear(); ++i) {
               player.sendMessage("");
            }
         }
      } else {
         chatClearMessage = this.plugin.getMessagesManager().getNoPermission();
         translatedChatClearMessage = this.plugin.getTranslateColors().translateColors((Player)null, prefix + chatClearMessage);
         sender.sendMessage(translatedChatClearMessage);
         return true;
      }
   }
}
