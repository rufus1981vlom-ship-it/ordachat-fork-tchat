package commands;

import config.ConfigManager;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;
import minealex.tchat.OrdaChat;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.ComponentBuilder;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.chat.HoverEvent.Action;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import utils.TranslateColors;

public class PrivateMessageCommand implements CommandExecutor {
   private final Map<UUID, UUID> lastMessaged = new HashMap();
   private final OrdaChat plugin;

   public PrivateMessageCommand(OrdaChat plugin) {
      this.plugin = plugin;
   }

   public Map<UUID, UUID> getLastMessaged() {
      return this.lastMessaged;
   }

   public void setLastMessaged(UUID sender, UUID receiver) {
      this.lastMessaged.put(sender, receiver);
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      if (!(sender instanceof Player)) {
         String m = this.plugin.getMessagesManager().getNoPlayer();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + m));
         return true;
      } else {
         Player senderPlayer = (Player)sender;
         TranslateColors translateColors = this.plugin.getTranslateColors();
         String message;
         if (!senderPlayer.hasPermission(this.plugin.getConfigManager().getMsgPermission()) && !senderPlayer.hasPermission("tchat.admin")) {
            message = this.plugin.getMessagesManager().getNoPermission();
            senderPlayer.sendMessage(translateColors.translateColors(senderPlayer, prefix + message));
         } else {
            if (args.length < 2) {
               message = this.plugin.getMessagesManager().getUsageMsg();
               senderPlayer.sendMessage(translateColors.translateColors(senderPlayer, prefix + message));
               return true;
            }

            Player targetPlayer = Bukkit.getPlayer(args[0]);
            if (targetPlayer == null) {
               String message = this.plugin.getMessagesManager().getPlayerNotFound();
               senderPlayer.sendMessage(translateColors.translateColors(senderPlayer, prefix + message));
               return true;
            }

            StringBuilder messageBuilder = new StringBuilder();

            for(int i = 1; i < args.length; ++i) {
               messageBuilder.append(args[i]).append(" ");
            }

            String messageToSend = messageBuilder.toString().trim();
            String senderFormattedMessage = translateColors.translateColors(senderPlayer, this.plugin.getConfigManager().getMsgFormatSender().replace("%sender%", sender.getName()).replace("%recipient%", targetPlayer.getName()).replace("%message%", messageToSend));
            String receiverFormattedMessage = translateColors.translateColors(targetPlayer, this.plugin.getConfigManager().getMsgFormatReceiver().replace("%sender%", sender.getName()).replace("%recipient%", targetPlayer.getName()).replace("%message%", messageToSend));
            String senderGroup = this.plugin.getGroupManager().getGroupName(senderPlayer);
            String receiverGroup = this.plugin.getGroupManager().getGroupName(targetPlayer);
            ConfigManager.HoverConfig senderHoverConfig = this.plugin.getConfigManager().getPmHoverConfig(senderGroup);
            ConfigManager.HoverConfig receiverHoverConfig = this.plugin.getConfigManager().getPmHoverConfig(receiverGroup);
            List<String> hoverSenderTextList = senderHoverConfig != null ? (List)senderHoverConfig.getSenderTexts().stream().map((line) -> {
               return translateColors.translateColors(senderPlayer, line);
            }).collect(Collectors.toList()) : List.of("No hover found (sender)");
            String hoverSenderText = String.join("\n", hoverSenderTextList);
            String senderAction = senderHoverConfig != null ? senderHoverConfig.getSenderAction() : null;
            Action senderHoverActionType = Action.SHOW_TEXT;
            TextComponent senderMessage = new TextComponent((new ComponentBuilder(senderFormattedMessage)).create());
            senderMessage.setHoverEvent(new HoverEvent(senderHoverActionType, (new ComponentBuilder(hoverSenderText)).create()));
            if (senderAction != null && !senderAction.isEmpty()) {
               this.applyClickEvent(senderMessage, senderAction);
            }

            List<String> hoverReceiverTextList = receiverHoverConfig != null ? (List)receiverHoverConfig.getReceiverTexts().stream().map((line) -> {
               return translateColors.translateColors(targetPlayer, line);
            }).collect(Collectors.toList()) : List.of("No hover found (receiver)");
            String hoverReceiverText = String.join("\n", hoverReceiverTextList);
            String receiverAction = receiverHoverConfig != null ? receiverHoverConfig.getReceiverAction() : null;
            Action receiverHoverActionType = Action.SHOW_TEXT;
            TextComponent receiverMessage = new TextComponent((new ComponentBuilder(receiverFormattedMessage)).create());
            receiverMessage.setHoverEvent(new HoverEvent(receiverHoverActionType, (new ComponentBuilder(hoverReceiverText)).create()));
            if (receiverAction != null && !receiverAction.isEmpty()) {
               this.applyClickEvent(receiverMessage, receiverAction);
            }

            senderPlayer.spigot().sendMessage(senderMessage);
            targetPlayer.spigot().sendMessage(receiverMessage);
            this.setLastMessaged(senderPlayer.getUniqueId(), targetPlayer.getUniqueId());
         }

         return true;
      }
   }

   private void applyClickEvent(TextComponent message, @NotNull String action) {
      String url;
      if (action.startsWith("[SUGGEST]")) {
         url = action.substring(10);
         message.setClickEvent(new ClickEvent(net.md_5.bungee.api.chat.ClickEvent.Action.SUGGEST_COMMAND, url));
      } else if (action.startsWith("[EXECUTE]")) {
         url = action.substring(10);
         message.setClickEvent(new ClickEvent(net.md_5.bungee.api.chat.ClickEvent.Action.RUN_COMMAND, url));
      } else if (action.startsWith("[OPEN]")) {
         url = action.substring(7);
         message.setClickEvent(new ClickEvent(net.md_5.bungee.api.chat.ClickEvent.Action.OPEN_URL, url));
      }

   }
}
