package commands;

import java.util.Iterator;
import minealex.tchat.OrdaChat;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class RulesCommand implements CommandExecutor {
   private final OrdaChat plugin;

   public RulesCommand(OrdaChat plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String s, @NotNull String[] strings) {
      String prefix;
      if (!sender.hasPermission("tchat.rules") && !sender.hasPermission("tchat.admin")) {
         prefix = this.plugin.getMessagesManager().getPrefix();
         String message = this.plugin.getMessagesManager().getNoPermission();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
      } else {
         if (this.plugin.getConfigManager().isRulesPrefixEnabled()) {
            prefix = this.plugin.getMessagesManager().getPrefix();
         } else {
            prefix = "";
         }

         Iterator var7;
         String message;
         if (sender instanceof Player) {
            Player player = (Player)sender;
            var7 = this.plugin.getConfigManager().getRulesMessage().iterator();

            while(var7.hasNext()) {
               message = (String)var7.next();
               player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
            }
         } else {
            var7 = this.plugin.getConfigManager().getRulesMessage().iterator();

            while(var7.hasNext()) {
               message = (String)var7.next();
               sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
            }
         }
      }

      return true;
   }
}
