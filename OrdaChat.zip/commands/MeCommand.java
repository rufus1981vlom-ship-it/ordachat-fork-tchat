package commands;

import minealex.tchat.OrdaChat;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class MeCommand implements CommandExecutor {
   private final OrdaChat plugin;

   public MeCommand(OrdaChat plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      String message;
      if (!(sender instanceof Player)) {
         message = this.plugin.getMessagesManager().getNoPlayer();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
         return true;
      } else {
         Player player = (Player)sender;
         if (!sender.hasPermission("tchat.me") && !sender.hasPermission("tchat.admin")) {
            message = this.plugin.getMessagesManager().getNoPermission();
            sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
         } else {
            if (args.length == 0) {
               message = this.plugin.getMessagesManager().getMeUsage();
               sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
               return true;
            }

            message = String.join(" ", args);
            String format = this.plugin.getConfigManager().getMeFormat().replace("%message%", message);
            Bukkit.broadcastMessage(this.plugin.getTranslateColors().translateColors(player, format));
         }

         return true;
      }
   }
}
