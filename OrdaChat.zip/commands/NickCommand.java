package commands;

import java.util.Arrays;
import minealex.tchat.OrdaChat;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import utils.TranslateColors;

public class NickCommand implements CommandExecutor {
   private final OrdaChat plugin;

   public NickCommand(@NotNull OrdaChat plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      String action;
      if (sender instanceof Player) {
         Player player = (Player)sender;
         if (!player.hasPermission("tchat.admin") && !player.hasPermission("tchat.nick")) {
            action = this.plugin.getMessagesManager().getNoPermission();
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + action));
            return true;
         } else if (args.length == 0) {
            action = this.plugin.getMessagesManager().getUsageNick();
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + action));
            return true;
         } else {
            action = args[0].toLowerCase();
            byte var9 = -1;
            switch(action.hashCode()) {
            case -934610812:
               if (action.equals("remove")) {
                  var9 = 1;
               }
               break;
            case 113762:
               if (action.equals("set")) {
                  var9 = 0;
               }
            }

            switch(var9) {
            case 0:
               this.handleSetNick(player, args);
               break;
            case 1:
               this.handleRemoveNick(player);
               break;
            default:
               String message = this.plugin.getMessagesManager().getUsageNick();
               player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
            }

            return true;
         }
      } else {
         action = this.plugin.getMessagesManager().getNoPlayer();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + action));
         return true;
      }
   }

   private void handleSetNick(Player player, String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      String newNick;
      if (args.length < 2) {
         newNick = this.plugin.getMessagesManager().getUsageNickSet();
         player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + newNick));
      } else {
         newNick = String.join(" ", (CharSequence[])Arrays.copyOfRange(args, 1, args.length));
         this.plugin.getSaveManager().setNick(player.getUniqueId(), newNick);
         String message = this.plugin.getMessagesManager().getNickSet();
         message = message.replace("%nick%", newNick);
         player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
      }
   }

   private void handleRemoveNick(Player player) {
      this.plugin.getSaveManager().setNick(player.getUniqueId(), (String)null);
      TranslateColors var10001 = this.plugin.getTranslateColors();
      String var10003 = this.plugin.getMessagesManager().getPrefix();
      player.sendMessage(var10001.translateColors(player, var10003 + this.plugin.getMessagesManager().getNickRemove()));
   }
}
