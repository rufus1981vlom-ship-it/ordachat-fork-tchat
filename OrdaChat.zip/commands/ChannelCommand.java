package commands;

import config.ChannelsConfigManager;
import java.util.Arrays;
import java.util.Iterator;
import minealex.tchat.OrdaChat;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import utils.ChannelsManager;

public class ChannelCommand implements CommandExecutor {
   private final OrdaChat plugin;
   private final ChannelsManager channelsManager;
   private final ChannelsConfigManager channelsConfigManager;

   public ChannelCommand(@NotNull OrdaChat plugin) {
      this.plugin = plugin;
      this.channelsManager = plugin.getChannelsManager();
      this.channelsConfigManager = plugin.getChannelsConfigManager();
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      if (sender instanceof Player) {
         Player player = (Player)sender;
         if (args.length == 0) {
            this.sendMessage(sender, this.plugin.getMessagesManager().getUsageChannel(), prefix);
            return true;
         } else {
            String action = args[0];
            String var8 = action.toLowerCase();
            byte var9 = -1;
            switch(var8.hashCode()) {
            case 3267882:
               if (var8.equals("join")) {
                  var9 = 0;
               }
               break;
            case 3526536:
               if (var8.equals("send")) {
                  var9 = 2;
               }
               break;
            case 102846135:
               if (var8.equals("leave")) {
                  var9 = 1;
               }
            }

            switch(var9) {
            case 0:
               this.handleJoin(player, args, prefix);
               break;
            case 1:
               this.handleLeave(player, args, prefix);
               break;
            case 2:
               this.handleSend(player, args, prefix);
               break;
            default:
               this.sendMessage(sender, this.plugin.getMessagesManager().getUsageChannel(), prefix);
            }

            return true;
         }
      } else {
         this.sendMessage(sender, this.plugin.getMessagesManager().getNoPlayer(), prefix);
         return true;
      }
   }

   private void handleJoin(Player player, String[] args, String prefix) {
      if (!this.hasPermission(player, "tchat.channel.command.join") && !this.hasPermission(player, "tchat.admin")) {
         if (args.length < 2) {
            this.sendMessage(player, this.plugin.getMessagesManager().getUsageJoinChannel(), prefix);
         } else {
            String channelName = args[1];
            Player targetPlayer = player;
            if (args.length >= 3) {
               Player specifiedPlayer = Bukkit.getPlayer(args[2]);
               if (specifiedPlayer == null) {
                  player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + this.plugin.getMessagesManager().getPlayerNotFound().replace("%player%", args[2])));
                  return;
               }

               targetPlayer = specifiedPlayer;
            }

            this.joinChannel(targetPlayer, channelName, prefix);
         }
      } else {
         this.sendMessage(player, this.plugin.getMessagesManager().getNoPermission(), prefix);
      }
   }

   private void handleLeave(Player player, String[] args, String prefix) {
      if (this.hasPermission(player, "tchat.channel.command.leave")) {
         this.sendMessage(player, this.plugin.getMessagesManager().getNoPermission(), prefix);
      } else if (args.length < 2) {
         this.sendMessage(player, this.plugin.getMessagesManager().getUsageLeaveChannel(), prefix);
      } else {
         String channelName = args[1];
         this.leaveChannel(player, channelName, prefix);
      }
   }

   private void handleSend(Player player, String[] args, String prefix) {
      if (this.hasPermission(player, "tchat.channel.command.send")) {
         this.sendMessage(player, this.plugin.getMessagesManager().getNoPermission(), prefix);
      } else if (args.length < 3) {
         this.sendMessage(player, this.plugin.getMessagesManager().getUsageSendChannel(), prefix);
      } else {
         String channelName = args[1];
         String message = String.join(" ", (CharSequence[])Arrays.copyOfRange(args, 2, args.length));
         this.sendMessageToChannel(player, channelName, message, prefix);
      }
   }

   private void joinChannel(Player player, String channelName, String prefix) {
      ChannelsConfigManager.Channel channel = this.channelsConfigManager.getChannel(channelName);
      if (channel == null) {
         this.sendMessage(player, this.plugin.getMessagesManager().getChannelNotExist().replace("%channel%", channelName), prefix);
      } else {
         int playerCount = this.channelsManager.getChannelPlayerCount(channelName);
         int playerLimit = channel.pLimit();
         String currentChannel;
         if (!player.hasPermission("tchat.admin") && !player.hasPermission("tchat.bypass.channel.limit") && playerLimit > 0 && playerCount >= playerLimit) {
            currentChannel = this.plugin.getMessagesManager().getChannelFull().replace("%channel%", channelName);
            currentChannel = currentChannel.replace("%players%", String.valueOf(playerCount)).replace("%limit%", String.valueOf(playerLimit));
            this.sendMessage(player, currentChannel, prefix);
         } else if (this.hasPermission(player, channel.permission())) {
            this.sendMessage(player, this.plugin.getMessagesManager().getChannelNoPermissionJoin().replace("%channel%", channelName), prefix);
         } else {
            currentChannel = this.channelsManager.getPlayerChannel(player);
            if (channelName.equalsIgnoreCase(currentChannel)) {
               this.sendMessage(player, this.plugin.getMessagesManager().getChannelAlready().replace("%channel%", channelName), prefix);
            } else {
               if (currentChannel != null) {
                  this.channelsManager.removePlayerFromChannel(player);
                  this.sendMessage(player, this.plugin.getMessagesManager().getChannelLeft().replace("%channel%", currentChannel), prefix);
               }

               this.channelsManager.setPlayerChannel(player, channelName);
               this.sendMessage(player, this.plugin.getMessagesManager().getChannelJoin().replace("%channel%", channelName), prefix);
               this.announceChannelChange(player, channelName, this.plugin.getMessagesManager().getChannelJoinAnnounce(), prefix);
            }
         }
      }
   }

   private void leaveChannel(Player player, @NotNull String channelName, String prefix) {
      String currentChannel = this.channelsManager.getPlayerChannel(player);
      if (!channelName.equalsIgnoreCase(currentChannel)) {
         this.sendMessage(player, this.plugin.getMessagesManager().getNoChannel().replace("%channel%", channelName), prefix);
      } else {
         ChannelsConfigManager.Channel channel = this.channelsConfigManager.getChannel(channelName);
         if (channel != null && this.hasPermission(player, "tchat.channel.command.leave")) {
            this.sendMessage(player, this.plugin.getMessagesManager().getNoPermissionChannelLeft().replace("%channel%", channelName), prefix);
         } else {
            this.channelsManager.removePlayerFromChannel(player);
            this.sendMessage(player, this.plugin.getMessagesManager().getChannelLeft().replace("%channel%", currentChannel), prefix);
            if (channel != null) {
               this.announceChannelChange(player, channelName, this.plugin.getMessagesManager().getChannelLeftAnnounce(), prefix);
            }

         }
      }
   }

   private void sendMessageToChannel(Player player, String channelName, String message, String prefix) {
      ChannelsConfigManager.Channel channel = this.channelsConfigManager.getChannel(channelName);
      if (channel == null) {
         this.sendMessage(player, this.plugin.getMessagesManager().getChannelNotExist().replace("%channel%", channelName), prefix);
      } else {
         String format = channel.formatEnabled() ? channel.format() : "%player%";
         String formattedMessage = format.replace("%player%", player.getName()).replace("%channel%", channelName);
         Iterator var8 = Bukkit.getOnlinePlayers().iterator();

         while(true) {
            Player p;
            boolean hasPermissionForChannel;
            boolean isInRecipientChannel;
            int messageMode;
            do {
               do {
                  if (!var8.hasNext()) {
                     return;
                  }

                  p = (Player)var8.next();
               } while(!channel.enabled());

               String recipientChannel = this.plugin.getChannelsManager().getPlayerChannel(p);
               hasPermissionForChannel = p.hasPermission(channel.permission()) || p.hasPermission("tchat.admin") || p.hasPermission("tchat.channel.all");
               isInRecipientChannel = recipientChannel != null && recipientChannel.equals(channelName);
               messageMode = channel.messageMode();
            } while(messageMode != 0 && (messageMode != 1 || !hasPermissionForChannel) && (messageMode != 2 || !isInRecipientChannel));

            p.sendMessage(this.plugin.getTranslateColors().translateColors(player, formattedMessage + message));
         }
      }
   }

   private void announceChannelChange(Player player, String channelName, String messageTemplate, String prefix) {
      ChannelsConfigManager.Channel channel = this.channelsConfigManager.getChannel(channelName);
      if (channel != null) {
         Iterator var6 = Bukkit.getOnlinePlayers().iterator();

         while(true) {
            Player p;
            do {
               if (!var6.hasNext()) {
                  return;
               }

               p = (Player)var6.next();
            } while(p.equals(player));

            String recipientChannel = this.channelsManager.getPlayerChannel(p);
            boolean hasPermissionForChannel = p.hasPermission(channel.permission()) || p.hasPermission("tchat.admin") || p.hasPermission("tchat.channel.all");
            boolean isInRecipientChannel = recipientChannel != null && recipientChannel.equals(channelName);
            int announceMode = channel.announceMode();
            if (this.shouldAnnounce(announceMode, hasPermissionForChannel, isInRecipientChannel)) {
               this.sendMessage(p, messageTemplate.replace("%player%", player.getName()).replace("%channel%", channelName), prefix);
            }
         }
      }
   }

   private boolean shouldAnnounce(int announceMode, boolean hasPermissionForChannel, boolean isInRecipientChannel) {
      return announceMode == 0 || announceMode == 1 && hasPermissionForChannel || announceMode == 2 && isInRecipientChannel;
   }

   private boolean hasPermission(@NotNull Player player, String permission) {
      return !player.hasPermission(permission) && !player.hasPermission("tchat.admin") && !player.hasPermission("tchat.channel.all");
   }

   private void sendMessage(@NotNull CommandSender sender, String message, String prefix) {
      sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
   }
}
