package commands;

import java.util.Iterator;
import minealex.tchat.OrdaChat;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class ListCommand implements CommandExecutor {
   private final OrdaChat plugin;

   public ListCommand(OrdaChat plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      String message;
      if (!(sender instanceof Player)) {
         message = this.plugin.getMessagesManager().getNoPlayer();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
         return false;
      } else {
         Player player = (Player)sender;
         if (!player.hasPermission("tchat.admin") && !player.hasPermission("tchat.admin.list")) {
            message = this.plugin.getMessagesManager().getNoPermission();
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
         } else {
            StringBuilder onlinePlayers = new StringBuilder(this.plugin.getConfigManager().getListHeader());
            Iterator var8 = Bukkit.getOnlinePlayers().iterator();

            while(var8.hasNext()) {
               Player p = (Player)var8.next();
               onlinePlayers.append(p.getName()).append(this.plugin.getTranslateColors().translateColors(player, this.plugin.getConfigManager().getListAppend()));
            }

            if (onlinePlayers.length() > 2) {
               onlinePlayers.setLength(onlinePlayers.length() - 2);
            }

            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, onlinePlayers.toString()));
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, this.plugin.getConfigManager().getListFooter()));
         }

         return true;
      }
   }
}
