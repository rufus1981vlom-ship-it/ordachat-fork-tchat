package commands;

import java.util.Iterator;
import minealex.tchat.OrdaChat;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.jetbrains.annotations.NotNull;

public class PluginCommand implements CommandExecutor {
   private final OrdaChat plugin;

   public PluginCommand(OrdaChat plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(@NotNull CommandSender commandSender, @NotNull Command command, @NotNull String s, @NotNull String[] strings) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      if (commandSender.hasPermission("tchat.admin.plugin") || commandSender.hasPermission("tchat.admin")) {
         String pluginName;
         if (strings.length == 0) {
            pluginName = this.plugin.getMessagesManager().getPluginUsage();
            commandSender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + pluginName));
            return false;
         }

         pluginName = strings[0];
         Plugin pluginN = Bukkit.getPluginManager().getPlugin(pluginName);
         String name;
         if (pluginN == null) {
            name = this.plugin.getMessagesManager().getPluginNotFound();
            commandSender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + name));
            return false;
         }

         name = pluginN.getDescription().getName();
         String version = pluginN.getDescription().getVersion();
         String author = String.join(", ", pluginN.getDescription().getAuthors());
         Iterator var11 = this.plugin.getMessagesManager().getPluginMessage().iterator();

         while(var11.hasNext()) {
            String message = (String)var11.next();
            message = message.replace("%plugin%", name);
            message = message.replace("%version%", version);
            message = message.replace("%author%", author);
            commandSender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, message));
         }
      }

      return true;
   }
}
