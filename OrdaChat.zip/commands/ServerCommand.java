package commands;

import java.util.Iterator;
import minealex.tchat.OrdaChat;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class ServerCommand implements CommandExecutor {
   private final OrdaChat plugin;

   public ServerCommand(OrdaChat plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      if (!sender.hasPermission("tchat.admin.server")) {
         String message = this.plugin.getMessagesManager().getNoPermission();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
         return true;
      } else {
         Iterator var6 = this.plugin.getMessagesManager().getServerMessage().iterator();

         while(var6.hasNext()) {
            String infoMessage = (String)var6.next();
            int port = Bukkit.getServer().getPort();
            String version = Bukkit.getServer().getVersion();
            String javaVersion = System.getProperty("java.version");
            double cpu = (double)Runtime.getRuntime().availableProcessors();
            String osN = System.getProperty("os.name");
            String osV = System.getProperty("os.version");
            String cpuFamily = System.getenv("PROCESSOR_IDENTIFIER");
            if (cpuFamily == null) {
               cpuFamily = "Unknown CPU Family";
            }

            int numPlugins = Bukkit.getServer().getPluginManager().getPlugins().length;
            int numWorlds = Bukkit.getServer().getWorlds().size();
            infoMessage = infoMessage.replace("%java_version%", javaVersion);
            infoMessage = infoMessage.replace("%port%", String.valueOf(port));
            infoMessage = infoMessage.replace("%version%", version);
            infoMessage = infoMessage.replace("%os_name%", osN);
            infoMessage = infoMessage.replace("%os_version%", osV);
            infoMessage = infoMessage.replace("%cpu_cores%", String.valueOf(cpu));
            infoMessage = infoMessage.replace("%cpu_family%", cpuFamily);
            infoMessage = infoMessage.replace("%plugins%", String.valueOf(numPlugins));
            infoMessage = infoMessage.replace("%worlds%", String.valueOf(numWorlds));
            sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, infoMessage));
         }

         return true;
      }
   }
}
