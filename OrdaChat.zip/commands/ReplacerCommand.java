package commands;

import config.ReplacerManager;
import java.util.Iterator;
import minealex.tchat.OrdaChat;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class ReplacerCommand implements CommandExecutor {
   private final OrdaChat plugin;
   private final ReplacerManager replacerManager;
   private final String prefix;

   public ReplacerCommand(@NotNull OrdaChat plugin) {
      this.plugin = plugin;
      this.replacerManager = plugin.getReplacerManager();
      this.prefix = plugin.getMessagesManager().getPrefix();
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
      String m = this.plugin.getMessagesManager().getUsageReplacer();
      if (args.length == 0) {
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, this.prefix + m));
         return true;
      } else {
         if (args[0].equalsIgnoreCase("list")) {
            this.handleListCommand(sender);
         } else if (args[0].equalsIgnoreCase("add")) {
            this.handleAddCommand(sender, args);
         } else if (args[0].equalsIgnoreCase("remove")) {
            this.handleRemoveCommand(sender, args);
         } else if (args[0].equalsIgnoreCase("enable")) {
            this.handleEnableCommand(sender);
         } else if (args[0].equalsIgnoreCase("disable")) {
            this.handleDisableCommand(sender);
         } else {
            sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, this.prefix + m));
         }

         return true;
      }
   }

   private void handleListCommand(CommandSender sender) {
      String m;
      if (sender instanceof Player && !sender.hasPermission("tchat.admin.command.replacer.list") && !sender.hasPermission("tchat.admin")) {
         m = this.plugin.getMessagesManager().getNoPermission();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, this.prefix + m));
      } else {
         if (this.replacerManager.getReplacements().isEmpty()) {
            m = this.plugin.getMessagesManager().getReplacerNoReplacements();
            sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, this.prefix + m));
            return;
         }

         m = this.plugin.getMessagesManager().getReplacerHeader();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, this.prefix + m));
         String or = this.plugin.getMessagesManager().getReplacerOriginal();
         String re = this.plugin.getMessagesManager().getReplacerReplace();
         String pm = this.plugin.getMessagesManager().getReplacerPermission();
         String pm1 = this.plugin.getMessagesManager().getReplacerPermissionEnd();
         Iterator var7 = this.replacerManager.getReplacements().values().iterator();

         while(var7.hasNext()) {
            ReplacerManager.Replacement replacement = (ReplacerManager.Replacement)var7.next();
            String var10001 = this.plugin.getTranslateColors().translateColors((Player)null, or);
            sender.sendMessage(var10001 + replacement.getOriginal() + this.plugin.getTranslateColors().translateColors((Player)null, re) + replacement.getReplace() + this.plugin.getTranslateColors().translateColors((Player)null, pm) + replacement.getPermission() + this.plugin.getTranslateColors().translateColors((Player)null, pm1));
         }
      }

   }

   private void handleAddCommand(CommandSender sender, @NotNull String[] args) {
      String original;
      if (args.length < 4) {
         original = this.plugin.getMessagesManager().getUsageReplacerAdd();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, this.prefix + original));
      } else {
         if (sender instanceof Player && !sender.hasPermission("tchat.admin.command.replacer.add") && !sender.hasPermission("tchat.admin")) {
            original = this.plugin.getMessagesManager().getNoPermission();
            sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, this.prefix + original));
         } else {
            original = args[1];
            String replace = args[2];
            String permission = args[3];
            this.replacerManager.addReplacement(original, replace, permission);
            String m = this.plugin.getMessagesManager().getReplacerAdded();
            m = m.replace("%original%", original).replace("%replacement%", replace);
            sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, this.prefix + m));
         }

      }
   }

   private void handleRemoveCommand(CommandSender sender, @NotNull String[] args) {
      String original;
      if (args.length < 2) {
         original = this.plugin.getMessagesManager().getUsageReplacerRemove();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, this.prefix + original));
      } else {
         if (sender instanceof Player && !sender.hasPermission("tchat.admin.command.replacer.remove") && !sender.hasPermission("tchat.admin")) {
            original = this.plugin.getMessagesManager().getNoPermission();
            sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, this.prefix + original));
         } else {
            original = args[1];
            this.replacerManager.removeReplacement(original);
            String m = this.plugin.getMessagesManager().getReplacerRemoved();
            m = m.replace("%original%", original);
            sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, this.prefix + m));
         }

      }
   }

   private void handleEnableCommand(CommandSender sender) {
      if (sender instanceof Player && !sender.hasPermission("tchat.admin.command.replacer.enable") && !sender.hasPermission("tchat.admin")) {
         sender.sendMessage("§cYou don't have permission to use this command.");
      } else {
         this.replacerManager.setReplacerEnabled(true);
         String m = this.plugin.getMessagesManager().getReplacerEnabled();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, this.prefix + m));
      }

   }

   private void handleDisableCommand(CommandSender sender) {
      if (sender instanceof Player && !sender.hasPermission("tchat.admin.command.replacer.disable") && !sender.hasPermission("tchat.admin")) {
         sender.sendMessage("§cYou don't have permission to use this command.");
      } else {
         this.replacerManager.setReplacerEnabled(false);
         String m = this.plugin.getMessagesManager().getReplacerDisabled();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, this.prefix + m));
      }

   }
}
