package commands;

import java.util.Arrays;
import minealex.tchat.OrdaChat;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import utils.Poll;

public class PollCommand implements CommandExecutor {
   private final OrdaChat plugin;

   public PollCommand(OrdaChat plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      String subCommand;
      if (args.length < 2) {
         subCommand = this.plugin.getMessagesManager().getUsagePoll();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + subCommand));
         return false;
      } else {
         subCommand = args[0].toLowerCase();
         if (subCommand.equals("create")) {
            return this.handleCreateCommand(sender, args);
         } else if (subCommand.equals("vote")) {
            return this.handleVoteCommand(sender, args);
         } else if (subCommand.equals("finish")) {
            return this.handleFinishCommand(sender, args);
         } else {
            String message = this.plugin.getMessagesManager().getUsagePoll();
            sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
            return false;
         }
      }
   }

   private boolean handleFinishCommand(@NotNull CommandSender sender, String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      if (!sender.hasPermission("tchat.poll.finish") && !sender.hasPermission("tchat.admin")) {
         String message = this.plugin.getMessagesManager().getNoPermission();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
         return false;
      } else {
         Poll currentPoll = Poll.getCurrentPoll();
         String message;
         if (currentPoll == null) {
            message = this.plugin.getMessagesManager().getNoPoll();
            sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
            return false;
         } else {
            currentPoll.finalizePoll();
            message = this.plugin.getMessagesManager().getPollFinish();
            sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
            return true;
         }
      }
   }

   private boolean handleCreateCommand(@NotNull CommandSender sender, String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      if (!sender.hasPermission("tchat.poll.create") && !sender.hasPermission("tchat.admin")) {
         String message = this.plugin.getMessagesManager().getNoPermission();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
      } else {
         String message;
         if (!(sender instanceof Player)) {
            message = this.plugin.getMessagesManager().getNoPlayer();
            sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
            return false;
         }

         Player player = (Player)sender;
         if (args.length < 3) {
            message = this.plugin.getMessagesManager().getUsagePollCreate();
            sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
            return false;
         }

         int duration;
         try {
            duration = Integer.parseInt(args[1]);
         } catch (NumberFormatException var23) {
            String message = this.plugin.getMessagesManager().getDurationNumber();
            sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
            return false;
         }

         String combinedArgs = String.join(" ", (CharSequence[])Arrays.copyOfRange(args, 2, args.length));
         String[] parts = combinedArgs.split("\\|", 4);
         String title;
         if (parts.length < 2) {
            title = this.plugin.getMessagesManager().getUsagePollCreate();
            sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + title));
            return false;
         }

         title = parts[0].trim();
         String[] options = parts[1].trim().split("\\s+");
         int minPlayer = Integer.parseInt(parts[2].trim());
         int maxPlayer = Integer.parseInt(parts[3].trim());
         if (options.length < 1) {
            String message = this.plugin.getMessagesManager().getOneOption();
            sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
            return false;
         }

         Poll newPoll = new Poll(this.plugin, title, duration, options, minPlayer, maxPlayer);
         Poll.setCurrentPoll(newPoll);
         String message = this.plugin.getMessagesManager().getPollCreate();
         message = message.replace("%title%", title);
         String durationString = String.valueOf(duration);
         message = message.replace("%seconds%", durationString);
         sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
         String startTitle = this.plugin.getMessagesManager().getStartTitle();
         String startTextTitle = this.plugin.getMessagesManager().getStartText();
         startTitle = startTitle != null ? startTitle : "";
         startTextTitle = startTextTitle != null ? startTextTitle : "";
         StringBuilder resultsMessage = new StringBuilder(this.plugin.getTranslateColors().translateColors((Player)null, startTitle));
         resultsMessage.append(this.plugin.getTranslateColors().translateColors((Player)null, startTextTitle)).append(title).append("\n");
         int BAR_LENGTH = this.plugin.getConfigManager().getPollBar();
         String[] var19 = options;
         int var20 = options.length;

         for(int var21 = 0; var21 < var20; ++var21) {
            String option = var19[var21];
            resultsMessage.append(ChatColor.translateAlternateColorCodes('&', this.plugin.getMessagesManager().getStartOptionLine().replace("%option%", option).replace("%votes%", "0").replace("%.2f%%", "0.00"))).append("\n").append(ChatColor.translateAlternateColorCodes('&', this.plugin.getMessagesManager().getStartProgressBar().replace("%filled%", String.valueOf('░').repeat(BAR_LENGTH)).replace("%empty%", ""))).append("\n");
         }

         Bukkit.broadcastMessage(resultsMessage.toString().trim());
      }

      return true;
   }

   private boolean handleVoteCommand(@NotNull CommandSender sender, String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      if (!sender.hasPermission("tchat.admin") && !sender.hasPermission("tchat.poll.vote")) {
         String message = this.plugin.getMessagesManager().getNoPermission();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
      } else {
         String message;
         if (!(sender instanceof Player)) {
            message = this.plugin.getMessagesManager().getNoPlayer();
            sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
            return false;
         }

         Player player = (Player)sender;
         if (args.length < 2) {
            message = this.plugin.getMessagesManager().getUsagePollVote();
            sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
            return false;
         }

         Poll currentPoll = Poll.getCurrentPoll();
         String option;
         if (currentPoll == null) {
            option = this.plugin.getMessagesManager().getNoPoll();
            sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + option));
            return false;
         }

         option = args[1];
         String message;
         if (!currentPoll.isValidOption(option)) {
            message = this.plugin.getMessagesManager().getInvalidOptionPoll();
            message = message.replace("%options%", String.join(", ", currentPoll.getOptions()));
            sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
            return false;
         }

         currentPoll.vote(player, option);
         message = this.plugin.getMessagesManager().getVotePoll();
         message = message.replace("%option%", option);
         sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
         String updateTitle = this.plugin.getMessagesManager().getUpdateTitle();
         String updateText = this.plugin.getMessagesManager().getUpdateText();
         updateTitle = updateTitle != null ? updateTitle : "";
         updateText = updateText != null ? updateText : "";
         StringBuilder resultsMessage = new StringBuilder(this.plugin.getTranslateColors().translateColors((Player)null, updateTitle));
         resultsMessage.append(this.plugin.getTranslateColors().translateColors((Player)null, updateText)).append(currentPoll.getTitle()).append("\n");
         int totalVotes = currentPoll.getResults().values().stream().mapToInt(Integer::intValue).sum();
         int BAR_LENGTH = this.plugin.getConfigManager().getPollBar();
         String[] var13 = currentPoll.getOptions();
         int var14 = var13.length;

         for(int var15 = 0; var15 < var14; ++var15) {
            String opt = var13[var15];
            int voteCount = (Integer)currentPoll.getResults().getOrDefault(opt, 0);
            double percentage = totalVotes > 0 ? (double)voteCount * 100.0D / (double)totalVotes : 0.0D;
            int filledBlocks = (int)(percentage / 100.0D * (double)BAR_LENGTH);
            int emptyBlocks = BAR_LENGTH - filledBlocks;
            String progressBar = ChatColor.translateAlternateColorCodes('&', this.plugin.getMessagesManager().getUpdateProgressBar().replace("%filled%", String.valueOf(this.plugin.getConfigManager().getPollFill()).repeat(filledBlocks)).replace("%empty%", String.valueOf(this.plugin.getConfigManager().getPollEmpty()).repeat(emptyBlocks)));
            resultsMessage.append(ChatColor.translateAlternateColorCodes('&', this.plugin.getMessagesManager().getUpdateOptionLine().replace("%option%", opt).replace("%votes%", String.valueOf(voteCount)).replace("%.2f%%", String.format("%.2f", percentage)))).append("\n").append(progressBar).append("\n");
         }

         Bukkit.broadcastMessage(resultsMessage.toString().trim());
      }

      return true;
   }
}
