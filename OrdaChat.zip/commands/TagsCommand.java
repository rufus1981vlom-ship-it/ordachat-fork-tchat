package commands;

import config.TagsManager;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import minealex.tchat.OrdaChat;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import utils.TagsInventoryManager;

public class TagsCommand implements CommandExecutor, TabCompleter {
   private final TagsManager tagsManager;
   private final OrdaChat plugin;
   private final TagsInventoryManager tagsInventoryManager;

   public TagsCommand(@NotNull OrdaChat plugin, TagsManager tagsManager, TagsInventoryManager tagsInventoryManager) {
      this.plugin = plugin;
      this.tagsManager = tagsManager;
      this.tagsInventoryManager = tagsInventoryManager;
      ((org.bukkit.command.PluginCommand)Objects.requireNonNull(plugin.getCommand("tags"))).setExecutor(this);
      ((org.bukkit.command.PluginCommand)Objects.requireNonNull(plugin.getCommand("tags"))).setTabCompleter(this);
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
      String p = this.plugin.getMessagesManager().getPrefix();
      String m;
      if (!(sender instanceof Player)) {
         m = this.plugin.getMessagesManager().getNoPlayer();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, p + m));
         return true;
      } else {
         Player player = (Player)sender;
         if (args.length == 0) {
            if (this.plugin.getTagsMenuConfigManager().isEnabled()) {
               this.tagsInventoryManager.openMenu(player, this.plugin.getTagsMenuConfigManager().getDmenu());
            } else {
               m = this.plugin.getMessagesManager().getTagsUsage();
               player.sendMessage(this.plugin.getTranslateColors().translateColors(player, p + m));
            }

            return true;
         } else if (!args[0].equalsIgnoreCase("list")) {
            if (args[0].equalsIgnoreCase("select")) {
               if (args.length < 2) {
                  m = this.plugin.getMessagesManager().getTagsUsageSelect();
                  player.sendMessage(this.plugin.getTranslateColors().translateColors(player, p + m));
                  return true;
               } else {
                  TagsManager.Tag tag = (TagsManager.Tag)this.tagsManager.getTags().get(args[1]);
                  String m;
                  if (tag == null) {
                     m = this.plugin.getMessagesManager().getTagsNotFound().replace("%tag%", args[1]);
                     player.sendMessage(this.plugin.getTranslateColors().translateColors(player, p + m));
                     return true;
                  } else if (!player.hasPermission(tag.getPermission()) && !player.hasPermission("tchat.tags.select") && !player.hasPermission("tchat.tags.all") && !player.hasPermission("tchat.admin")) {
                     m = this.plugin.getMessagesManager().getNoPermission();
                     player.sendMessage(this.plugin.getTranslateColors().translateColors(player, p + m));
                     return true;
                  } else {
                     m = this.plugin.getMessagesManager().getTagsSelected().replace("%tag%", args[1]);
                     player.sendMessage(this.plugin.getTranslateColors().translateColors(player, p + m));
                     this.plugin.getSaveManager().saveSelectedTag(player.getUniqueId(), args[1]);
                     return true;
                  }
               }
            } else {
               return false;
            }
         } else if (!player.hasPermission("tchat.tags.list") && !player.hasPermission("tchat.admin")) {
            m = this.plugin.getMessagesManager().getNoPermission();
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, p + m));
            return true;
         } else {
            m = this.plugin.getMessagesManager().getTagsList();
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, p + m));
            Iterator var8 = this.tagsManager.getTags().keySet().iterator();

            while(var8.hasNext()) {
               String tag = (String)var8.next();
               player.sendMessage("- " + tag);
            }

            return true;
         }
      }
   }

   @Nullable
   public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, @NotNull String[] args) {
      List<String> completions = new ArrayList();
      if (args.length == 1) {
         if ("list".startsWith(args[0].toLowerCase()) && sender.hasPermission("tchat.tags.list") || sender.hasPermission("tchat.admin")) {
            completions.add("list");
         }

         if ("select".startsWith(args[0].toLowerCase()) && sender.hasPermission("tchat.tags.select") || sender.hasPermission("tchat.admin")) {
            completions.add("select");
         }
      } else if (args.length == 2 && args[0].equalsIgnoreCase("select") && sender.hasPermission("tchat.tags.select") || sender.hasPermission("tchat.admin")) {
         Iterator var6 = this.tagsManager.getTags().keySet().iterator();

         while(var6.hasNext()) {
            String tag = (String)var6.next();
            if (tag.toLowerCase().startsWith(args[1].toLowerCase())) {
               completions.add(tag);
            }
         }
      }

      return completions;
   }
}
