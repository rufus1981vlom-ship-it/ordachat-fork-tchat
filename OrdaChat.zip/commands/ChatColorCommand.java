package commands;

import java.util.HashMap;
import java.util.Map;
import minealex.tchat.OrdaChat;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class ChatColorCommand implements CommandExecutor {
   private final OrdaChat plugin;
   private final Map<String, String> colorCodeToNameMap;

   public ChatColorCommand(OrdaChat plugin) {
      this.plugin = plugin;
      this.colorCodeToNameMap = new HashMap();
      this.initializeColorMappings();
   }

   private void initializeColorMappings() {
      this.colorCodeToNameMap.put("&0", "black");
      this.colorCodeToNameMap.put("&1", "dark_blue");
      this.colorCodeToNameMap.put("&2", "dark_green");
      this.colorCodeToNameMap.put("&3", "dark_aqua");
      this.colorCodeToNameMap.put("&4", "dark_red");
      this.colorCodeToNameMap.put("&5", "dark_purple");
      this.colorCodeToNameMap.put("&6", "gold");
      this.colorCodeToNameMap.put("&7", "gray");
      this.colorCodeToNameMap.put("&8", "dark_gray");
      this.colorCodeToNameMap.put("&9", "blue");
      this.colorCodeToNameMap.put("&a", "green");
      this.colorCodeToNameMap.put("&b", "aqua");
      this.colorCodeToNameMap.put("&c", "red");
      this.colorCodeToNameMap.put("&d", "light_purple");
      this.colorCodeToNameMap.put("&e", "yellow");
      this.colorCodeToNameMap.put("&f", "white");
      this.colorCodeToNameMap.put("&k", "magic");
      this.colorCodeToNameMap.put("&l", "bold");
      this.colorCodeToNameMap.put("&m", "strikethrough");
      this.colorCodeToNameMap.put("&n", "underline");
      this.colorCodeToNameMap.put("&o", "italic");
      this.colorCodeToNameMap.put("&r", "reset");
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, @NotNull String[] args) {
      String prefix;
      String title;
      if (!(sender instanceof Player)) {
         prefix = this.plugin.getTranslateColors().translateColors((Player)null, this.plugin.getMessagesManager().getNoPlayer());
         title = this.plugin.getTranslateColors().translateColors((Player)null, this.plugin.getMessagesManager().getPrefix());
         sender.sendMessage(title + prefix);
         return true;
      } else {
         Player player = (Player)sender;
         prefix = this.plugin.getTranslateColors().translateColors(player, this.plugin.getMessagesManager().getPrefix());
         if (args.length == 0 && this.plugin.getConfigManager().isChatColorMenuEnabled()) {
            if (player.hasPermission("tchat.chatcolor.menu")) {
               title = this.plugin.getTranslateColors().translateColors(player, this.plugin.getChatColorManager().getTitle());
               if (title.contains("%center%")) {
                  title = title.replace("%center%", "");
                  title = this.centerText(title);
               }

               this.plugin.getChatColorInventoryManager().openInventory(player, title);
            } else {
               title = this.plugin.getTranslateColors().translateColors(player, this.plugin.getMessagesManager().getNoPermission());
               player.sendMessage(prefix + title);
            }
         } else {
            String[] var7 = args;
            int var8 = args.length;

            for(int var9 = 0; var9 < var8; ++var9) {
               String arg = var7[var9];
               String colorPermission;
               String format;
               String message;
               if (arg.matches("&[0-9a-f]")) {
                  colorPermission = "tchat.chatcolor.command." + arg;
                  if (player.hasPermission(colorPermission)) {
                     this.plugin.getSaveManager().setChatColor(player.getUniqueId(), arg);
                     format = this.plugin.getSaveManager().getFormat(player.getUniqueId());
                     message = this.plugin.getMessagesManager().getColorSelectedMessage();
                     message = message.replace("%id%", arg);
                     message = message.replace("%format%", format);
                     message = message.replace("%color%", (CharSequence)this.colorCodeToNameMap.getOrDefault(arg, "unknown"));
                     player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
                  } else {
                     format = this.plugin.getTranslateColors().translateColors(player, this.plugin.getMessagesManager().getNoPermission());
                     player.sendMessage(prefix + format);
                  }
               } else if (arg.matches("&[k-o&r]")) {
                  colorPermission = "tchat.chatcolor.command." + arg;
                  if (player.hasPermission(colorPermission)) {
                     this.plugin.getSaveManager().setFormat(player.getUniqueId(), arg);
                     format = this.plugin.getSaveManager().getChatColor(player.getUniqueId());
                     message = this.plugin.getMessagesManager().getFormatSelectedMessage();
                     message = message.replace("%id%", arg);
                     message = message.replace("%color%", format);
                     message = message.replace("%format%", (CharSequence)this.colorCodeToNameMap.getOrDefault(arg, "unknown"));
                     player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
                  } else {
                     format = this.plugin.getTranslateColors().translateColors(player, this.plugin.getMessagesManager().getNoPermission());
                     player.sendMessage(prefix + format);
                  }
               } else if (arg.startsWith("&#")) {
                  colorPermission = "tchat.chatcolor.command.hex";
                  if (player.hasPermission(colorPermission)) {
                     this.plugin.getSaveManager().setChatColor(player.getUniqueId(), arg);
                     format = this.plugin.getSaveManager().getFormat(player.getUniqueId());
                     message = this.plugin.getMessagesManager().getColorSelectedMessage();
                     message = message.replace("%id%", arg);
                     message = message.replace("%format%", format);
                     message = message.replace("%color%", "hex");
                     player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
                  } else {
                     format = this.plugin.getTranslateColors().translateColors(player, this.plugin.getMessagesManager().getNoPermission());
                     player.sendMessage(prefix + format);
                  }
               } else {
                  colorPermission = this.plugin.getMessagesManager().getInvalidColor();
                  colorPermission = colorPermission.replace("%color%", arg);
                  player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + colorPermission));
               }
            }
         }

         return true;
      }
   }

   private String centerText(String message) {
      int maxLength = true;
      String strippedMessage = ChatColor.stripColor(message);
      int length = strippedMessage.length();
      if (length >= 32) {
         return message;
      } else {
         int spaces = (32 - length) / 2;
         String var10000 = " ".repeat(spaces);
         return var10000 + message;
      }
   }
}
