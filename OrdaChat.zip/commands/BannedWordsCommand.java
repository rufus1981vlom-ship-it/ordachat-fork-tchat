package commands;

import config.BannedWordsManager;
import java.util.List;
import minealex.tchat.OrdaChat;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class BannedWordsCommand implements CommandExecutor {
   private final BannedWordsManager bannedWordsManager;
   private final OrdaChat plugin;

   public BannedWordsCommand(OrdaChat plugin, BannedWordsManager bannedWordsManager) {
      this.plugin = plugin;
      this.bannedWordsManager = bannedWordsManager;
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      String action;
      if (sender instanceof Player) {
         Player player = (Player)sender;
         if (!player.hasPermission("tchat.admin.command.bannedwords")) {
            action = this.plugin.getMessagesManager().getNoPermission();
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + action));
            return true;
         } else if (args.length == 0) {
            action = this.plugin.getMessagesManager().getUsageBannedWords();
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + action));
            return true;
         } else {
            action = args[0].toLowerCase();
            byte var9 = -1;
            switch(action.hashCode()) {
            case -934610812:
               if (action.equals("remove")) {
                  var9 = 2;
               }
               break;
            case 96417:
               if (action.equals("add")) {
                  var9 = 1;
               }
               break;
            case 3322014:
               if (action.equals("list")) {
                  var9 = 0;
               }
            }

            String wordToAdd;
            String wordToRemove;
            String message;
            switch(var9) {
            case 0:
               List<String> bannedWords = this.bannedWordsManager.getBannedWords();
               if (bannedWords.isEmpty()) {
                  wordToAdd = this.plugin.getMessagesManager().getBannedWordsNone();
                  player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + wordToAdd));
               } else {
                  wordToAdd = this.plugin.getMessagesManager().getBannedWordsList();
                  wordToAdd = wordToAdd.replace("%words%", String.join(", ", bannedWords));
                  player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + wordToAdd));
               }
               break;
            case 1:
               if (args.length < 2) {
                  wordToAdd = this.plugin.getMessagesManager().getUsageBannedWordsAdd();
                  player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + wordToAdd));
                  return true;
               }

               wordToAdd = args[1].toLowerCase();
               if (!this.bannedWordsManager.getBannedWords().contains(wordToAdd)) {
                  this.bannedWordsManager.getBannedWords().add(wordToAdd);
                  this.bannedWordsManager.saveBannedWords();
                  wordToRemove = this.plugin.getMessagesManager().getBannedWordsAdd().replace("%word%", wordToAdd);
                  player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + wordToRemove));
               } else {
                  wordToRemove = this.plugin.getMessagesManager().getBannedWordsAlready().replace("%word%", wordToAdd);
                  player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + wordToRemove));
               }
               break;
            case 2:
               if (args.length < 2) {
                  wordToRemove = this.plugin.getMessagesManager().getUsageBannedWordsRemove();
                  player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + wordToRemove));
                  return true;
               }

               wordToRemove = args[1].toLowerCase();
               if (this.bannedWordsManager.getBannedWords().contains(wordToRemove)) {
                  this.bannedWordsManager.getBannedWords().remove(wordToRemove);
                  this.bannedWordsManager.saveBannedWords();
                  message = this.plugin.getMessagesManager().getBannedWordsRemoved().replace("%word%", wordToRemove);
                  player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
               } else {
                  message = this.plugin.getMessagesManager().getBannedWordsUnknown().replace("%word%", wordToRemove);
                  player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
               }
               break;
            default:
               message = this.plugin.getMessagesManager().getUsageBannedWords();
               player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
            }

            return true;
         }
      } else {
         action = this.plugin.getMessagesManager().getNoPlayer();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + action));
         return true;
      }
   }
}
