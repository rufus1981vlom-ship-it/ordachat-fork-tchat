package commands;

import config.LogsManager;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import minealex.tchat.OrdaChat;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class LogsCommand implements CommandExecutor, TabCompleter {
   private final LogsManager logsManager;
   private final OrdaChat plugin;

   public LogsCommand(@NotNull OrdaChat plugin) {
      this.logsManager = plugin.getLogsManager();
      this.plugin = plugin;
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
      String p = this.plugin.getMessagesManager().getPrefix();
      String logType;
      if (args.length == 0) {
         logType = this.plugin.getMessagesManager().getUsageLogs();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, p + logType));
         return false;
      } else if (!sender.hasPermission("tchat.admin.command.logs")) {
         logType = this.plugin.getMessagesManager().getNoPermission();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, p + logType));
         return false;
      } else {
         logType = args[0].toLowerCase();
         String playerName = args.length > 1 ? args[1] : "";
         String filter = args.length > 2 ? args[2] : "";
         File logFile = this.getLogFile(logType);
         if (logFile == null) {
            String m = this.plugin.getMessagesManager().getLogsInvalid();
            sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, p + m));
            return false;
         } else {
            List<String> results = this.searchLogs(logFile, playerName, filter);
            String m;
            if (results.isEmpty()) {
               m = this.plugin.getMessagesManager().getLogsNoRegister();
               sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, p + m));
            } else {
               m = this.plugin.getMessagesManager().getLogsHeader();
               sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, p + m));
               Iterator var12 = results.iterator();

               while(var12.hasNext()) {
                  String result = (String)var12.next();
                  sender.sendMessage(result);
               }
            }

            return true;
         }
      }
   }

   @Nullable
   private File getLogFile(@NotNull String logType) {
      byte var3 = -1;
      switch(logType.hashCode()) {
      case -2118832514:
         if (logType.equals("antiadver")) {
            var3 = 5;
         }
         break;
      case -1335772033:
         if (logType.equals("deaths")) {
            var3 = 6;
         }
         break;
      case -1190396462:
         if (logType.equals("ignore")) {
            var3 = 4;
         }
         break;
      case -602535288:
         if (logType.equals("commands")) {
            var3 = 2;
         }
         break;
      case 3052376:
         if (logType.equals("chat")) {
            var3 = 0;
         }
         break;
      case 1190235046:
         if (logType.equals("bannedcommands")) {
            var3 = 3;
         }
         break;
      case 2009357899:
         if (logType.equals("bannedwords")) {
            var3 = 1;
         }
      }

      File var10000;
      switch(var3) {
      case 0:
         var10000 = this.logsManager.getChatLogFile();
         break;
      case 1:
         var10000 = this.logsManager.getBannedWordsFile();
         break;
      case 2:
         var10000 = this.logsManager.getCommandLogFile();
         break;
      case 3:
         var10000 = this.logsManager.getBannedCommandsFile();
         break;
      case 4:
         var10000 = this.logsManager.getIgnoreFile();
         break;
      case 5:
         var10000 = this.logsManager.getAntiAdverFile();
         break;
      case 6:
         var10000 = this.logsManager.getDeathFile();
         break;
      default:
         var10000 = null;
      }

      return var10000;
   }

   @NotNull
   private List<String> searchLogs(File logFile, String playerName, String filter) {
      ArrayList results = new ArrayList();

      try {
         BufferedReader reader = new BufferedReader(new FileReader(logFile));

         try {
            label43:
            while(true) {
               String line;
               do {
                  do {
                     if ((line = reader.readLine()) == null) {
                        break label43;
                     }
                  } while(!playerName.isEmpty() && !line.contains(playerName));
               } while(!filter.isEmpty() && !line.contains(filter));

               results.add(line);
            }
         } catch (Throwable var9) {
            try {
               reader.close();
            } catch (Throwable var8) {
               var9.addSuppressed(var8);
            }

            throw var9;
         }

         reader.close();
      } catch (IOException var10) {
         Bukkit.getLogger().severe("Error reading the log file: " + var10.getMessage());
      }

      return results;
   }

   public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, @NotNull String[] args) {
      List<String> completions = new ArrayList();
      if (args.length == 1) {
         completions.add("chat");
         completions.add("bannedwords");
         completions.add("commands");
         completions.add("bannedcommands");
         completions.add("ignore");
         completions.add("antiadver");
         completions.add("deaths");
      } else if (args.length == 2) {
         Iterator var6 = Bukkit.getOnlinePlayers().iterator();

         while(var6.hasNext()) {
            Player player = (Player)var6.next();
            completions.add(player.getName());
         }
      }

      return completions;
   }
}
