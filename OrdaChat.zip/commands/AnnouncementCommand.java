package commands;

import java.util.Iterator;
import minealex.tchat.OrdaChat;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class AnnouncementCommand implements CommandExecutor {
   private final OrdaChat plugin;

   public AnnouncementCommand(OrdaChat plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      String message;
      if (!sender.hasPermission("tchat.admin.announcement") && !sender.hasPermission("tchat.admin")) {
         message = this.plugin.getMessagesManager().getNoPermission();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
      } else {
         if (args.length == 0) {
            message = this.plugin.getMessagesManager().getUsageAnnouncement();
            sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
            return true;
         }

         message = String.join(" ", args);
         String format = this.plugin.getConfigManager().getAnnouncementFormat();
         format = format.replace("%message%", message);
         Iterator var8 = Bukkit.getOnlinePlayers().iterator();

         while(var8.hasNext()) {
            Player player = (Player)var8.next();
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, format));
         }
      }

      return true;
   }
}
