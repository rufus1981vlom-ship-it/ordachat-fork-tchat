package utils;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Map.Entry;
import minealex.tchat.OrdaChat;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

public class Poll {
   private static Poll currentPoll;
   private final OrdaChat plugin;
   private final String title;
   private final long endTime;
   private final Map<Player, String> votes;
   private final String[] options;
   private final int minPlayers;
   private final int maxPlayers;

   public Poll(OrdaChat plugin, String title, int duration, String[] options, int minPlayers, int maxPlayers) {
      this.plugin = plugin;
      this.title = title;
      this.endTime = System.currentTimeMillis() + (long)duration * 1000L;
      this.votes = new HashMap();
      this.options = options;
      this.minPlayers = minPlayers;
      this.maxPlayers = maxPlayers;
   }

   public String getTitle() {
      return this.title;
   }

   public boolean hasEnded() {
      return System.currentTimeMillis() > this.endTime;
   }

   public void vote(Player player, String option) {
      if (!this.hasEnded() && this.isValidOption(option)) {
         this.votes.put(player, option);
         if (this.votes.size() >= this.maxPlayers) {
            this.finalizePoll();
         }
      }

   }

   public String[] getOptions() {
      return this.options;
   }

   public Map<String, Integer> getResults() {
      Map<String, Integer> results = new HashMap();
      String[] var2 = this.options;
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         String option = var2[var4];
         results.put(option, 0);
      }

      Iterator var6 = this.votes.values().iterator();

      while(var6.hasNext()) {
         String vote = (String)var6.next();
         results.put(vote, (Integer)results.get(vote) + 1);
      }

      return results;
   }

   public boolean isValidOption(String option) {
      String[] var2 = this.options;
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         String o = var2[var4];
         if (o.equalsIgnoreCase(option)) {
            return true;
         }
      }

      return false;
   }

   public void finalizePoll() {
      if (this.votes.size() >= this.minPlayers) {
         if (this.hasEnded()) {
            Map<String, Integer> results = this.getResults();
            String optionLine = this.plugin.getMessagesManager().getOptionLine();
            String progressBarFormat = this.plugin.getMessagesManager().getProgressBar();
            String endTitle = this.plugin.getMessagesManager().getEndTitle();
            String endTextTitle = this.plugin.getMessagesManager().getEndTextTitle();
            endTitle = endTitle != null ? endTitle : "";
            endTextTitle = endTextTitle != null ? endTextTitle : "";
            StringBuilder resultsMessage = new StringBuilder(this.plugin.getTranslateColors().translateColors((Player)null, endTitle));
            resultsMessage.append(this.plugin.getTranslateColors().translateColors((Player)null, endTextTitle)).append(this.getTitle()).append("\n");
            int totalVotes = results.values().stream().mapToInt(Integer::intValue).sum();
            int BAR_LENGTH = this.plugin.getConfigManager().getPollBar();
            Iterator var9 = results.entrySet().iterator();

            while(var9.hasNext()) {
               Entry<String, Integer> entry = (Entry)var9.next();
               String option = (String)entry.getKey();
               int voteCount = (Integer)entry.getValue();
               double percentage = totalVotes > 0 ? (double)voteCount * 100.0D / (double)totalVotes : 0.0D;
               int filledBlocks = (int)(percentage / 100.0D * (double)BAR_LENGTH);
               int emptyBlocks = BAR_LENGTH - filledBlocks;
               String progressBar = ChatColor.translateAlternateColorCodes('&', progressBarFormat.replace("%filled%", String.valueOf(this.plugin.getConfigManager().getPollFill()).repeat(filledBlocks)).replace("%empty%", String.valueOf(this.plugin.getConfigManager().getPollEmpty()).repeat(emptyBlocks)));
               String formattedOptionLine = ChatColor.translateAlternateColorCodes('&', optionLine.replace("%option%", option).replace("%votes%", String.valueOf(voteCount)).replace("%.2f%%", String.format("%.2f", percentage)));
               resultsMessage.append(formattedOptionLine).append("\n").append(progressBar).append("\n");
            }

            String messageToSend = this.plugin.getTranslateColors().translateColors((Player)null, resultsMessage.toString());
            Bukkit.broadcastMessage(((String)Objects.requireNonNullElse(messageToSend, resultsMessage.toString())).trim());
            setCurrentPoll((Poll)null);
         }
      }
   }

   public static Poll getCurrentPoll() {
      return currentPoll;
   }

   public static void setCurrentPoll(Poll poll) {
      currentPoll = poll;
   }
}
