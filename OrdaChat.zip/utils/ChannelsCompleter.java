package utils;

import config.ChannelsConfigManager;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import minealex.tchat.OrdaChat;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class ChannelsCompleter implements TabCompleter {
   private final OrdaChat plugin;

   public ChannelsCompleter(OrdaChat plugin) {
      this.plugin = plugin;
   }

   public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, @NotNull String[] args) {
      if (!(sender instanceof Player)) {
         return new ArrayList();
      } else {
         Player player = (Player)sender;
         if (args.length == 1) {
            List<String> commands = new ArrayList();
            if (player.hasPermission("tchat.channel.command.join") || player.hasPermission("tchat.admin") || player.hasPermission("tchat.channel.all")) {
               commands.add("join");
            }

            if (player.hasPermission("tchat.channel.command.leave") || player.hasPermission("tchat.admin") || player.hasPermission("tchat.channel.all")) {
               commands.add("leave");
            }

            if (player.hasPermission("tchat.channel.command.send") || player.hasPermission("tchat.admin") || player.hasPermission("tchat.channel.all")) {
               commands.add("send");
            }

            return (List)commands.stream().filter((cmd) -> {
               return cmd.startsWith(args[0]);
            }).collect(Collectors.toList());
         } else {
            if (args.length == 2) {
               String action = args[0];
               Map channels;
               List filteredChannels;
               if ("join".equalsIgnoreCase(action) || "leave".equalsIgnoreCase(action)) {
                  channels = this.plugin.getChannelsConfigManager().getChannels();
                  filteredChannels = channels.keySet().stream().filter((channelName) -> {
                     if (!"join".equalsIgnoreCase(action)) {
                        return "leave".equalsIgnoreCase(action) ? channelName.equalsIgnoreCase(this.plugin.getChannelsManager().getPlayerChannel(player)) : false;
                     } else {
                        ChannelsConfigManager.Channel channel = (ChannelsConfigManager.Channel)channels.get(channelName);
                        return player.hasPermission(channel.permission()) || player.hasPermission("tchat.admin") || player.hasPermission("tchat.channel.all");
                     }
                  }).toList();
                  return (List)filteredChannels.stream().filter((channelName) -> {
                     return channelName.startsWith(args[1]);
                  }).collect(Collectors.toList());
               }

               if ("send".equalsIgnoreCase(action)) {
                  channels = this.plugin.getChannelsConfigManager().getChannels();
                  filteredChannels = channels.keySet().stream().filter((channelName) -> {
                     return player.hasPermission(((ChannelsConfigManager.Channel)channels.get(channelName)).permission()) || player.hasPermission("tchat.admin") || player.hasPermission("tchat.channel.all");
                  }).toList();
                  return (List)filteredChannels.stream().filter((channelName) -> {
                     return channelName.startsWith(args[1]);
                  }).collect(Collectors.toList());
               }
            } else if (args.length > 2 && "send".equalsIgnoreCase(args[0])) {
               return new ArrayList();
            }

            return new ArrayList();
         }
      }
   }
}
