package utils;

import config.CommandProgrammerManager;
import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import minealex.tchat.OrdaChat;
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitRunnable;
import org.jetbrains.annotations.NotNull;

public class CommandProgrammerSender {
   private final OrdaChat plugin;
   private final CommandProgrammerManager manager;
   private final Map<String, LocalDateTime> lastExecutionTimes = new HashMap();

   public CommandProgrammerSender(OrdaChat plugin, CommandProgrammerManager manager) {
      this.plugin = plugin;
      this.manager = manager;
      this.startScheduler();
   }

   private void startScheduler() {
      if (!this.plugin.getCommandProgrammerManager().isEnabled()) {
         (new BukkitRunnable() {
            public void run() {
               CommandProgrammerSender.this.checkAndExecuteCommands();
            }
         }).runTaskTimer(this.plugin, 0L, 20L);
      }
   }

   private void checkAndExecuteCommands() {
      LocalDateTime now = LocalDateTime.now();
      boolean commandExecuted = false;
      Iterator var3 = this.manager.getHourlyCommands().iterator();

      while(true) {
         CommandProgrammerManager.CommandSchedule schedule;
         LocalDateTime lastExecution;
         do {
            do {
               do {
                  if (!var3.hasNext()) {
                     var3 = this.manager.getDailyCommands().iterator();

                     while(true) {
                        do {
                           do {
                              do {
                                 do {
                                    do {
                                       if (!var3.hasNext()) {
                                          var3 = this.manager.getWeeklyCommands().iterator();

                                          while(true) {
                                             do {
                                                do {
                                                   do {
                                                      do {
                                                         do {
                                                            if (!var3.hasNext()) {
                                                               var3 = this.manager.getMonthlyCommands().iterator();

                                                               while(true) {
                                                                  do {
                                                                     do {
                                                                        do {
                                                                           do {
                                                                              do {
                                                                                 do {
                                                                                    if (!var3.hasNext()) {
                                                                                       var3 = this.manager.getYearlyCommands().iterator();

                                                                                       while(true) {
                                                                                          do {
                                                                                             do {
                                                                                                do {
                                                                                                   do {
                                                                                                      do {
                                                                                                         do {
                                                                                                            if (!var3.hasNext()) {
                                                                                                               if (commandExecuted) {
                                                                                                                  Bukkit.getLogger().info("Commands executed at " + now);
                                                                                                               }

                                                                                                               return;
                                                                                                            }

                                                                                                            schedule = (CommandProgrammerManager.CommandSchedule)var3.next();
                                                                                                         } while(schedule.getHour() != now.getHour());
                                                                                                      } while(schedule.getMinute() != now.getMinute());
                                                                                                   } while(now.getDayOfMonth() != schedule.getDay());
                                                                                                } while(now.getMonth() != Month.of(schedule.getMonth()));
                                                                                             } while(!this.checkPlayers(schedule.getPlayers()));

                                                                                             lastExecution = (LocalDateTime)this.lastExecutionTimes.get("yearly");
                                                                                          } while(lastExecution != null && lastExecution.toLocalDate().equals(now.toLocalDate()) && lastExecution.getMonth() == now.getMonth() && lastExecution.getDayOfMonth() == now.getDayOfMonth());

                                                                                          this.executeCommands(schedule.getCommands());
                                                                                          this.lastExecutionTimes.put("yearly", now);
                                                                                          commandExecuted = true;
                                                                                       }
                                                                                    }

                                                                                    schedule = (CommandProgrammerManager.CommandSchedule)var3.next();
                                                                                 } while(schedule.getHour() != now.getHour());
                                                                              } while(schedule.getMinute() != now.getMinute());
                                                                           } while(now.getDayOfMonth() != schedule.getDay());
                                                                        } while(now.getMonth() != Month.of(schedule.getMonth()));
                                                                     } while(!this.checkPlayers(schedule.getPlayers()));

                                                                     lastExecution = (LocalDateTime)this.lastExecutionTimes.get("monthly");
                                                                  } while(lastExecution != null && lastExecution.toLocalDate().equals(now.toLocalDate()) && lastExecution.getMonth() == now.getMonth() && lastExecution.getDayOfMonth() == now.getDayOfMonth());

                                                                  this.executeCommands(schedule.getCommands());
                                                                  this.lastExecutionTimes.put("monthly", now);
                                                                  commandExecuted = true;
                                                               }
                                                            }

                                                            schedule = (CommandProgrammerManager.CommandSchedule)var3.next();
                                                         } while(schedule.getHour() != now.getHour());
                                                      } while(schedule.getMinute() != now.getMinute());
                                                   } while(now.getDayOfWeek() != DayOfWeek.of(schedule.getDay()));
                                                } while(!this.checkPlayers(schedule.getPlayers()));

                                                lastExecution = (LocalDateTime)this.lastExecutionTimes.get("weekly");
                                             } while(lastExecution != null && lastExecution.toLocalDate().equals(now.toLocalDate()) && lastExecution.getDayOfWeek() == now.getDayOfWeek());

                                             this.executeCommands(schedule.getCommands());
                                             this.lastExecutionTimes.put("weekly", now);
                                             commandExecuted = true;
                                          }
                                       }

                                       schedule = (CommandProgrammerManager.CommandSchedule)var3.next();
                                    } while(schedule.getHour() != now.getHour());
                                 } while(schedule.getMinute() != now.getMinute());
                              } while(now.getDayOfMonth() != schedule.getDay());
                           } while(!this.checkPlayers(schedule.getPlayers()));

                           lastExecution = (LocalDateTime)this.lastExecutionTimes.get("daily");
                        } while(lastExecution != null && lastExecution.toLocalDate().equals(now.toLocalDate()));

                        this.executeCommands(schedule.getCommands());
                        this.lastExecutionTimes.put("daily", now);
                        commandExecuted = true;
                     }
                  }

                  schedule = (CommandProgrammerManager.CommandSchedule)var3.next();
               } while(schedule.getMinute() != now.getMinute());
            } while(!this.checkPlayers(schedule.getPlayers()));

            lastExecution = (LocalDateTime)this.lastExecutionTimes.get("hourly");
         } while(lastExecution != null && lastExecution.toLocalDate().equals(now.toLocalDate()) && lastExecution.getHour() == now.getHour());

         this.executeCommands(schedule.getCommands());
         this.lastExecutionTimes.put("hourly", now);
         commandExecuted = true;
      }
   }

   private boolean checkPlayers(int requiredPlayers) {
      return requiredPlayers <= Bukkit.getOnlinePlayers().size();
   }

   private void executeCommands(@NotNull List<String> commands) {
      Iterator var2 = commands.iterator();

      while(var2.hasNext()) {
         String command = (String)var2.next();
         Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), command);
      }

   }
}
