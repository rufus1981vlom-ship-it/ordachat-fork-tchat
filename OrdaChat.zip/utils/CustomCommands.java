package utils;

import config.CommandsManager;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import me.clip.placeholderapi.PlaceholderAPI;
import minealex.tchat.OrdaChat;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.chat.ClickEvent.Action;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.jetbrains.annotations.NotNull;

public class CustomCommands implements Listener {
   private final OrdaChat plugin;
   private final CommandsManager commandsManager;
   private final Map<UUID, Long> commandCooldowns = new HashMap();
   private int currentIteration;

   public CustomCommands(@NotNull OrdaChat plugin) {
      this.plugin = plugin;
      this.commandsManager = plugin.getCommandsManager();
      Bukkit.getPluginManager().registerEvents(this, plugin);
   }

   @EventHandler
   public void onPlayerCommand(@NotNull PlayerCommandPreprocessEvent e) {
      if (!e.isCancelled()) {
         Player player = e.getPlayer();
         String message = e.getMessage();
         if (message.startsWith("/")) {
            String[] commandArgs = message.substring(1).split(" ");
            String commandName = commandArgs[0].toLowerCase();
            if (this.commandsManager.getCommands().containsKey(commandName)) {
               String prefix = this.plugin.getMessagesManager().getPrefix();
               CommandsManager.Command command = (CommandsManager.Command)this.commandsManager.getCommands().get(commandName);
               boolean allowArgs = command.args();
               String permission;
               if (allowArgs && commandArgs.length < 2) {
                  permission = this.plugin.getMessagesManager().getCustomCommandsArguments();
                  player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + permission));
                  e.setCancelled(true);
                  return;
               }

               if (command.permissionRequired()) {
                  permission = "tchat.customcommand." + commandName;
                  if (!player.hasPermission(permission) && !player.hasPermission("tchat.admin")) {
                     String message1 = this.plugin.getMessagesManager().getNoPermission();
                     player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message1));
                     e.setCancelled(true);
                     return;
                  }
               }

               int cooldownSeconds = this.getCooldown(commandName);
               if (cooldownSeconds > 0 && this.isOnCooldown(player, commandName, cooldownSeconds)) {
                  int remainingCooldown = this.getRemainingCooldown(player, commandName);
                  String message1 = this.plugin.getMessagesManager().getCustomCommandsCooldown();
                  message1 = message1.replace("%cooldown%", String.valueOf(remainingCooldown));
                  player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message1));
                  e.setCancelled(true);
                  return;
               }

               List<String> actions = command.actions();
               this.processActions(player, actions, allowArgs ? message.substring(commandArgs[0].length() + 1) : null);
               if (cooldownSeconds > 0) {
                  this.setCooldown(player, commandName, cooldownSeconds);
               }

               e.setCancelled(true);
            }
         }

      }
   }

   private void processActions(Player player, @NotNull List<String> actions, String args) {
      boolean isIfBlock = false;
      boolean isElseIfBlock = false;
      boolean skipActions = false;
      boolean inConditional = false;
      boolean inLoop = false;
      boolean inWhileLoop = false;
      AtomicBoolean breakLoop = new AtomicBoolean(false);
      AtomicBoolean returnCondition = new AtomicBoolean(false);
      List<String> loopActions = new ArrayList();
      String originalWhileCondition = "";
      int loopCount = 0;
      this.currentIteration = 0;
      Iterator var15 = actions.iterator();

      while(var15.hasNext()) {
         String action = (String)var15.next();
         if (returnCondition.get()) {
            break;
         }

         if (action.startsWith("[WHILE]")) {
            if (inWhileLoop) {
               skipActions = true;
            } else {
               originalWhileCondition = action.substring(7).trim();
               loopActions = new ArrayList();
               inWhileLoop = true;
            }
         } else if (action.startsWith("[ELIHW]")) {
            if (inWhileLoop) {
               inWhileLoop = false;
               List<String> finalLoopActions = new ArrayList(loopActions);
               Bukkit.getScheduler().runTaskAsynchronously(this.plugin, () -> {
                  for(this.currentIteration = 1; !returnCondition.get(); ++this.currentIteration) {
                     String evaluatedCondition = this.processPlaceholders(player, originalWhileCondition);
                     if (!this.evaluateCondition(evaluatedCondition, player) || breakLoop.get()) {
                        break;
                     }

                     Iterator var8 = finalLoopActions.iterator();

                     while(var8.hasNext()) {
                        String loopAction = (String)var8.next();
                        if (returnCondition.get()) {
                           break;
                        }

                        String evaluatedAction = this.processPlaceholders(player, loopAction);
                        evaluatedAction = evaluatedAction.replace("%i%", String.valueOf(this.currentIteration));
                        this.executeAction(player, evaluatedAction, args);
                     }
                  }

                  breakLoop.set(false);
               });
            } else {
               skipActions = true;
            }
         } else if (action.startsWith("[FOR]")) {
            if (inLoop) {
               skipActions = true;
            } else {
               try {
                  loopCount = Integer.parseInt(action.substring(5).trim());
                  loopActions = new ArrayList();
                  inLoop = true;
               } catch (NumberFormatException var21) {
                  this.plugin.getLogger().warning("Invalid number in [FOR]: " + action);
                  skipActions = true;
               }
            }
         } else if (!action.startsWith("[ROF]")) {
            if (!inWhileLoop && !inLoop) {
               String condition;
               if (action.startsWith("[IF]")) {
                  if (inConditional) {
                     skipActions = true;
                  } else {
                     condition = action.substring(4).trim();
                     condition = condition.replace("%i%", String.valueOf(this.currentIteration));
                     isIfBlock = this.evaluateCondition(condition, player);
                     skipActions = !isIfBlock;
                     inConditional = true;
                  }
               } else if (action.startsWith("[ELSE IF]")) {
                  if (inConditional && !isIfBlock) {
                     condition = action.substring(9).trim();
                     condition = condition.replace("%i%", String.valueOf(this.currentIteration));
                     isElseIfBlock = this.evaluateCondition(condition, player);
                     skipActions = !isElseIfBlock;
                  } else {
                     skipActions = true;
                  }
               } else if (action.startsWith("[ELSE]")) {
                  if (inConditional && !isIfBlock && !isElseIfBlock) {
                     isIfBlock = true;
                     skipActions = false;
                  } else {
                     skipActions = true;
                  }
               } else if (action.startsWith("[FI]")) {
                  inConditional = false;
                  isIfBlock = false;
                  isElseIfBlock = false;
                  skipActions = false;
               } else if (action.startsWith("[RETURN]")) {
                  if (isIfBlock || isElseIfBlock) {
                     returnCondition.set(true);
                     break;
                  }
               } else if (!skipActions) {
                  this.executeAction(player, action, args);
               }
            } else {
               loopActions.add(action);
            }
         } else if (!inLoop) {
            skipActions = true;
         } else {
            inLoop = false;

            for(this.currentIteration = 1; this.currentIteration <= loopCount; ++this.currentIteration) {
               Iterator var17 = loopActions.iterator();

               while(var17.hasNext()) {
                  String loopAction = (String)var17.next();
                  if (returnCondition.get()) {
                     break;
                  }

                  String evaluatedAction = this.processPlaceholders(player, loopAction);
                  evaluatedAction = evaluatedAction.replace("%i%", String.valueOf(this.currentIteration));
                  String condition;
                  if (evaluatedAction.startsWith("[IF]")) {
                     condition = evaluatedAction.substring(4).trim();
                     condition = condition.replace("%i%", String.valueOf(this.currentIteration));
                     skipActions = !this.evaluateCondition(condition, player);
                     inConditional = true;
                  } else if (evaluatedAction.startsWith("[ELSE IF]")) {
                     if (inConditional && !isIfBlock) {
                        condition = evaluatedAction.substring(9).trim();
                        condition = condition.replace("%i%", String.valueOf(this.currentIteration));
                        skipActions = !this.evaluateCondition(condition, player);
                     } else {
                        skipActions = true;
                     }
                  } else if (!evaluatedAction.startsWith("[ELSE]")) {
                     if (evaluatedAction.startsWith("[FI]")) {
                        inConditional = false;
                        isIfBlock = false;
                        isElseIfBlock = false;
                        skipActions = false;
                     } else if (!skipActions) {
                        if (evaluatedAction.startsWith("[BREAK]")) {
                           breakLoop.set(true);
                           break;
                        }

                        this.executeAction(player, evaluatedAction, args);
                     }
                  } else {
                     skipActions = !inConditional || isIfBlock || isElseIfBlock;
                  }
               }

               if (breakLoop.get() || returnCondition.get()) {
                  break;
               }
            }

            this.currentIteration = 0;
            breakLoop.set(false);
         }
      }

   }

   private boolean evaluateCondition(@NotNull String condition, Player player) {
      String[] orConditions = condition.split("\\|\\|");
      boolean finalResult = false;
      String[] var5 = orConditions;
      int var6 = orConditions.length;

      for(int var7 = 0; var7 < var6; ++var7) {
         String orCondition = var5[var7];
         String[] andConditions = orCondition.split("&&");
         boolean orResult = true;
         String[] var11 = andConditions;
         int var12 = andConditions.length;

         for(int var13 = 0; var13 < var12; ++var13) {
            String andCondition = var11[var13];
            boolean result = this.evaluateSingleCondition(andCondition.trim(), player);
            orResult = orResult && result;
         }

         finalResult = finalResult || orResult;
      }

      return finalResult;
   }

   private boolean evaluateSingleCondition(String condition, Player player) {
      condition = this.processPlaceholders(player, condition);
      Pattern pattern = Pattern.compile("(.+?)\\s*(>=|<=|>|<|==|!=)\\s*(.+)");
      Matcher matcher = pattern.matcher(condition);
      if (matcher.matches()) {
         String leftSide = matcher.group(1).trim();
         String operator = matcher.group(2);
         String rightSide = matcher.group(3).trim();
         boolean isNumericComparison = false;
         double leftValue = 0.0D;
         double rightValue = 0.0D;

         try {
            leftValue = Double.parseDouble(leftSide);
            rightValue = Double.parseDouble(rightSide);
            isNumericComparison = true;
         } catch (NumberFormatException var16) {
         }

         boolean result;
         byte var15;
         boolean var10000;
         if (isNumericComparison) {
            var15 = -1;
            switch(operator.hashCode()) {
            case 60:
               if (operator.equals("<")) {
                  var15 = 3;
               }
               break;
            case 62:
               if (operator.equals(">")) {
                  var15 = 2;
               }
               break;
            case 1084:
               if (operator.equals("!=")) {
                  var15 = 5;
               }
               break;
            case 1921:
               if (operator.equals("<=")) {
                  var15 = 1;
               }
               break;
            case 1952:
               if (operator.equals("==")) {
                  var15 = 4;
               }
               break;
            case 1983:
               if (operator.equals(">=")) {
                  var15 = 0;
               }
            }

            switch(var15) {
            case 0:
               var10000 = leftValue >= rightValue;
               break;
            case 1:
               var10000 = leftValue <= rightValue;
               break;
            case 2:
               var10000 = leftValue > rightValue;
               break;
            case 3:
               var10000 = leftValue < rightValue;
               break;
            case 4:
               var10000 = leftValue == rightValue;
               break;
            case 5:
               var10000 = leftValue != rightValue;
               break;
            default:
               var10000 = false;
            }

            result = var10000;
         } else {
            var15 = -1;
            switch(operator.hashCode()) {
            case 1084:
               if (operator.equals("!=")) {
                  var15 = 1;
               }
               break;
            case 1952:
               if (operator.equals("==")) {
                  var15 = 0;
               }
               break;
            case 1955:
               if (operator.equals("=@")) {
                  var15 = 3;
               }
               break;
            case 2017:
               if (operator.equals("=~")) {
                  var15 = 2;
               }
            }

            switch(var15) {
            case 0:
               var10000 = leftSide.equals(rightSide);
               break;
            case 1:
               var10000 = !leftSide.equals(rightSide);
               break;
            case 2:
               var10000 = leftSide.matches(rightSide);
               break;
            case 3:
               var10000 = leftSide.matches(rightSide.replace("*", ".*"));
               break;
            default:
               var10000 = false;
            }

            result = var10000;
         }

         return result;
      } else {
         return false;
      }
   }

   @NotNull
   private String processPlaceholders(Player player, String text) {
      return PlaceholderAPI.setPlaceholders(player, text);
   }

   private void executeAction(Player player, @NotNull String action, String args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      String[] parts = action.split(" ", 2);
      if (parts.length >= 2) {
         String type = parts[0].trim();
         String data = parts[1].trim();
         if (data.startsWith("'") && data.endsWith("'")) {
            data = data.substring(1, data.length() - 1);
         }

         data = data.replace("%prefix%", prefix);
         data = data.replace("%i%", String.valueOf(this.currentIteration));
         data = data.replace("%player%", player.getName());
         int spaces = Math.max(56 - data.length(), 0);
         String center = " ".repeat(spaces);
         data = data.replace("%center%", center);
         if (args != null) {
            String modifiedArgs = args.substring(1);
            data = data.replace("%args%", modifiedArgs);
         }

         byte var11 = -1;
         switch(type.hashCode()) {
         case -1667629064:
            if (type.equals("[ACTION_BAR]")) {
               var11 = 8;
            }
            break;
         case -1615988247:
            if (type.equals("[MUTE]")) {
               var11 = 19;
            }
            break;
         case -1427819369:
            if (type.equals("[TELEPORT]")) {
               var11 = 6;
            }
            break;
         case -1035147923:
            if (type.equals("[CHATCOLOR]")) {
               var11 = 12;
            }
            break;
         case -949066063:
            if (type.equals("[MESSAGE]")) {
               var11 = 0;
            }
            break;
         case -210937384:
            if (type.equals("[BUNGEECORD]")) {
               var11 = 9;
            }
            break;
         case -171087013:
            if (type.equals("[POTION_EFFECT]")) {
               var11 = 7;
            }
            break;
         case -23746443:
            if (type.equals("[PLAYER_COMMAND]")) {
               var11 = 2;
            }
            break;
         case 2798122:
            if (type.equals("[XP]")) {
               var11 = 16;
            }
            break;
         case 11119036:
            if (type.equals("[WARNING]")) {
               var11 = 18;
            }
            break;
         case 283420828:
            if (type.equals("[PARTICLE]")) {
               var11 = 5;
            }
            break;
         case 301404917:
            if (type.equals("[CONSOLE_COMMAND]")) {
               var11 = 3;
            }
            break;
         case 521007199:
            if (type.equals("[GLOBAL]")) {
               var11 = 13;
            }
            break;
         case 625352571:
            if (type.equals("[ANNOUNCEMENT]")) {
               var11 = 21;
            }
            break;
         case 1165364373:
            if (type.equals("[CLICK_ACTION]")) {
               var11 = 11;
            }
            break;
         case 1171011749:
            if (type.equals("[DEBUG]")) {
               var11 = 20;
            }
            break;
         case 1400625556:
            if (type.equals("[LEVEL]")) {
               var11 = 17;
            }
            break;
         case 1525720695:
            if (type.equals("[BROADCAST]")) {
               var11 = 14;
            }
            break;
         case 1606987937:
            if (type.equals("[SLEEP]")) {
               var11 = 15;
            }
            break;
         case 1610243433:
            if (type.equals("[SOUND]")) {
               var11 = 4;
            }
            break;
         case 1633299776:
            if (type.equals("[TITLE]")) {
               var11 = 1;
            }
            break;
         case 1957202236:
            if (type.equals("[INVENTORY]")) {
               var11 = 10;
            }
         }

         String actionType;
         String actionType;
         String unit;
         String format2;
         int durationInTicks;
         switch(var11) {
         case 0:
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, data));
            break;
         case 1:
            String[] titleParts = data.split(";");
            if (titleParts.length == 2) {
               player.sendTitle(titleParts[0], titleParts[1], 10, 70, 20);
            }
            break;
         case 2:
            player.performCommand(data);
            break;
         case 3:
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), data);
            break;
         case 4:
            player.playSound(player.getLocation(), Sound.valueOf(data), 1.0F, 1.0F);
            break;
         case 5:
            player.spawnParticle(Particle.valueOf(data), player.getLocation(), 100, 1.0D, 1.0D, 1.0D);
            break;
         case 6:
            String[] teleportParts = data.split(";");
            if (teleportParts.length == 4) {
               World world = Bukkit.getWorld(teleportParts[0]);
               if (world != null) {
                  Location location = new Location(world, Double.parseDouble(teleportParts[1]), Double.parseDouble(teleportParts[2]), Double.parseDouble(teleportParts[3]));
                  player.teleport(location);
               }
            }
            break;
         case 7:
            String[] effectParts = data.split(" ");
            if (effectParts.length >= 2) {
               actionType = effectParts[0].toUpperCase();
               String effectData = effectParts[1].trim();
               String[] effectParams = effectData.split(":");
               unit = effectParams[0].toUpperCase();
               durationInTicks = 0;
               int amplifier = 0;
               if (effectParams.length == 2) {
                  try {
                     durationInTicks = Integer.parseInt(effectParams[1]) * 20;
                  } catch (NumberFormatException var31) {
                     this.plugin.getLogger().warning("Invalid duration format: " + effectParams[1]);
                     return;
                  }
               } else if (effectParams.length == 3) {
                  try {
                     durationInTicks = Integer.parseInt(effectParams[1]) * 20;
                     amplifier = Integer.parseInt(effectParams[2]);
                  } catch (NumberFormatException var30) {
                     this.plugin.getLogger().warning("Invalid duration or amplifier format: " + effectParams[1] + ", " + effectParams[2]);
                     return;
                  }
               }

               PotionEffectType potion = PotionEffectType.getByName(unit);
               if (potion != null) {
                  if (actionType.equals("ADD")) {
                     player.addPotionEffect(new PotionEffect(potion, durationInTicks, amplifier));
                  } else if (actionType.equals("REMOVE")) {
                     player.removePotionEffect(potion);
                  } else {
                     this.plugin.getLogger().warning("Invalid potion effect action type: " + actionType);
                  }
               } else {
                  this.plugin.getLogger().warning("Invalid potion effect type: " + unit);
               }
            } else {
               this.plugin.getLogger().warning("Invalid potion effect format: " + data + " (Expected format: ACTION EFFECT:PARAMS)");
            }
            break;
         case 8:
            actionType = this.plugin.getTranslateColors().translateColors(player, data);
            player.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText(actionType));
            break;
         case 9:
            this.sendPlayerToBungeeServer(player, data);
            break;
         case 10:
            String[] inventoryParts = data.split(" ");
            if (inventoryParts.length >= 3) {
               actionType = inventoryParts[0];
               unit = inventoryParts[1];

               try {
                  durationInTicks = Integer.parseInt(inventoryParts[2]);
               } catch (NumberFormatException var29) {
                  this.plugin.getLogger().warning("Invalid quantity format: " + inventoryParts[2]);
                  return;
               }

               Material material = Material.valueOf(unit);
               ItemStack item = new ItemStack(material, durationInTicks);
               if (inventoryParts.length >= 4) {
                  String itemName2 = inventoryParts[3];
                  Material material2 = Material.valueOf(itemName2);
                  ItemStack item2 = new ItemStack(material2, durationInTicks);
                  if (actionType.equals("CHANGE") && player.getInventory().contains(item)) {
                     player.getInventory().removeItem(new ItemStack[]{item});
                     player.getInventory().addItem(new ItemStack[]{item2});
                  }
               } else if (actionType.equals("ADD")) {
                  player.getInventory().addItem(new ItemStack[]{item});
               } else if (actionType.equals("REMOVE")) {
                  player.getInventory().removeItem(new ItemStack[]{item});
               }
            } else {
               this.plugin.getLogger().warning("Invalid inventory action format: " + data);
            }
            break;
         case 11:
            this.handleClickAction(player, data);
            break;
         case 12:
            this.handleChatColorAction(player, data);
            break;
         case 13:
            Bukkit.broadcastMessage(this.plugin.getTranslateColors().translateColors(player, data));
            break;
         case 14:
            actionType = this.plugin.getConfigManager().getBroadcastFormat();
            actionType = actionType.replace("%message%", data);
            Bukkit.broadcastMessage(this.plugin.getTranslateColors().translateColors(player, actionType));
            break;
         case 15:
            unit = data.substring(data.length() - 1);

            long time;
            try {
               time = Long.parseLong(data.substring(0, data.length() - 1));
            } catch (NumberFormatException var28) {
               this.plugin.getLogger().warning("Invalid sleep time format: " + data);
               return;
            }

            byte var40 = -1;
            switch(unit.hashCode()) {
            case 109:
               if (unit.equals("m")) {
                  var40 = 2;
               }
               break;
            case 115:
               if (unit.equals("s")) {
                  var40 = 0;
               }
               break;
            case 116:
               if (unit.equals("t")) {
                  var40 = 1;
               }
            }

            switch(var40) {
            case 0:
               time *= 1000L;
               break;
            case 1:
               time *= 50L;
            case 2:
               break;
            default:
               this.plugin.getLogger().warning("Invalid time unit for [SLEEP]: " + unit);
               return;
            }

            try {
               Thread.sleep(time);
            } catch (InterruptedException var27) {
               Thread.currentThread().interrupt();
            }
            break;
         case 16:
            this.handleXPAction(player, data);
            break;
         case 17:
            this.handleLevelAction(player, data);
            break;
         case 18:
            String format1 = this.plugin.getConfigManager().getWarningFormat();
            format1 = format1.replace("%message%", data);
            Bukkit.broadcastMessage(this.plugin.getTranslateColors().translateColors(player, format1));
            break;
         case 19:
            this.handleMuteAction(player, data);
            break;
         case 20:
            String[] parts1 = data.split(" ", 2);
            if (parts1.length < 2) {
               return;
            }

            String debugMode = parts1[0].trim();
            String debugData = parts1[1].trim();
            debugData = this.plugin.getTranslateColors().translateColors(player, debugData);
            format2 = debugMode.toUpperCase();
            byte var26 = -1;
            switch(format2.hashCode()) {
            case -1852393868:
               if (format2.equals("SEVERE")) {
                  var26 = 2;
               }
               break;
            case 2251950:
               if (format2.equals("INFO")) {
                  var26 = 1;
               }
               break;
            case 64921139:
               if (format2.equals("DEBUG")) {
                  var26 = 3;
               }
               break;
            case 66247144:
               if (format2.equals("ERROR")) {
                  var26 = 4;
               }
               break;
            case 1842428796:
               if (format2.equals("WARNING")) {
                  var26 = 0;
               }
            }

            switch(var26) {
            case 0:
               this.plugin.getLogger().warning(debugData);
               break;
            case 1:
               this.plugin.getLogger().info(debugData);
               break;
            case 2:
               this.plugin.getLogger().severe(debugData);
               break;
            case 3:
               this.plugin.getLogger().fine(debugData);
               break;
            case 4:
               this.plugin.getLogger().severe("ERROR: " + debugData);
               break;
            default:
               this.plugin.getLogger().info("DEFAULT: " + debugData);
            }
         case 21:
            format2 = this.plugin.getConfigManager().getAnnouncementFormat();
            format2 = format2.replace("%message%", data);
            Bukkit.broadcastMessage(this.plugin.getTranslateColors().translateColors(player, format2));
            break;
         default:
            this.plugin.getLogger().warning("Unknown action type: " + type);
            this.plugin.getLogger().warning("Action: " + data);
         }

      }
   }

   private void handleMuteAction(Player player, @NotNull String data) {
      String timePart = data.trim();
      long duration = this.parseTime(timePart);
      if (duration == 0L) {
         this.plugin.getLogger().warning("Invalid time format for [MUTE]: " + timePart);
      } else {
         this.plugin.getSaveManager().mutePlayer(player.getUniqueId(), duration);
         String p = this.plugin.getMessagesManager().getPrefix();
         String m;
         if (duration == -1L) {
            m = this.plugin.getMessagesManager().getMutePermanent();
         } else {
            m = this.plugin.getMessagesManager().getMuteTemp().replace("%time%", timePart);
         }

         player.sendMessage(this.plugin.getTranslateColors().translateColors(player, p + m));
      }
   }

   private long parseTime(@NotNull String duration) throws IllegalArgumentException {
      char timeUnit = duration.charAt(duration.length() - 1);
      long timeValue = Long.parseLong(duration.substring(0, duration.length() - 1));
      String p = this.plugin.getMessagesManager().getPrefix();
      String m = this.plugin.getMessagesManager().getMuteInvalidUnit();
      long var10000;
      switch(timeUnit) {
      case 'M':
         var10000 = TimeUnit.DAYS.toMillis(timeValue * 30L);
         break;
      case 'd':
         var10000 = TimeUnit.DAYS.toMillis(timeValue);
         break;
      case 'h':
         var10000 = TimeUnit.HOURS.toMillis(timeValue);
         break;
      case 'm':
         var10000 = TimeUnit.MINUTES.toMillis(timeValue);
         break;
      case 's':
         var10000 = TimeUnit.SECONDS.toMillis(timeValue);
         break;
      case 'w':
         var10000 = TimeUnit.DAYS.toMillis(timeValue * 7L);
         break;
      default:
         throw new IllegalArgumentException(this.plugin.getTranslateColors().translateColors((Player)null, p + m));
      }

      return var10000;
   }

   private void handleXPAction(Player player, @NotNull String data) {
      String[] parts = data.split(" ");
      if (parts.length != 2) {
         this.plugin.getLogger().warning("Invalid [XP] format: " + data + " (Expected format: ACTION VALUE)");
      } else {
         String actionType = parts[0].toUpperCase();

         int xpAmount;
         try {
            xpAmount = Integer.parseInt(parts[1]);
         } catch (NumberFormatException var12) {
            this.plugin.getLogger().warning("Invalid XP value: " + parts[1]);
            return;
         }

         UUID puuid = player.getUniqueId();
         int xp = this.plugin.getSaveManager().getXp(puuid);
         byte var9 = -1;
         switch(actionType.hashCode()) {
         case -1881281404:
            if (actionType.equals("REMOVE")) {
               var9 = 1;
            }
            break;
         case 64641:
            if (actionType.equals("ADD")) {
               var9 = 0;
            }
            break;
         case 81986:
            if (actionType.equals("SET")) {
               var9 = 2;
            }
         }

         switch(var9) {
         case 0:
            int result = xp + xpAmount;
            this.plugin.getSaveManager().setXp(puuid, result);
            break;
         case 1:
            int result1 = xp - xpAmount;
            this.plugin.getSaveManager().setXp(puuid, result1);
            break;
         case 2:
            this.plugin.getSaveManager().setXp(puuid, xpAmount);
            break;
         default:
            this.plugin.getLogger().warning("Unknown [XP] action type: " + actionType);
         }

      }
   }

   private void handleLevelAction(Player player, @NotNull String data) {
      String[] parts = data.split(" ");
      if (parts.length != 2) {
         this.plugin.getLogger().warning("Invalid [LEVEL] format: " + data + " (Expected format: ACTION VALUE)");
      } else {
         String actionType = parts[0].toUpperCase();

         int levelAmount;
         try {
            levelAmount = Integer.parseInt(parts[1]);
         } catch (NumberFormatException var12) {
            this.plugin.getLogger().warning("Invalid Level value: " + parts[1]);
            return;
         }

         UUID puuid = player.getUniqueId();
         int level = this.plugin.getSaveManager().getLevel(puuid);
         byte var9 = -1;
         switch(actionType.hashCode()) {
         case -1881281404:
            if (actionType.equals("REMOVE")) {
               var9 = 1;
            }
            break;
         case 64641:
            if (actionType.equals("ADD")) {
               var9 = 0;
            }
            break;
         case 81986:
            if (actionType.equals("SET")) {
               var9 = 2;
            }
         }

         switch(var9) {
         case 0:
            int result = level + levelAmount;
            this.plugin.getSaveManager().setLevel(puuid, result);
            break;
         case 1:
            int result1 = level - levelAmount;
            this.plugin.getSaveManager().setLevel(puuid, result1);
            break;
         case 2:
            this.plugin.getSaveManager().setLevel(puuid, levelAmount);
            break;
         default:
            this.plugin.getLogger().warning("Unknown [XP] action type: " + actionType);
         }

      }
   }

   private void handleChatColorAction(Player player, @NotNull String data) {
      String[] parts = data.split("/", 2);
      if (parts.length < 2) {
         this.plugin.getLogger().warning("Invalid [CHATCOLOR] format: " + data);
      } else {
         String type = parts[0].trim();
         String colorOrFormat = parts[1].trim();
         String var6 = type.toUpperCase();
         byte var7 = -1;
         switch(var6.hashCode()) {
         case 64304963:
            if (var6.equals("COLOR")) {
               var7 = 0;
            }
            break;
         case 2079517687:
            if (var6.equals("FORMAT")) {
               var7 = 1;
            }
         }

         switch(var7) {
         case 0:
            this.plugin.getSaveManager().setChatColor(player.getUniqueId(), colorOrFormat);
            break;
         case 1:
            this.plugin.getSaveManager().setFormat(player.getUniqueId(), colorOrFormat);
            break;
         default:
            this.plugin.getLogger().warning("Unknown [CHATCOLOR] type: " + type);
         }

      }
   }

   private int getCooldown(String commandName) {
      return ((CommandsManager.Command)this.commandsManager.getCommands().get(commandName)).cooldown();
   }

   private void handleClickAction(Player player, @NotNull String data) {
      String[] parts = data.split("\\|", 2);
      if (parts.length < 2) {
         this.plugin.getLogger().warning("Invalid [CLICK_ACTION] format: " + data);
      } else {
         String actionType = parts[0].trim();
         String message = parts[1].trim();
         String translatedMessage = this.plugin.getTranslateColors().translateColors(player, message);
         TextComponent textComponent = new TextComponent(translatedMessage);
         String command;
         if (actionType.startsWith("OPEN")) {
            command = actionType.substring("OPEN".length()).trim();
            textComponent.setClickEvent(new ClickEvent(Action.OPEN_URL, command));
         } else if (actionType.startsWith("SUGGEST")) {
            command = actionType.substring("SUGGEST".length()).trim();
            textComponent.setClickEvent(new ClickEvent(Action.SUGGEST_COMMAND, command));
         } else {
            if (!actionType.startsWith("EXECUTE")) {
               this.plugin.getLogger().warning("Unknown [CLICK_ACTION] type: " + actionType);
               return;
            }

            command = actionType.substring("EXECUTE".length()).trim();
            textComponent.setClickEvent(new ClickEvent(Action.RUN_COMMAND, command));
         }

         player.spigot().sendMessage(textComponent);
      }
   }

   private boolean isOnCooldown(@NotNull Player player, String commandName, int cooldownSeconds) {
      long currentTime = System.currentTimeMillis() / 1000L;
      long lastExecution = (Long)this.commandCooldowns.getOrDefault(player.getUniqueId(), 0L);
      return currentTime < lastExecution + (long)cooldownSeconds;
   }

   private int getRemainingCooldown(@NotNull Player player, String commandName) {
      long currentTime = System.currentTimeMillis() / 1000L;
      long lastExecution = (Long)this.commandCooldowns.getOrDefault(player.getUniqueId(), 0L);
      return (int)(lastExecution + (long)this.getCooldown(commandName) - currentTime);
   }

   public void sendPlayerToBungeeServer(Player player, String serverName) {
      ByteArrayOutputStream b = new ByteArrayOutputStream();
      DataOutputStream out = new DataOutputStream(b);

      try {
         out.writeUTF("Connect");
         out.writeUTF(serverName);
      } catch (IOException var6) {
         var6.printStackTrace();
      }

      player.sendPluginMessage(this.plugin, "BungeeCord", b.toByteArray());
   }

   private void setCooldown(@NotNull Player player, String commandName, int cooldownSeconds) {
      long currentTime = System.currentTimeMillis() / 1000L;
      this.commandCooldowns.put(player.getUniqueId(), currentTime);
   }
}
