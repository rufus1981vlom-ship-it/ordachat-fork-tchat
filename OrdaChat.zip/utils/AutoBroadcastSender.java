package utils;

import config.AutoBroadcastManager;
import java.util.Iterator;
import minealex.tchat.OrdaChat;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.jetbrains.annotations.NotNull;

public class AutoBroadcastSender {
   private final OrdaChat plugin;
   private final AutoBroadcastManager autoBroadcastManager;
   private int currentBroadcastIndex;
   private BukkitTask broadcastTask;

   public AutoBroadcastSender(@NotNull OrdaChat plugin) {
      this.plugin = plugin;
      this.autoBroadcastManager = plugin.getAutoBroadcastManager();
      this.currentBroadcastIndex = 0;
      this.startBroadcastTask();
   }

   public void startBroadcastTask() {
      if (this.broadcastTask == null || this.broadcastTask.isCancelled()) {
         this.broadcastTask = (new BukkitRunnable() {
            public void run() {
               if (AutoBroadcastSender.this.autoBroadcastManager.isEnabled()) {
                  AutoBroadcastManager.Broadcast[] broadcasts = (AutoBroadcastManager.Broadcast[])AutoBroadcastSender.this.autoBroadcastManager.getBroadcasts().values().toArray(new AutoBroadcastManager.Broadcast[0]);
                  if (broadcasts.length == 0) {
                     AutoBroadcastSender.this.plugin.getLogger().info("No broadcasts available.");
                     return;
                  }

                  AutoBroadcastManager.Broadcast currentBroadcast = broadcasts[AutoBroadcastSender.this.currentBroadcastIndex];
                  if (currentBroadcast.enabled()) {
                     String channelName = currentBroadcast.channel();
                     if (currentBroadcast.channel().equalsIgnoreCase("none")) {
                        AutoBroadcastSender.this.sendMessageToPlayers(Bukkit.getOnlinePlayers(), currentBroadcast);
                     } else {
                        int messageMode = AutoBroadcastSender.this.plugin.getChannelsConfigManager().getChannel(channelName).messageMode();
                        Iterator var5;
                        Player player;
                        label37:
                        switch(messageMode) {
                        case 0:
                           AutoBroadcastSender.this.sendMessageToPlayers(Bukkit.getOnlinePlayers(), currentBroadcast);
                           break;
                        case 1:
                           var5 = Bukkit.getOnlinePlayers().iterator();

                           while(true) {
                              if (!var5.hasNext()) {
                                 break label37;
                              }

                              player = (Player)var5.next();
                              String permission = AutoBroadcastSender.this.plugin.getChannelsConfigManager().getChannel(channelName).permission();
                              if (player.hasPermission(permission)) {
                                 AutoBroadcastSender.this.sendMessageToPlayer(player, currentBroadcast);
                              }
                           }
                        case 2:
                           var5 = AutoBroadcastSender.this.plugin.getChannelsManager().getPlayersInChannel(channelName).iterator();

                           while(var5.hasNext()) {
                              player = (Player)var5.next();
                              AutoBroadcastSender.this.sendMessageToPlayer(player, currentBroadcast);
                           }
                        case 3:
                           break;
                        default:
                           AutoBroadcastSender.this.plugin.getLogger().warning("Unknown Message Mode: " + messageMode);
                        }
                     }
                  }

                  AutoBroadcastSender.this.currentBroadcastIndex = (AutoBroadcastSender.this.currentBroadcastIndex + 1) % broadcasts.length;
               }

            }
         }).runTaskTimer(this.plugin, 0L, (long)this.autoBroadcastManager.getTime() * 20L);
      }
   }

   public void stopBroadcastTask() {
      if (this.broadcastTask != null && !this.broadcastTask.isCancelled()) {
         this.broadcastTask.cancel();
      }

   }

   public void restartBroadcasts() {
      this.stopBroadcastTask();
      this.currentBroadcastIndex = 0;
      this.startBroadcastTask();
   }

   private void sendMessageToPlayers(@NotNull Iterable<? extends Player> players, AutoBroadcastManager.Broadcast broadcast) {
      Iterator var3 = players.iterator();

      while(var3.hasNext()) {
         Player player = (Player)var3.next();
         this.sendMessageToPlayer(player, broadcast);
      }

   }

   private void sendMessageToPlayer(Player player, @NotNull AutoBroadcastManager.Broadcast broadcast) {
      if (!this.plugin.getAutoBroadcastManager().isPlayerToggled(player)) {
         String broadcastPermission = broadcast.permission();
         if (broadcastPermission == null || broadcastPermission.equalsIgnoreCase("none") || broadcastPermission.isEmpty() || player.hasPermission(broadcastPermission)) {
            String translatedMessage;
            for(Iterator var4 = broadcast.message().iterator(); var4.hasNext(); player.sendMessage(translatedMessage)) {
               String line = (String)var4.next();
               translatedMessage = this.plugin.getTranslateColors().translateColors(player, line);
               if (translatedMessage.contains("%center%")) {
                  translatedMessage = translatedMessage.replace("%center%", "");
                  translatedMessage = this.centerText(translatedMessage);
               }
            }

            if (broadcast.titleEnabled()) {
               player.sendTitle(this.plugin.getTranslateColors().translateColors(player, broadcast.title()), this.plugin.getTranslateColors().translateColors(player, broadcast.subtitle()), 10, 70, 20);
            }

            if (broadcast.actionbarEnabled()) {
               player.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText(this.plugin.getTranslateColors().translateColors(player, broadcast.actionbar())));
            }

            if (broadcast.soundEnabled()) {
               try {
                  Sound sound = Sound.valueOf(broadcast.sound().toUpperCase());
                  player.playSound(player.getLocation(), sound, 1.0F, 1.0F);
               } catch (IllegalArgumentException var8) {
                  this.plugin.getLogger().warning("Invalid sound type: " + broadcast.sound());
               }
            }

            if (broadcast.particlesEnabled()) {
               try {
                  Particle particle = Particle.valueOf(broadcast.particle().toUpperCase());
                  player.getWorld().spawnParticle(particle, player.getLocation(), broadcast.particleCount());
               } catch (IllegalArgumentException var7) {
                  this.plugin.getLogger().warning("Invalid particle type: " + broadcast.particle());
               }
            }

         }
      }
   }

   private String centerText(String message) {
      int maxLength = true;
      String strippedMessage = ChatColor.stripColor(message);
      int length = strippedMessage.length();
      if (length >= 56) {
         return message;
      } else {
         int spaces = (56 - length) / 2;
         StringBuilder centeredMessage = new StringBuilder();
         centeredMessage.append(" ".repeat(spaces));
         centeredMessage.append(message);

         while(centeredMessage.length() < 56) {
            centeredMessage.append(" ");
         }

         return centeredMessage.toString();
      }
   }
}
