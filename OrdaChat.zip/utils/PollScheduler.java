package utils;

import minealex.tchat.OrdaChat;
import org.bukkit.scheduler.BukkitRunnable;

public class PollScheduler {
   public static void startPollChecker(OrdaChat plugin) {
      (new BukkitRunnable() {
         public void run() {
            Poll currentPoll = Poll.getCurrentPoll();
            if (currentPoll != null && currentPoll.hasEnded()) {
               currentPoll.finalizePoll();
            }

         }
      }).runTaskTimer(plugin, 20L, 20L);
   }
}
