package listeners;

import config.WorldsManager;
import minealex.tchat.OrdaChat;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.jetbrains.annotations.NotNull;

public class ChatEnabledListener implements Listener {
   private final OrdaChat plugin;
   private final WorldsManager worldsManager;

   public ChatEnabledListener(@NotNull OrdaChat plugin) {
      this.plugin = plugin;
      this.worldsManager = plugin.getWorldsManager();
   }

   @EventHandler
   public void checkChatEnabled(@NotNull AsyncPlayerChatEvent event) {
      if (!event.isCancelled()) {
         Player player = event.getPlayer();
         String worldName = player.getWorld().getName();
         WorldsManager.WorldConfigData configData = (WorldsManager.WorldConfigData)this.worldsManager.getWorldsConfig().get(worldName);
         if (configData != null) {
            boolean chatEnabled = configData.chatEnabled();
            if (!chatEnabled && !player.hasPermission("tchat.admin") && !player.hasPermission("tchat.bypass.chat-enabled")) {
               event.setCancelled(true);
               String prefix = this.plugin.getMessagesManager().getPrefix();
               String message = this.plugin.getMessagesManager().getChatDisabledWorld();
               player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
            }
         }

      }
   }
}
