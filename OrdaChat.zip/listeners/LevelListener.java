package listeners;

import config.LevelsManager;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import minealex.tchat.OrdaChat;
import org.bukkit.Bukkit;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.scheduler.BukkitRunnable;
import org.jetbrains.annotations.NotNull;

public class LevelListener implements Listener {
   private final Random random = new Random();
   private final OrdaChat plugin;

   public LevelListener(@NotNull OrdaChat plugin) {
      this.plugin = plugin;
      plugin.getServer().getPluginManager().registerEvents(this, plugin);
   }

   @EventHandler
   public void addXp(@NotNull AsyncPlayerChatEvent event) {
      if (!event.isCancelled() && this.plugin.getLevelsManager().isEnabled()) {
         Player player = event.getPlayer();
         UUID playerId = player.getUniqueId();
         LevelsManager levelsManager = this.plugin.getLevelsManager();
         LevelsManager.Multiplier multiplier = levelsManager.getMultiplier(player);
         double xpMultiplier = multiplier.getXpMultiplier();
         int minXp = levelsManager.getMinXp();
         int maxXp = levelsManager.getMaxXp();
         int randomNumber = minXp + this.random.nextInt(maxXp - minXp + 1);
         int adjustedXp = (int)((double)randomNumber * xpMultiplier);
         Bukkit.getScheduler().runTask(this.plugin, () -> {
            int currentXp = this.plugin.getSaveManager().getXp(playerId);
            int totalXp = currentXp + adjustedXp;
            this.handleLevelUp(player, totalXp);
         });
      }
   }

   private void handleLevelUp(@NotNull Player player, int totalXp) {
      UUID playerId = player.getUniqueId();
      LevelsManager levelsManager = this.plugin.getLevelsManager();
      int currentLevel = this.plugin.getSaveManager().getLevel(playerId);

      for(int levelId = currentLevel + 1; levelsManager.getLevels().containsKey(levelId); ++levelId) {
         LevelsManager.Level level = levelsManager.getLevel(levelId);
         int requiredXp = level.getXp();
         if (totalXp < requiredXp) {
            break;
         }

         this.plugin.getSaveManager().setLevel(playerId, levelId);
         totalXp -= requiredXp;
         this.applyRewards(player, level.getRewards());
         String prefix = this.plugin.getMessagesManager().getPrefix();
         String message = this.plugin.getMessagesManager().getLevelUp();
         message = message.replace("%level%", String.valueOf(levelId));
         player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
      }

      this.plugin.getSaveManager().setXp(playerId, totalXp);
   }

   private void applyRewards(final Player player, final List<String> rewards) {
      final ConsoleCommandSender console = Bukkit.getServer().getConsoleSender();
      (new BukkitRunnable() {
         public void run() {
            Iterator var1 = rewards.iterator();

            while(var1.hasNext()) {
               String reward = (String)var1.next();
               String command = reward.replace("%player%", player.getName());
               Bukkit.dispatchCommand(console, command);
            }

         }
      }).runTask(this.plugin);
   }
}
