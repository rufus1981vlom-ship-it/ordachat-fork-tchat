package listeners;

import config.JoinManager;
import java.util.Iterator;
import minealex.tchat.OrdaChat;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.jetbrains.annotations.NotNull;

public class PlayerLeftListener implements Listener {
   private final OrdaChat plugin;
   private final JoinManager joinManager;

   public PlayerLeftListener(@NotNull OrdaChat plugin) {
      this.plugin = plugin;
      this.joinManager = plugin.getJoinManager();
   }

   @EventHandler
   public void onPlayerLeft(@NotNull PlayerQuitEvent event) {
      Player player = event.getPlayer();
      String username = player.getName();
      this.plugin.getDiscordHook().sendLeftMessage(username);
      this.playerQuitActions(player, event);
   }

   public void playerQuitActions(Player player, PlayerQuitEvent event) {
      String groupName = this.plugin.getGroupManager().getGroup(player);
      JoinManager.GroupConfig groupConfig = (JoinManager.GroupConfig)this.joinManager.getAllGroupConfigs().get(groupName);
      if (groupConfig != null) {
         JoinManager.EventConfig quitConfig = groupConfig.getQuitConfig();
         String subtitle;
         if (quitConfig.isMessageEnabled()) {
            Iterator var6 = quitConfig.getMessage().iterator();

            while(var6.hasNext()) {
               subtitle = (String)var6.next();
               String formattedMessage = this.plugin.getTranslateColors().translateColors(player, subtitle);
               Bukkit.broadcastMessage(formattedMessage);
            }
         }

         String actionBarMessage;
         if (quitConfig.isTitleEnabled()) {
            actionBarMessage = this.plugin.getTranslateColors().translateColors(player, quitConfig.getTitle());
            subtitle = this.plugin.getTranslateColors().translateColors(player, quitConfig.getSubtitle());
            Iterator var13 = Bukkit.getOnlinePlayers().iterator();

            while(var13.hasNext()) {
               Player onlinePlayer = (Player)var13.next();
               onlinePlayer.sendTitle(actionBarMessage, subtitle, 10, 70, 20);
            }
         }

         Iterator var12;
         Player onlinePlayer;
         if (quitConfig.isSoundEnabled()) {
            actionBarMessage = quitConfig.getSound();
            var12 = Bukkit.getOnlinePlayers().iterator();

            while(var12.hasNext()) {
               onlinePlayer = (Player)var12.next();
               onlinePlayer.playSound(onlinePlayer.getLocation(), actionBarMessage, quitConfig.getVolume(), quitConfig.getPitch());
            }
         }

         if (quitConfig.isParticlesEnabled()) {
            Particle particleType = Particle.valueOf(quitConfig.getParticle());
            player.getWorld().spawnParticle(particleType, player.getLocation(), 30);
         }

         if (quitConfig.isActionbarEnabled()) {
            actionBarMessage = this.plugin.getTranslateColors().translateColors(player, quitConfig.getActionbarMessage()).replace("{player}", player.getName());
            var12 = Bukkit.getOnlinePlayers().iterator();

            while(var12.hasNext()) {
               onlinePlayer = (Player)var12.next();
               onlinePlayer.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText(actionBarMessage));
            }
         }

         if (quitConfig.isCancelLeftMessage()) {
            event.setQuitMessage((String)null);
         }
      }

   }
}
