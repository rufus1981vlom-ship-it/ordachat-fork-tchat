package listeners;

import java.util.HashMap;
import java.util.Map;
import minealex.tchat.OrdaChat;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.jetbrains.annotations.NotNull;

public class RepeatMessagesListener implements Listener {
   private final Map<Player, String> lastMessages = new HashMap();
   private final Map<Player, Integer> messageCount = new HashMap();
   private final OrdaChat plugin;

   public RepeatMessagesListener(OrdaChat plugin) {
      this.plugin = plugin;
   }

   @EventHandler
   public void checkRepeatMessages(@NotNull AsyncPlayerChatEvent event, Player player, String newMessage) {
      if (this.lastMessages.containsKey(player)) {
         String lastMessage = (String)this.lastMessages.get(player);
         if (this.isSimilar(lastMessage, newMessage)) {
            int count = (Integer)this.messageCount.getOrDefault(player, 0) + 1;
            int limit = this.plugin.getConfigManager().getMaxRepeatMessages();
            if (count >= limit) {
               event.setCancelled(true);
               String message = this.plugin.getMessagesManager().getRepeatMessage();
               String prefix = this.plugin.getMessagesManager().getPrefix();
               player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
               return;
            }

            this.messageCount.put(player, count);
         } else {
            this.messageCount.put(player, 1);
         }
      }

      this.lastMessages.put(player, newMessage);
   }

   private boolean isSimilar(String message1, String message2) {
      message1 = message1.toLowerCase();
      message2 = message2.toLowerCase();
      int maxLength = Math.max(message1.length(), message2.length());
      int similarChars = 0;

      for(int i = 0; i < Math.min(message1.length(), message2.length()); ++i) {
         if (message1.charAt(i) == message2.charAt(i)) {
            ++similarChars;
         }
      }

      double similarity = (double)similarChars / (double)maxLength;
      return similarity >= this.plugin.getConfigManager().getRepeatMessagesPercent();
   }
}
