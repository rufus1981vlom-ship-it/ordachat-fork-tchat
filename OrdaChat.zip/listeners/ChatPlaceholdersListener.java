package listeners;

import commands.ShowItemCommand;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import minealex.tchat.OrdaChat;
import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.ComponentBuilder;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.chat.HoverEvent.Action;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.NotNull;

public class ChatPlaceholdersListener implements Listener {
   private final OrdaChat plugin;
   private final ShowItemCommand showItemCommand;

   public ChatPlaceholdersListener(OrdaChat plugin, ShowItemCommand showItemCommand) {
      this.plugin = plugin;
      this.showItemCommand = showItemCommand;
   }

   @EventHandler
   public void onPlayerChat(@NotNull AsyncPlayerChatEvent event) {
      Player player = event.getPlayer();
      String message = event.getMessage();
      String prefix = this.plugin.getMessagesManager().getPrefix();
      String initialMessage;
      String p;
      String s;
      String itemName;
      if (this.plugin.getPlaceholdersConfig().isCoordsEnabled() && message.contains(this.plugin.getPlaceholdersConfig().getCoordsName())) {
         if (!player.hasPermission("tchat.admin") && !player.hasPermission("tchat.placeholder.coords")) {
            itemName = this.plugin.getMessagesManager().getNoPermission();
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + itemName));
         } else {
            double x = player.getLocation().getX();
            double y = player.getLocation().getY();
            double z = player.getLocation().getZ();
            initialMessage = String.format("%.2f", x);
            p = String.format("%.2f", y);
            s = String.format("%.2f", z);
            String coordsMessage = this.plugin.getTranslateColors().translateColors(player, this.plugin.getPlaceholdersConfig().getCoordsFormat());
            coordsMessage = coordsMessage.replace("%x%", initialMessage);
            coordsMessage = coordsMessage.replace("%y%", p);
            coordsMessage = coordsMessage.replace("%z%", s);
            message = message.replace(this.plugin.getPlaceholdersConfig().getCoordsName(), coordsMessage);
         }
      }

      itemName = this.plugin.getPlaceholdersConfig().getItemName();
      String error;
      String afterInventory;
      String enderchestName;
      String inventoryName;
      if (this.plugin.getPlaceholdersConfig().isItemEnabled() && message.contains(itemName)) {
         if (!player.hasPermission("tchat.admin") && !player.hasPermission("tchat.placeholder.item")) {
            enderchestName = this.plugin.getMessagesManager().getNoPermission();
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + enderchestName));
         } else {
            String[] parts = message.split(Pattern.quote(itemName), 2);
            if (parts.length == 2) {
               inventoryName = parts[0];
               error = parts[1];
               ItemStack itemInHand = player.getInventory().getItemInMainHand();
               afterInventory = "None";
               initialMessage = "{}";
               if (itemInHand.getType() != Material.AIR) {
                  ItemMeta itemMeta = itemInHand.getItemMeta();
                  if (itemMeta != null) {
                     afterInventory = itemMeta.hasDisplayName() ? itemMeta.getDisplayName() : itemInHand.getType().toString().replace('_', ' ').toLowerCase();
                     initialMessage = String.format("{\"id\":\"%s\",\"Count\":%d,\"tag\":%s,\"Damage\":%d}", itemInHand.getType().getKey().getKey(), itemInHand.getAmount(), this.showItemCommand.getItemTagJson(itemMeta), itemMeta instanceof Damageable ? ((Damageable)itemMeta).getDamage() : 0);
                  }
               }

               p = this.plugin.getPlaceholdersConfig().getItemPrefix();
               s = this.plugin.getPlaceholdersConfig().getItemSuffix();
               p = p.replace("%before_item%", inventoryName);
               s = s.replace("%after_item%", error);
               TextComponent beforeComponent = new TextComponent(this.plugin.getTranslateColors().translateColors(player, p));
               TextComponent afterComponent = new TextComponent(this.plugin.getTranslateColors().translateColors(player, s));
               TextComponent itemComponent = new TextComponent(afterInventory);
               itemComponent.setHoverEvent(new HoverEvent(Action.SHOW_ITEM, (new ComponentBuilder(initialMessage)).create()));
               event.getRecipients().clear();
               Iterator var17 = this.plugin.getServer().getOnlinePlayers().iterator();

               while(var17.hasNext()) {
                  Player onlinePlayer = (Player)var17.next();
                  onlinePlayer.spigot().sendMessage(new BaseComponent[]{beforeComponent, itemComponent, afterComponent});
               }
            }
         }
      }

      if (this.plugin.getPlaceholdersConfig().isWorldEnabled() && message.contains(this.plugin.getPlaceholdersConfig().getWorldName())) {
         if (!player.hasPermission("tchat.admin") && !player.hasPermission("tchat.placeholder.world")) {
            enderchestName = this.plugin.getMessagesManager().getNoPermission();
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + enderchestName));
         } else {
            enderchestName = ((World)Objects.requireNonNull(player.getLocation().getWorld())).getName();
            inventoryName = this.plugin.getTranslateColors().translateColors(player, this.plugin.getPlaceholdersConfig().getWorldFormat());
            inventoryName = inventoryName.replace("%world%", enderchestName);
            message = message.replace(this.plugin.getPlaceholdersConfig().getWorldName(), inventoryName);
         }
      }

      String beforeInventory;
      TextComponent inventoryComponent;
      Iterator var32;
      Player onlinePlayer;
      if (this.plugin.getPlaceholdersConfig().isCommandEnabled()) {
         Pattern commandPattern = Pattern.compile(this.plugin.getPlaceholdersConfig().getCommandName());
         Matcher commandMatcher = commandPattern.matcher(message);
         if (commandMatcher.find()) {
            error = commandMatcher.group(1);
            beforeInventory = message.substring(0, commandMatcher.start());
            afterInventory = message.substring(commandMatcher.end());
            initialMessage = this.plugin.getPlaceholdersConfig().getCommandFormat();
            initialMessage = initialMessage.replace("%command%", error).replace("%before_command%", beforeInventory).replace("%after_command%", afterInventory);
            initialMessage = this.plugin.getTranslateColors().translateColors(player, initialMessage);
            inventoryComponent = this.getHoverCommand(initialMessage, player, error);
            event.getRecipients().clear();
            event.setFormat(inventoryComponent.toLegacyText());
            var32 = this.plugin.getServer().getOnlinePlayers().iterator();

            while(var32.hasNext()) {
               onlinePlayer = (Player)var32.next();
               onlinePlayer.spigot().sendMessage(inventoryComponent);
            }
         } else {
            event.setMessage(message);
         }
      }

      enderchestName = this.plugin.getPlaceholdersConfig().getEnderName();
      if (this.plugin.getPlaceholdersConfig().isEnderEnabled() && message.contains(enderchestName)) {
         if (!player.hasPermission("tchat.admin") && !player.hasPermission("tchat.placeholder.enderchest")) {
            inventoryName = this.plugin.getMessagesManager().getNoPermission();
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + inventoryName));
         } else {
            String[] parts = message.split(Pattern.quote(enderchestName), 2);
            if (parts.length == 2) {
               error = parts[0];
               beforeInventory = parts[1];
               afterInventory = this.plugin.getPlaceholdersConfig().getEnderFormat();
               afterInventory = afterInventory.replace("%before_ender%", error).replace("%after_ender%", beforeInventory);
               afterInventory = this.plugin.getTranslateColors().translateColors(player, afterInventory);
               TextComponent enderComponent = this.getEnderTextComponent(afterInventory, player);
               event.getRecipients().clear();
               event.setFormat(enderComponent.toLegacyText());
               Iterator var31 = this.plugin.getServer().getOnlinePlayers().iterator();

               while(var31.hasNext()) {
                  Player onlinePlayer = (Player)var31.next();
                  onlinePlayer.spigot().sendMessage(enderComponent);
               }
            }
         }
      } else {
         event.setMessage(message);
      }

      inventoryName = this.plugin.getPlaceholdersConfig().getInventoryName();
      if (this.plugin.getPlaceholdersConfig().isInventoryEnabled() && message.contains(inventoryName)) {
         if (!player.hasPermission("tchat.admin") && !player.hasPermission("tchat.placeholder.inventory")) {
            error = this.plugin.getMessagesManager().getNoPermission();
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + error));
         } else {
            String[] parts = message.split(Pattern.quote(inventoryName), 2);
            if (parts.length == 2) {
               beforeInventory = parts[0];
               afterInventory = parts[1];
               initialMessage = this.plugin.getPlaceholdersConfig().getInventoryFormat();
               initialMessage = initialMessage.replace("%before_inv%", beforeInventory).replace("%after_inv%", afterInventory);
               initialMessage = this.plugin.getTranslateColors().translateColors(player, initialMessage);
               inventoryComponent = this.getTextComponent(initialMessage, player);
               event.getRecipients().clear();
               event.setFormat(inventoryComponent.toLegacyText());
               var32 = this.plugin.getServer().getOnlinePlayers().iterator();

               while(var32.hasNext()) {
                  onlinePlayer = (Player)var32.next();
                  onlinePlayer.spigot().sendMessage(inventoryComponent);
               }
            }
         }
      } else {
         event.setMessage(message);
      }

      event.setMessage(message);
   }

   @NotNull
   private TextComponent getHoverCommand(String commandFormat, Player player, String command) {
      TextComponent commandComponent = new TextComponent(commandFormat);
      if (this.plugin.getPlaceholdersConfig().isHoverCommandEnabled()) {
         ComponentBuilder hoverBuilder = this.getComponentBuilderCommand(player, command);
         TextComponent hoverComponent = new TextComponent(hoverBuilder.create());
         commandComponent.setHoverEvent(new HoverEvent(Action.SHOW_TEXT, new BaseComponent[]{hoverComponent}));
      }

      commandComponent.setClickEvent(new ClickEvent(net.md_5.bungee.api.chat.ClickEvent.Action.RUN_COMMAND, "/" + command));
      return commandComponent;
   }

   @NotNull
   private ComponentBuilder getComponentBuilderCommand(Player player, String command) {
      List<String> hoverTextList = this.plugin.getPlaceholdersConfig().getHoverCommand();
      hoverTextList.replaceAll((s) -> {
         return this.plugin.getTranslateColors().translateColors(player, s.replace("%command%", command));
      });
      ComponentBuilder hoverBuilder = new ComponentBuilder();

      for(int i = 0; i < hoverTextList.size(); ++i) {
         String line = (String)hoverTextList.get(i);
         hoverBuilder.append(line);
         if (i < hoverTextList.size() - 1) {
            hoverBuilder.append("\n");
         }
      }

      return hoverBuilder;
   }

   @NotNull
   private TextComponent getTextComponent(String initialMessage, @NotNull Player player) {
      TextComponent inventoryComponent = new TextComponent(initialMessage);
      if (this.plugin.getPlaceholdersConfig().isHoverInventoryTextEnabled()) {
         List<String> hoverTextList = this.plugin.getPlaceholdersConfig().getHoverInventoryText();
         if (hoverTextList != null) {
            ComponentBuilder hoverBuilder = new ComponentBuilder();

            for(int i = 0; i < hoverTextList.size(); ++i) {
               String line = (String)hoverTextList.get(i);
               String translatedLine = this.plugin.getTranslateColors().translateColors(player, line);
               hoverBuilder.append(translatedLine);
               if (i < hoverTextList.size() - 1) {
                  hoverBuilder.append("\n");
               }
            }

            TextComponent hoverComponent = new TextComponent(hoverBuilder.create());
            HoverEvent hoverEvent = new HoverEvent(Action.SHOW_TEXT, new BaseComponent[]{hoverComponent});
            inventoryComponent.setHoverEvent(hoverEvent);
         }
      }

      if (this.plugin.getPlaceholdersConfig().isHoverInventoryActionEnabled()) {
         String action = this.plugin.getPlaceholdersConfig().getHoverInventoryAction();
         if (action != null) {
            action = action.replace("%player%", player.getName());
            inventoryComponent.setClickEvent(new ClickEvent(net.md_5.bungee.api.chat.ClickEvent.Action.RUN_COMMAND, action));
         }
      }

      return inventoryComponent;
   }

   @NotNull
   private TextComponent getEnderTextComponent(String initialMessage, @NotNull Player player) {
      TextComponent inventoryComponent = new TextComponent(initialMessage);
      if (this.plugin.getPlaceholdersConfig().isHoverEnderTextEnabled()) {
         List<String> hoverTextList = this.plugin.getPlaceholdersConfig().getHoverEnderText();
         if (hoverTextList != null) {
            ComponentBuilder hoverBuilder = new ComponentBuilder();

            for(int i = 0; i < hoverTextList.size(); ++i) {
               String line = (String)hoverTextList.get(i);
               String translatedLine = this.plugin.getTranslateColors().translateColors(player, line);
               hoverBuilder.append(translatedLine);
               if (i < hoverTextList.size() - 1) {
                  hoverBuilder.append("\n");
               }
            }

            TextComponent hoverComponent = new TextComponent(hoverBuilder.create());
            HoverEvent hoverEvent = new HoverEvent(Action.SHOW_TEXT, new BaseComponent[]{hoverComponent});
            inventoryComponent.setHoverEvent(hoverEvent);
         }
      }

      if (this.plugin.getPlaceholdersConfig().isHoverEnderActionEnabled()) {
         String action = this.plugin.getPlaceholdersConfig().getHoverEnderAction();
         if (action != null) {
            action = action.replace("%player%", player.getName());
            inventoryComponent.setClickEvent(new ClickEvent(net.md_5.bungee.api.chat.ClickEvent.Action.RUN_COMMAND, action));
         }
      }

      return inventoryComponent;
   }
}
