package listeners;

import minealex.tchat.OrdaChat;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.jetbrains.annotations.NotNull;

public class CapListener implements Listener {
   private final OrdaChat plugin;

   public CapListener(OrdaChat plugin) {
      this.plugin = plugin;
   }

   @EventHandler
   public void playerAntiCap(@NotNull AsyncPlayerChatEvent event) {
      if (!event.isCancelled()) {
         boolean isAntiCapEnabled = this.plugin.getConfigManager().isAntiCapEnabled();
         if (isAntiCapEnabled) {
            Player player = event.getPlayer();
            boolean hasBypassPermission = player.hasPermission("tchat.bypass.anticap");
            boolean hasAdminPermission = player.hasPermission("tchat.admin");
            if (!hasBypassPermission && !hasAdminPermission) {
               String message = event.getMessage();
               int totalChars = 0;
               int uppercaseChars = 0;
               char[] var9 = message.toCharArray();
               int var10 = var9.length;

               for(int var11 = 0; var11 < var10; ++var11) {
                  char c = var9[var11];
                  if (Character.isLetter(c)) {
                     ++totalChars;
                     if (Character.isUpperCase(c)) {
                        ++uppercaseChars;
                     }
                  }
               }

               double percentUppercase = totalChars > 0 ? (double)uppercaseChars / (double)totalChars : 0.0D;
               double antiCapPercent = this.plugin.getConfigManager().getAntiCapPercent();
               if (percentUppercase > antiCapPercent) {
                  String antiCapMode = this.plugin.getConfigManager().getAntiCapMode();
                  byte var15 = -1;
                  switch(antiCapMode.hashCode()) {
                  case 63294573:
                     if (antiCapMode.equals("BLOCK")) {
                        var15 = 1;
                     }
                     break;
                  case 530285942:
                     if (antiCapMode.equals("ToLowerCase")) {
                        var15 = 0;
                     }
                     break;
                  case 1984282058:
                     if (antiCapMode.equals("CENSOR")) {
                        var15 = 2;
                     }
                  }

                  switch(var15) {
                  case 0:
                     event.setMessage(message.toLowerCase());
                     break;
                  case 1:
                     event.setCancelled(true);
                     if (this.plugin.getConfigManager().isAntiCapMessageEnabled()) {
                        String error = this.plugin.getMessagesManager().getAntiCapMessage();
                        String prefix = this.plugin.getMessagesManager().getPrefix();
                        event.getPlayer().sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + error));
                     }
                     break;
                  case 2:
                     StringBuilder newMessage = new StringBuilder();
                     char[] var17 = message.toCharArray();
                     int var18 = var17.length;

                     for(int var19 = 0; var19 < var18; ++var19) {
                        char c = var17[var19];
                        if (Character.isUpperCase(c)) {
                           newMessage.append('*');
                        } else {
                           newMessage.append(c);
                        }
                     }

                     event.setMessage(newMessage.toString());
                     break;
                  default:
                     this.plugin.getLogger().warning("Unknown anti-cap mode: " + antiCapMode);
                  }
               }
            }
         }

      }
   }
}
