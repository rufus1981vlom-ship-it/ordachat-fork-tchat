package listeners;

import java.util.HashMap;
import java.util.Map;
import minealex.tchat.OrdaChat;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.jetbrains.annotations.NotNull;

public class RepeatCommandsListener implements Listener {
   private final OrdaChat plugin;
   private final Map<Player, String> lastCommandMap = new HashMap();

   public RepeatCommandsListener(OrdaChat plugin) {
      this.plugin = plugin;
   }

   @EventHandler
   public void checkRepeatCommand(@NotNull PlayerCommandPreprocessEvent event) {
      if (!event.isCancelled()) {
         Player player = event.getPlayer();
         String command = event.getMessage();
         if (this.lastCommandMap.containsKey(player) && ((String)this.lastCommandMap.get(player)).equals(command)) {
            event.setCancelled(true);
            String p = this.plugin.getMessagesManager().getPrefix();
            String m = this.plugin.getMessagesManager().getRepeatCommands();
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, p + m));
         } else {
            this.lastCommandMap.put(player, command);
         }
      }
   }
}
