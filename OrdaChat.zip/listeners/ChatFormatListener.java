package listeners;

import config.ChannelsConfigManager;
import config.ConfigManager;
import config.GroupManager;
import config.MentionsManager;
import config.WorldsManager;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import me.clip.placeholderapi.PlaceholderAPI;
import minealex.tchat.OrdaChat;
import net.md_5.bungee.api.ChatColor;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.ComponentBuilder;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.chat.HoverEvent.Action;
import org.bukkit.Bukkit;
import org.bukkit.Particle;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import utils.TranslateHexColorCodes;

public class ChatFormatListener implements Listener {
   private final Map<String, Map<UUID, Long>> channelCooldowns = new HashMap();
   private final ConfigManager configManager;
   private final GroupManager groupManager;
   private final OrdaChat plugin;
   private final ChannelsConfigManager channelsConfigManager;
   private final MentionsManager mentionsManager;

   public ChatFormatListener(@NotNull OrdaChat plugin, ConfigManager configManager, GroupManager groupManager) {
      this.plugin = plugin;
      this.configManager = configManager;
      this.groupManager = groupManager;
      this.channelsConfigManager = plugin.getChannelsConfigManager();
      this.mentionsManager = plugin.getMentionsManager();
   }

   @EventHandler
   public void playerFormat(@NotNull AsyncPlayerChatEvent event) {
      if (!event.isCancelled()) {
         Player player = event.getPlayer();
         String message = event.getMessage();
         String worldName = player.getWorld().getName();
         WorldsManager.WorldConfigData worldConfigData = (WorldsManager.WorldConfigData)this.plugin.getWorldsManager().getWorldsConfig().get(worldName);
         boolean perWorldChat = worldConfigData != null && worldConfigData.pwc();
         boolean chatRadiusEnabled = worldConfigData != null && worldConfigData.chatrEnabled();
         if (perWorldChat) {
            Set<Player> recipients = (Set)event.getRecipients().stream().filter((recipient) -> {
               return recipient.hasPermission("tchat.admin") || recipient.hasPermission("tchat.bypass.pwc") || recipient.getWorld().getName().equals(worldName);
            }).collect(Collectors.toSet());
            event.getRecipients().clear();
            event.getRecipients().addAll(recipients);
         } else if (this.plugin.getWorldsManager().getBridgesConfig().values().stream().anyMatch((bridgex) -> {
            return bridgex.enabled() && bridgex.worlds().contains(worldName);
         })) {
            Set<String> worldsToInclude = new HashSet();
            worldsToInclude.add(worldName);
            Iterator var10 = this.plugin.getWorldsManager().getBridgesConfig().values().iterator();

            while(var10.hasNext()) {
               WorldsManager.BridgeConfigData bridge = (WorldsManager.BridgeConfigData)var10.next();
               if (bridge.enabled() && bridge.worlds().contains(worldName)) {
                  worldsToInclude.addAll(bridge.worlds());
               }
            }

            Set<Player> recipients = (Set)Bukkit.getOnlinePlayers().stream().filter((recipient) -> {
               return recipient.hasPermission("tchat.admin") || recipient.hasPermission("tchat.bypass.bridge") || worldsToInclude.contains(recipient.getWorld().getName());
            }).collect(Collectors.toSet());
            event.getRecipients().clear();
            event.getRecipients().addAll(recipients);
         }

         assert worldConfigData != null;

         String chatrPrefix = worldConfigData.bpNone();
         if (chatRadiusEnabled) {
            int chatRadius = worldConfigData.chatr();
            String cRadius = worldConfigData.bcchatr();
            Set<Player> recipients = (Set)event.getRecipients().stream().filter((recipient) -> {
               return recipient.hasPermission("tchat.admin") || recipient.hasPermission("tchat.bypass.chat-radius") || event.getMessage().startsWith(cRadius) && recipient.hasPermission("tchat.bypass.chat-radius.character") || recipient.getWorld().getName().equals(worldName) && recipient.getLocation().distance(player.getLocation()) <= (double)chatRadius;
            }).collect(Collectors.toSet());
            event.getRecipients().clear();
            event.getRecipients().addAll(recipients);
            String globalPrefix = worldConfigData.bcchatr();
            boolean chatr = message.startsWith(globalPrefix);

            if (chatr) {
               chatrPrefix = worldConfigData.bpGlobal();
               message = message.substring(globalPrefix.length()).trim();

               if (message.isEmpty()) {
                  event.setCancelled(true);
                  return;
               }
            } else {
               chatrPrefix = worldConfigData.bpLocal();
            }
         }

         String channelName;
         if (this.plugin.getConfigManager().isChatColorEnabled()) {
            channelName = this.plugin.getSaveManager().getChatColor(player.getUniqueId()) + this.plugin.getSaveManager().getFormat(player.getUniqueId());
            if (!channelName.equalsIgnoreCase("")) {
               message = channelName + message;
               message = this.plugin.getTranslateColors().translateColors(player, message);
            }
         }

         if (this.plugin.getConfigManager().isColorsChatEnabled()) {
            if (!player.hasPermission("tchat.admin") && !player.hasPermission("tchat.color.all")) {
               if (message.length() >= 2 && message.charAt(0) == '&') {
                  char colorCode = message.charAt(1);
                  if ("0123456789AaBbCcDdEeFfKkLlMmNnOoRrXx".indexOf(colorCode) > -1) {
                     if (player.hasPermission("tchat.color." + colorCode)) {
                        message = this.plugin.getTranslateColors().translateColors(player, message);
                     } else {
                        message = ChatColor.stripColor(message);
                     }
                  }
               } else {
                  message = ChatColor.stripColor(message);
               }
            } else {
               message = this.plugin.getTranslateColors().translateColors(player, message);
            }
         }

         if (this.plugin.getMentionsManager().isEnabled()) {
            message = this.handleMentions(event, player, message);
         }

         if (this.plugin.getConfigManager().isIgnoreEnabled()) {
            List<String> playerIgnoreList = this.plugin.getSaveManager().getIgnoreList(player.getUniqueId());
            List<Player> finalRecipients = event.getRecipients().stream().filter((recipient) -> {
               if (playerIgnoreList.contains("all")) {
                  return recipient.equals(player);
               } else {
                  List<String> recipientIgnoreList = this.plugin.getSaveManager().getIgnoreList(recipient.getUniqueId());
                  return !recipientIgnoreList.contains("all") && !recipientIgnoreList.contains(player.getUniqueId().toString());
               }
            }).toList();
            event.getRecipients().clear();
            event.getRecipients().addAll(finalRecipients);
         }

         channelName = this.plugin.getChannelsManager().getPlayerChannel(player);
         ChannelsConfigManager.Channel channel = this.channelsConfigManager.getChannel(channelName);
         String groupName;
         String errorMessage;
         if (this.plugin.getConfigManager().isFormatEnabled() && this.groupManager.isFormatEnabled(player)) {
            String recipientChannel;
            if (channel != null && channel.cooldownEnabled()) {
               long cooldownTime = (long)channel.cooldown();
               if (!this.canSendMessage(player, channelName, cooldownTime)) {
                  long lastMessageTime = (Long)((Map)this.channelCooldowns.getOrDefault(channelName, new HashMap())).getOrDefault(player.getUniqueId(), 0L);
                  long currentTime = System.currentTimeMillis();
                  long timeLeft = cooldownTime - (currentTime - lastMessageTime);
                  long secondsLeft = timeLeft / 1000L;
                  recipientChannel = this.plugin.getMessagesManager().getPrefix();
                  String m = this.plugin.getMessagesManager().getCooldownChannel();
                  m = m.replace("%seconds%", String.valueOf(secondsLeft));
                  player.sendMessage(this.plugin.getTranslateColors().translateColors(player, recipientChannel + m));
                  event.setCancelled(true);
                  return;
               }

               this.setLastMessageTime(player, channelName);
            }

            String format;
            String prefix;
            if (channel != null && channel.formatEnabled() && channel.enabled() && (player.hasPermission(channel.permission()) || player.hasPermission("tchat.admin") || player.hasPermission("tchat.channel.all"))) {
               format = channel.format();
               format = format.replace("%channel%", channelName);
            } else {
               groupName = this.groupManager.getGroup(player);
               if (this.configManager.isFormatGroup()) {
                  format = this.groupManager.getGroupFormat(groupName);
               } else {
                  format = this.configManager.getFormat();
               }

               if (format.isEmpty()) {
                  String var10000 = player.getName();
                  format = "<" + var10000 + "> " + message;
                  errorMessage = this.plugin.getMessagesManager().getNoFormatGroup();
                  prefix = this.plugin.getMessagesManager().getPrefix();
                  ConsoleCommandSender var42 = Bukkit.getConsoleSender();
                  String var10001 = this.plugin.getTranslateColors().translateColors(player, prefix);
                  var42.sendMessage(var10001 + org.bukkit.ChatColor.translateAlternateColorCodes('&', errorMessage).replace("%group%", groupName));
               }
            }

            if (format.contains("%radius_mode%")) {
               format = format.replace("%radius_mode%", chatrPrefix);
            }

            format = PlaceholderAPI.setPlaceholders(player, format);
            format = TranslateHexColorCodes.translateHexColorCodes("&#", "", format);
            format = ChatColor.translateAlternateColorCodes('&', format);
            String[] parts = format.split("¡", 2);
            errorMessage = parts[0];
            prefix = parts.length > 1 ? parts[1] : "";
            TextComponent mainComponent = new TextComponent(TextComponent.fromLegacyText(errorMessage));
            TextComponent messageComponent = new TextComponent(TextComponent.fromLegacyText(prefix + message));
            String groupName = this.groupManager.getGroup(player);
            GroupManager.HoverClickAction playerHoverClick = this.groupManager.getPlayerHoverClickAction(groupName);
            if (playerHoverClick.isEnabled()) {
               mainComponent.setHoverEvent(this.createHoverEvent(player, playerHoverClick.getHoverText()));
               if (playerHoverClick.isClickEnabled()) {
                  this.applyClickAction(mainComponent, playerHoverClick.getClickAction(), player.getName());
               }
            }

            GroupManager.HoverClickAction messageHoverClick = this.groupManager.getMessageHoverClickAction(groupName);
            if (messageHoverClick.isEnabled()) {
               messageComponent.setHoverEvent(this.createHoverEvent(player, messageHoverClick.getHoverText()));
               if (messageHoverClick.isClickEnabled()) {
                  this.applyClickAction(messageComponent, messageHoverClick.getClickAction(), player.getName());
               }
            }

            mainComponent.addExtra(messageComponent);
            Iterator var20 = event.getRecipients().iterator();

            while(true) {
               Player p;
               boolean hasPermissionForChannel;
               boolean isInRecipientChannel;
               int messageMode;
               label176:
               do {
                  while(var20.hasNext()) {
                     p = (Player)var20.next();
                     if (channel != null && channel.enabled()) {
                        recipientChannel = this.plugin.getChannelsManager().getPlayerChannel(p);
                        hasPermissionForChannel = p.hasPermission(channel.permission()) || p.hasPermission("tchat.admin") || p.hasPermission("tchat.channel.all");
                        isInRecipientChannel = recipientChannel != null && recipientChannel.equals(channelName);
                        messageMode = channel.messageMode();
                        continue label176;
                     }

                     p.spigot().sendMessage(mainComponent);
                  }

                  event.getRecipients().clear();
                  event.setFormat(mainComponent.toPlainText().replace("%", "%%"));
                  if (this.plugin.getDiscordManager().isDiscordEnabled()) {
                     String URL;
                     if (channelName == null) {
                        URL = this.removeMinecraftColorCodes(mainComponent.toLegacyText());
                        this.plugin.getDiscordHook().sendMessage(URL, this.plugin.getDiscordManager().getDiscordHook());
                     } else if (this.plugin.getChannelsConfigManager().getChannel(channelName).discordEnabled()) {
                        URL = this.plugin.getChannelsConfigManager().getChannel(channelName).discordHook();
                        String discordMessage = this.removeMinecraftColorCodes(mainComponent.toLegacyText());
                        this.plugin.getDiscordHook().sendMessage(discordMessage, URL);
                        return;
                     }

                     return;
                  }

                  return;
               } while(messageMode != 0 && (messageMode != 1 || !hasPermissionForChannel) && (messageMode != 2 || !isInRecipientChannel));

               p.spigot().sendMessage(mainComponent);
            }
         } else if (this.plugin.getDiscordManager().isDiscordEnabled()) {
            if (channelName == null) {
               groupName = this.removeMinecraftColorCodes(message);
               this.plugin.getDiscordHook().sendMessage(groupName, this.plugin.getDiscordManager().getDiscordHook());
            } else if (this.plugin.getChannelsConfigManager().getChannel(channelName).discordEnabled()) {
               groupName = this.plugin.getChannelsConfigManager().getChannel(channelName).discordHook();
               errorMessage = this.removeMinecraftColorCodes(message);
               this.plugin.getDiscordHook().sendMessage(errorMessage, groupName);
            }
         }

      }
   }

   @Contract(
      pure = true
   )
   @NotNull
   private String removeMinecraftColorCodes(@NotNull String message) {
      String legacyHexPattern = "§x(§[0-9a-fA-F]){6}";
      String standardColorPattern = "§[0-9a-fk-or]";
      String result = message.replaceAll(legacyHexPattern, "");
      result = result.replaceAll(standardColorPattern, "");
      return result;
   }

   @Contract("_, _ -> new")
   @NotNull
   private HoverEvent createHoverEvent(Player player, @NotNull List<String> hoverText) {
      TextComponent hoverComponent = new TextComponent();
      List<String> processedLines = hoverText.stream().map((linex) -> {
         return this.plugin.getTranslateColors().translateColors(player, linex);
      }).toList();
      int maxLineLength = processedLines.stream().mapToInt((linex) -> {
         return ChatColor.stripColor(linex.replace("%center%", "")).length();
      }).max().orElse(0);
      boolean first = true;
      Iterator var7 = processedLines.iterator();

      while(var7.hasNext()) {
         String line = (String)var7.next();
         if (!first) {
            hoverComponent.addExtra("\n");
         } else {
            first = false;
         }

         if (line.contains("%center%")) {
            String strippedLine = ChatColor.stripColor(line.replace("%center%", ""));
            int spacesToAdd = (maxLineLength - strippedLine.length()) / 2;
            String centeredLine = line.replace("%center%", " ".repeat(Math.max(0, spacesToAdd)));
            hoverComponent.addExtra(new TextComponent(TextComponent.fromLegacyText(centeredLine)));
         } else {
            hoverComponent.addExtra(new TextComponent(TextComponent.fromLegacyText(line)));
         }
      }

      return new HoverEvent(Action.SHOW_TEXT, (new ComponentBuilder(hoverComponent)).create());
   }

   private String handleMentions(@NotNull AsyncPlayerChatEvent event, Player player, String message) {
      Set<Player> mentionedPlayers = new HashSet();
      String finalMessage = message;
      Iterator var6 = event.getRecipients().iterator();

      Player mentionedPlayer;
      String groupName;
      String particle;
      String subtitle;
      while(var6.hasNext()) {
         mentionedPlayer = (Player)var6.next();
         groupName = this.groupManager.getGroup(mentionedPlayer);
         MentionsManager.GroupConfig groupConfig = this.mentionsManager.getGroupConfig(groupName);
         particle = groupConfig.getCharacter();
         subtitle = groupConfig.getColor();
         String mention = particle + mentionedPlayer.getName();
         if (message.contains(mention)) {
            String coloredMention = this.plugin.getTranslateColors().translateColors(player, subtitle + mention);
            finalMessage = finalMessage.replace(mention, coloredMention);
            mentionedPlayers.add(mentionedPlayer);
         }
      }

      var6 = mentionedPlayers.iterator();

      while(var6.hasNext()) {
         mentionedPlayer = (Player)var6.next();
         groupName = this.groupManager.getGroup(mentionedPlayer);
         MentionsManager.EventConfig personalConfig = this.mentionsManager.getPersonalEventConfig(groupName);
         if (personalConfig.isMessageEnabled()) {
            String[] messages = (String[])personalConfig.getMessage().stream().map((msg) -> {
               return msg.replace("%mentioned%", mentionedPlayer.getName());
            }).toArray((x$0) -> {
               return new String[x$0];
            });
            mentionedPlayer.sendMessage(this.plugin.getTranslateColors().translateColors(mentionedPlayer, String.join("\n", messages)));
         }

         if (personalConfig.isTitleEnabled() || personalConfig.isSubtitleEnabled()) {
            particle = personalConfig.isTitleEnabled() ? this.plugin.getTranslateColors().translateColors(mentionedPlayer, personalConfig.getTitle()) : "";
            subtitle = personalConfig.isSubtitleEnabled() ? this.plugin.getTranslateColors().translateColors(mentionedPlayer, personalConfig.getSubtitle()) : "";
            mentionedPlayer.sendTitle(particle, subtitle, 10, 70, 20);
         }

         if (personalConfig.isSoundEnabled()) {
            particle = personalConfig.getSound();
            mentionedPlayer.playSound(mentionedPlayer.getLocation(), particle, 1.0F, 1.0F);
         }

         if (personalConfig.isParticlesEnabled()) {
            particle = personalConfig.getParticle();
            mentionedPlayer.getWorld().spawnParticle(Particle.valueOf(particle.toUpperCase()), mentionedPlayer.getLocation(), 10);
         }

         if (personalConfig.isActionbarEnabled()) {
            mentionedPlayer.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent(this.plugin.getTranslateColors().translateColors(player, personalConfig.getActionbarMessage())));
         }
      }

      String groupName = this.groupManager.getGroup(player);
      MentionsManager.EventConfig globalConfig = this.mentionsManager.getGlobalEventConfig(groupName);
      if (globalConfig.isMessageEnabled() || globalConfig.isTitleEnabled() || globalConfig.isSoundEnabled() || globalConfig.isParticlesEnabled() || globalConfig.isActionbarEnabled()) {
         Iterator var16 = Bukkit.getOnlinePlayers().iterator();

         while(var16.hasNext()) {
            Player recipient = (Player)var16.next();
            if (globalConfig.isMessageEnabled()) {
               recipient.sendMessage(ChatColor.translateAlternateColorCodes('&', String.join("\n", globalConfig.getMessage())));
            }

            if (globalConfig.isTitleEnabled() || globalConfig.isSubtitleEnabled()) {
               particle = globalConfig.isTitleEnabled() ? this.plugin.getTranslateColors().translateColors(player, globalConfig.getTitle()) : " ";
               subtitle = globalConfig.isSubtitleEnabled() ? this.plugin.getTranslateColors().translateColors(player, globalConfig.getSubtitle()) : " ";
               recipient.sendTitle(particle, subtitle, 10, 70, 20);
            }

            if (globalConfig.isSoundEnabled()) {
               particle = globalConfig.getSound();
               recipient.playSound(recipient.getLocation(), particle, 1.0F, 1.0F);
            }

            if (globalConfig.isParticlesEnabled()) {
               particle = globalConfig.getParticle();
               recipient.getWorld().spawnParticle(Particle.valueOf(particle.toUpperCase()), recipient.getLocation(), 10);
            }

            if (globalConfig.isActionbarEnabled()) {
               recipient.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent(this.plugin.getTranslateColors().translateColors(player, globalConfig.getActionbarMessage())));
            }
         }
      }

      return finalMessage;
   }

   private void applyClickAction(TextComponent component, @NotNull String clickAction, String playerName) {
      String replacedAction = clickAction.replace("%player%", playerName);
      String command;
      if (replacedAction.startsWith("[EXECUTE]")) {
         command = replacedAction.substring("[EXECUTE] ".length());
         component.setClickEvent(new ClickEvent(net.md_5.bungee.api.chat.ClickEvent.Action.RUN_COMMAND, command));
      } else if (replacedAction.startsWith("[OPEN]")) {
         command = replacedAction.substring("[OPEN] ".length());
         component.setClickEvent(new ClickEvent(net.md_5.bungee.api.chat.ClickEvent.Action.OPEN_URL, command));
      } else if (replacedAction.startsWith("[SUGGEST]")) {
         command = replacedAction.substring("[SUGGEST] ".length());
         component.setClickEvent(new ClickEvent(net.md_5.bungee.api.chat.ClickEvent.Action.SUGGEST_COMMAND, command));
      }

   }

   private boolean canSendMessage(@NotNull Player player, String channelName, long cooldownTime) {
      Map<UUID, Long> playerCooldowns = (Map)this.channelCooldowns.getOrDefault(channelName, new HashMap());
      long lastMessageTime = (Long)playerCooldowns.getOrDefault(player.getUniqueId(), 0L);
      long currentTime = System.currentTimeMillis();
      return currentTime - lastMessageTime >= cooldownTime;
   }

   private void setLastMessageTime(@NotNull Player player, String channelName) {
      ((Map)this.channelCooldowns.computeIfAbsent(channelName, (k) -> {
         return new HashMap();
      })).put(player.getUniqueId(), System.currentTimeMillis());
   }
}
