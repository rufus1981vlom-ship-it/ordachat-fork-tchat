package listeners;

import config.JoinManager;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import minealex.tchat.OrdaChat;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.jetbrains.annotations.NotNull;

public class PlayerJoinListener implements Listener {
   private final OrdaChat plugin;
   private final JoinManager joinManager;
   private final Set<Player> unverifiedPlayers = new HashSet();

   public PlayerJoinListener(@NotNull OrdaChat plugin) {
      this.plugin = plugin;
      this.joinManager = plugin.getJoinManager();
   }

   @EventHandler
   public void onPlayerJoin(@NotNull PlayerJoinEvent event) {
      Player player = event.getPlayer();
      String username = player.getName();
      if (!this.unverifiedPlayers.contains(player) && this.plugin.getConfigManager().isAntibotEnabled() && !player.hasPermission(this.plugin.getConfigManager().getAntibotBypass()) && !player.hasPermission("tchat.admin")) {
         this.unverifiedPlayers.add(player);
         if (this.plugin.getConfigManager().isAntibotJoin()) {
            String prefix = this.plugin.getMessagesManager().getPrefix();
            String message = this.plugin.getMessagesManager().getAntibotJoin();
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
         }
      }

      this.joinPersonalActions(player, event);
      this.joinGlobalActions(player);
      this.plugin.getDiscordHook().sendJoinMessage(username);
   }

   private void joinGlobalActions(Player player) {
      String groupName = this.plugin.getGroupManager().getGroup(player);
      JoinManager.GroupConfig groupConfig = (JoinManager.GroupConfig)this.joinManager.getAllGroupConfigs().get(groupName);
      if (groupConfig != null) {
         JoinManager.EventConfig globalConfig = groupConfig.getGlobalConfig();
         Iterator var7;
         if (globalConfig.isMessageEnabled()) {
            Iterator var5 = Bukkit.getOnlinePlayers().iterator();

            label87:
            while(true) {
               Player p;
               do {
                  if (!var5.hasNext()) {
                     break label87;
                  }

                  p = (Player)var5.next();
               } while(p.equals(player));

               var7 = globalConfig.getMessage().iterator();

               while(var7.hasNext()) {
                  String line = (String)var7.next();
                  p.sendMessage(this.plugin.getTranslateColors().translateColors(player, line));
               }
            }
         }

         String actionBar;
         if (globalConfig.isTitleEnabled()) {
            actionBar = this.plugin.getTranslateColors().translateColors(player, globalConfig.getTitle());
            String subtitle = this.plugin.getTranslateColors().translateColors(player, globalConfig.getSubtitle());
            var7 = Bukkit.getOnlinePlayers().iterator();

            while(var7.hasNext()) {
               Player p = (Player)var7.next();
               if (!p.equals(player)) {
                  p.sendTitle(actionBar, subtitle, 10, 70, 20);
               }
            }
         }

         Iterator var13;
         Player p;
         if (globalConfig.isSoundEnabled()) {
            Sound sound = Sound.valueOf(globalConfig.getSound().toUpperCase());
            var13 = Bukkit.getOnlinePlayers().iterator();

            while(var13.hasNext()) {
               p = (Player)var13.next();
               if (!p.equals(player)) {
                  p.playSound(p.getLocation(), sound, globalConfig.getVolume(), globalConfig.getPitch());
               }
            }
         }

         if (globalConfig.isParticlesEnabled()) {
            Particle particle = Particle.valueOf(globalConfig.getParticle().toUpperCase());
            var13 = Bukkit.getOnlinePlayers().iterator();

            while(var13.hasNext()) {
               p = (Player)var13.next();
               if (!p.equals(player)) {
                  p.getWorld().spawnParticle(particle, p.getLocation(), 30);
               }
            }
         }

         if (globalConfig.isActionbarEnabled()) {
            actionBar = this.plugin.getTranslateColors().translateColors(player, globalConfig.getActionbarMessage());
            var13 = Bukkit.getOnlinePlayers().iterator();

            while(var13.hasNext()) {
               p = (Player)var13.next();
               if (!p.equals(player)) {
                  p.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText(actionBar));
               }
            }
         }
      }

   }

   private void joinPersonalActions(Player player, PlayerJoinEvent event) {
      String groupName = this.plugin.getGroupManager().getGroup(player);
      JoinManager.GroupConfig groupConfig = (JoinManager.GroupConfig)this.joinManager.getAllGroupConfigs().get(groupName);
      if (groupConfig != null) {
         JoinManager.EventConfig personalConfig = groupConfig.getPersonalConfig();
         if (personalConfig.isMessageEnabled()) {
            Iterator var6 = personalConfig.getMessage().iterator();

            while(var6.hasNext()) {
               String line = (String)var6.next();
               player.sendMessage(this.plugin.getTranslateColors().translateColors(player, line));
            }
         }

         if (personalConfig.isTitleEnabled()) {
            player.sendTitle(this.plugin.getTranslateColors().translateColors(player, personalConfig.getTitle()), this.plugin.getTranslateColors().translateColors(player, personalConfig.getSubtitle()), 10, 70, 20);
         }

         if (personalConfig.isSoundEnabled()) {
            player.playSound(player.getLocation(), Sound.valueOf(personalConfig.getSound()), personalConfig.getVolume(), personalConfig.getPitch());
         }

         if (personalConfig.isParticlesEnabled()) {
            player.getWorld().spawnParticle(Particle.valueOf(personalConfig.getParticle()), player.getLocation(), 30);
         }

         if (personalConfig.isActionbarEnabled()) {
            String actionBar = this.plugin.getTranslateColors().translateColors(player, personalConfig.getActionbarMessage());
            player.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText(actionBar));
         }

         if (personalConfig.isCancelJoinMessage()) {
            event.setJoinMessage((String)null);
         }
      }

   }

   public boolean isUnverified(Player player) {
      return this.unverifiedPlayers.contains(player);
   }

   public void removeUnverifiedPlayer(Player player) {
      this.unverifiedPlayers.remove(player);
   }
}
