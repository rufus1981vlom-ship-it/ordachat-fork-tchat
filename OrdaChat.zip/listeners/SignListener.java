package listeners;

import blocked.AntiAdvertising;
import config.AdvertisingConfig;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import minealex.tchat.OrdaChat;
import org.bukkit.ChatColor;
import org.bukkit.block.BlockState;
import org.bukkit.block.Sign;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.SignChangeEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerInteractEvent;

public class SignListener implements Listener {
   private final OrdaChat plugin;
   private final AntiAdvertising antiAdvertising;

   public SignListener(OrdaChat plugin) {
      this.plugin = plugin;
      this.antiAdvertising = plugin.getAntiAdvertising();
   }

   @EventHandler
   public void onSignChange(SignChangeEvent event) {
      if (!event.isCancelled()) {
         Player player = event.getPlayer();
         String[] lines = event.getLines();

         int i;
         for(i = 0; i < lines.length; ++i) {
            String line = lines[i];
            if (!player.hasPermission("tchat.admin") && !player.hasPermission("tchat.signcolor")) {
               lines[i] = ChatColor.stripColor(line);
            } else {
               lines[i] = this.plugin.getTranslateColors().translateColors(player, line);
            }

            Iterator var6 = this.getAllAdvertisingConfigs().iterator();

            while(var6.hasNext()) {
               AdvertisingConfig config = (AdvertisingConfig)var6.next();
               if (config.isEnabled() && lines[i].matches(config.getMatch())) {
                  if (!player.hasPermission(this.plugin.getConfigManager().getAdvertisingBypass()) || !player.hasPermission("tchat.admin")) {
                     event.setCancelled(true);
                     this.handleSignAdvertising(player, lines[i], config);
                  }

                  return;
               }
            }
         }

         for(i = 0; i < lines.length; ++i) {
            event.setLine(i, lines[i]);
         }

      }
   }

   @EventHandler
   public void onPlayerInteract(PlayerInteractEvent event) {
      if (event.getAction() == Action.RIGHT_CLICK_BLOCK) {
         if (event.getClickedBlock() != null) {
            BlockState var3 = event.getClickedBlock().getState();
            if (var3 instanceof Sign) {
               Sign sign = (Sign)var3;
               Player player = event.getPlayer();
               String[] var4 = sign.getLines();
               String[] var5 = var4;
               int var6 = var4.length;

               for(int var7 = 0; var7 < var6; ++var7) {
                  String s = var5[var7];
                  String line;
                  if (!player.hasPermission("tchat.admin") && !player.hasPermission("tchat.signcolor")) {
                     line = ChatColor.stripColor(s);
                  } else {
                     line = this.plugin.getTranslateColors().translateColors(player, s);
                  }

                  Iterator var10 = this.getAllAdvertisingConfigs().iterator();

                  while(var10.hasNext()) {
                     AdvertisingConfig config = (AdvertisingConfig)var10.next();
                     if (config.isEnabled() && line.matches(config.getMatch())) {
                        if (!player.hasPermission(this.plugin.getConfigManager().getAdvertisingBypass()) || !player.hasPermission("tchat.admin")) {
                           this.handleSignAdvertising(player, line, config);
                        }

                        return;
                     }
                  }
               }

               return;
            }
         }

      }
   }

   private void handleSignAdvertising(Player player, String line, AdvertisingConfig config) {
      this.antiAdvertising.checkAndHandle((AsyncPlayerChatEvent)null, player, line, config);
   }

   private List<AdvertisingConfig> getAllAdvertisingConfigs() {
      List<AdvertisingConfig> configs = new ArrayList();
      configs.add(this.plugin.getConfigManager().getIpv4Config());
      configs.add(this.plugin.getConfigManager().getDomainConfig());
      configs.add(this.plugin.getConfigManager().getLinksConfig());
      return configs;
   }
}
