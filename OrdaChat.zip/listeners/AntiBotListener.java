package listeners;

import java.util.List;
import minealex.tchat.OrdaChat;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.jetbrains.annotations.NotNull;

public class AntiBotListener implements Listener {
   private final OrdaChat plugin;

   public AntiBotListener(OrdaChat plugin) {
      this.plugin = plugin;
   }

   @EventHandler
   public void playerChat(AsyncPlayerChatEvent event, Player player) {
      if (this.plugin.getConfigManager().isAntibotChat()) {
         event.setCancelled(true);
         String prefix = this.plugin.getMessagesManager().getPrefix();
         String message = this.plugin.getMessagesManager().getAntibotChat();
         player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
      }

   }

   @EventHandler
   public void playerCommand(@NotNull PlayerCommandPreprocessEvent event) {
      if (this.plugin.getConfigManager().isAntibotCommand()) {
         Player player = event.getPlayer();
         String command = event.getMessage().split(" ")[0].toLowerCase();
         List<String> whitelist = this.plugin.getConfigManager().getWhitelistCommandsAntiBot();
         if (whitelist.contains(command)) {
            return;
         }

         event.setCancelled(true);
         String prefix = this.plugin.getMessagesManager().getPrefix();
         String message = this.plugin.getMessagesManager().getAntibotCommand();
         player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
      }

   }
}
