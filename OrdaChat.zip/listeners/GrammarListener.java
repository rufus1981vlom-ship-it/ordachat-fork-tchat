package listeners;

import minealex.tchat.OrdaChat;
import org.bukkit.entity.Player;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.jetbrains.annotations.NotNull;

public class GrammarListener {
   private final OrdaChat plugin;

   public GrammarListener(OrdaChat plugin) {
      this.plugin = plugin;
   }

   public void checkGrammar(@NotNull AsyncPlayerChatEvent event, Player player, String message) {
      if (!event.isCancelled()) {
         if (this.plugin.getConfigManager().isGrammarCapEnabled() && !player.hasPermission(this.plugin.getConfigManager().getPermissionBypassCap()) && !player.hasPermission("tchat.admin")) {
            message = this.checkCap(message);
         }

         if (this.plugin.getConfigManager().isGrammarDotEnabled() && !player.hasPermission(this.plugin.getConfigManager().getPermissionBypassFinalDot()) && !player.hasPermission("tchat.admin")) {
            message = this.checkDot(message);
         }

         event.setMessage(message);
         if (this.plugin.getConfigManager().isRepeatMessagesEnabled() && !player.hasPermission(this.plugin.getConfigManager().getBypassRepeatMessages()) && !player.hasPermission("tchat.admin")) {
            this.plugin.getRepeatMessagesListener().checkRepeatMessages(event, player, message);
         }

      }
   }

   public String checkCap(@NotNull String message) {
      if (message.length() > this.plugin.getConfigManager().getGrammarMinCharactersCap()) {
         String var10000 = message.substring(0, 1).toUpperCase();
         return var10000 + message.substring(this.plugin.getConfigManager().getGrammarCapLetters());
      } else {
         return message;
      }
   }

   public String checkDot(@NotNull String message) {
      String dot = this.plugin.getConfigManager().getGrammarDotCharacter();
      return message.length() > this.plugin.getConfigManager().getGrammarMinCharactersDot() && !message.endsWith(dot) ? message + dot : message;
   }
}
