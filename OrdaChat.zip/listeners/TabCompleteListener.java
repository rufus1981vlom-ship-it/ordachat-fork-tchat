package listeners;

import config.BannedCommandsManager;
import java.lang.reflect.Field;
import java.util.Iterator;
import java.util.List;
import minealex.tchat.OrdaChat;
import org.bukkit.command.CommandMap;
import org.bukkit.command.CommandSender;
import org.bukkit.command.defaults.BukkitCommand;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandSendEvent;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class TabCompleteListener implements Listener {
   private final OrdaChat plugin;
   private BannedCommandsManager bannedCommandsManager;
   private List<String> remove;
   private List<String> add;

   public TabCompleteListener(@NotNull OrdaChat plugin) {
      this.plugin = plugin;
      this.bannedCommandsManager = plugin.getBannedCommandsManager();
      this.remove = this.bannedCommandsManager.getNoTabCompleteCommands();
      this.add = this.bannedCommandsManager.getAddTabCommands();
   }

   @EventHandler
   void onPlayerCommandSend(@NotNull PlayerCommandSendEvent event) {
      if (!event.getPlayer().hasPermission(this.bannedCommandsManager.getBypassPermissionTab()) && !event.getPlayer().hasPermission("tchat.admin")) {
         if (this.bannedCommandsManager.getBlockAllCommands()) {
            event.getCommands().removeIf((command) -> {
               return command.contains(":");
            });
         }

         event.getCommands().removeAll(this.remove);
      }

      this.registerCommands();
   }

   private void registerCommands() {
      CommandMap commandMap = this.getCommandMap();
      Iterator var2 = this.add.iterator();

      while(var2.hasNext()) {
         String commandName = (String)var2.next();
         if (commandMap != null && commandMap.getCommand(commandName) == null) {
            BukkitCommand dynamicCommand = new BukkitCommand(commandName) {
               public boolean execute(@NotNull CommandSender sender, @NotNull String label, @NotNull String[] args) {
                  return true;
               }
            };
            commandMap.register(this.plugin.getName(), dynamicCommand);
         }
      }

   }

   @Nullable
   private CommandMap getCommandMap() {
      try {
         Field commandMapField = this.plugin.getServer().getClass().getDeclaredField("commandMap");
         commandMapField.setAccessible(true);
         return (CommandMap)commandMapField.get(this.plugin.getServer());
      } catch (IllegalAccessException | NoSuchFieldException var2) {
         return null;
      }
   }

   public void reloadConfig() {
      this.bannedCommandsManager = this.plugin.getBannedCommandsManager();
      this.remove = this.bannedCommandsManager.getNoTabCompleteCommands();
      this.add = this.bannedCommandsManager.getAddTabCommands();
      this.registerCommands();
   }
}
